package hu.bme.mit.inf.dslreasoner.application.execution;

import com.google.common.collect.Iterables;
import hu.bme.mit.inf.dslreasoner.application.execution.ScriptConsoleDecorator;
import hu.bme.mit.inf.dslreasoner.workspace.FileSystemWorkspace;
import hu.bme.mit.inf.dslreasoner.workspace.ProjectWorkspace;
import hu.bme.mit.inf.dslreasoner.workspace.ReasonerWorkspace;
import java.util.Collection;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.function.Consumer;
import org.eclipse.emf.common.util.URI;
import org.eclipse.xtend2.lib.StringConcatenation;
import org.eclipse.xtext.xbase.lib.CollectionLiterals;
import org.eclipse.xtext.xbase.lib.Conversions;
import org.eclipse.xtext.xbase.lib.Exceptions;
import org.eclipse.xtext.xbase.lib.ExclusiveRange;
import org.eclipse.xtext.xbase.lib.InputOutput;
import org.eclipse.xtext.xbase.lib.IterableExtensions;
import org.eclipse.xtext.xbase.lib.ObjectExtensions;
import org.eclipse.xtext.xbase.lib.Procedures.Procedure1;

@SuppressWarnings("all")
public abstract class ScriptConsole {
  @FunctionalInterface
  public interface Factory {
    ScriptConsole createScriptConsole(final boolean cleanFiles, final URI messageConsoleURI, final URI errorConsoleURI, final URI statisticsConsoleURI);
  }
  
  private final boolean printToConsole;
  
  private final ReasonerWorkspace messageWorkspace;
  
  private final String messageFileName;
  
  private final ReasonerWorkspace errorWorkspace;
  
  private final String errorFileName;
  
  private final ReasonerWorkspace statisticsWorkspace;
  
  private final String statisticsFileName;
  
  private final List<String> errorMessagesDuringInitialisation = new LinkedList<String>();
  
  private final LinkedHashSet<String> statisticsHeaderBuffer = new LinkedHashSet<String>();
  
  private final LinkedList<Map<String, ?>> statisticsDataBuffer = new LinkedList<Map<String, ?>>();
  
  private static final String delimier = ",";
  
  private static final String empty = "";
  
  public ScriptConsole(final boolean printToConsole, final boolean cleanFiles, final URI messageConsoleURI, final URI errorConsoleURI, final URI statisticsConsoleURI) {
    this.messageWorkspace = this.prepareWorkspace(messageConsoleURI, this.errorMessagesDuringInitialisation);
    this.messageFileName = this.prepareFileName(messageConsoleURI);
    this.errorWorkspace = this.prepareWorkspace(errorConsoleURI, this.errorMessagesDuringInitialisation);
    this.errorFileName = this.prepareFileName(errorConsoleURI);
    this.statisticsWorkspace = this.prepareWorkspace(statisticsConsoleURI, this.errorMessagesDuringInitialisation);
    this.statisticsFileName = this.prepareFileName(statisticsConsoleURI);
    this.printToConsole = printToConsole;
  }
  
  /**
   * Writes any error messages that occurred during console initialization.
   * 
   * Should be called by implementations at the end of their constructors.
   */
  protected final void writeErrorMessagesDuringInitialisation() {
    final Consumer<String> _function = (String it) -> {
      StringConcatenation _builder = new StringConcatenation();
      _builder.append("Error during console initialisation: \"");
      _builder.append(it);
      _builder.append("\"");
      this.writeError(_builder.toString());
    };
    this.errorMessagesDuringInitialisation.forEach(_function);
    this.errorMessagesDuringInitialisation.clear();
  }
  
  public void writeMessage(final CharSequence message, final String separator, final ScriptConsoleDecorator[] decorators) {
    final String resolvedText = this.resolveToText(message, separator, decorators);
    if ((this.messageWorkspace != null)) {
      this.messageWorkspace.writeText(this.messageFileName, resolvedText);
    }
    if (this.printToConsole) {
      InputOutput.<String>println(resolvedText);
    }
  }
  
  public void writeMessage(final String message) {
    if ((this.messageWorkspace != null)) {
      this.messageWorkspace.writeText(this.messageFileName, message);
    }
    if (this.printToConsole) {
      InputOutput.<String>println(message);
    }
  }
  
  public void writeError(final CharSequence message, final String separator, final ScriptConsoleDecorator[] decorators) {
    final String resolvedText = this.resolveToText(message, separator, decorators);
    if ((this.errorWorkspace != null)) {
      this.errorWorkspace.writeText(this.errorFileName, resolvedText);
    }
    InputOutput.<CharSequence>println(message);
  }
  
  public void writeError(final String message) {
    if ((this.errorWorkspace != null)) {
      this.errorWorkspace.writeText(this.errorFileName, message);
    }
    InputOutput.<String>println(message);
  }
  
  public URI writeStatistics(final LinkedHashMap<String, ?> statistics) {
    URI _xifexpression = null;
    if ((this.statisticsWorkspace != null)) {
      URI _xblockexpression = null;
      {
        StringConcatenation _builder = new StringConcatenation();
        {
          Set<String> _keySet = statistics.keySet();
          boolean _hasElements = false;
          for(final String key : _keySet) {
            if (!_hasElements) {
              _hasElements = true;
            } else {
              _builder.appendImmediate(ScriptConsole.delimier, "");
            }
            _builder.append(key);
          }
        }
        _builder.newLineIfNotEmpty();
        {
          Collection<?> _values = statistics.values();
          boolean _hasElements_1 = false;
          for(final Object value : _values) {
            if (!_hasElements_1) {
              _hasElements_1 = true;
            } else {
              _builder.appendImmediate(ScriptConsole.delimier, "");
            }
            _builder.append(value);
          }
        }
        final String message = _builder.toString();
        _xblockexpression = this.statisticsWorkspace.writeText(this.statisticsFileName, message);
      }
      _xifexpression = _xblockexpression;
    }
    return _xifexpression;
  }
  
  public boolean addStatistics(final LinkedHashMap<String, ?> statistics) {
    boolean _xblockexpression = false;
    {
      Set<String> _keySet = statistics.keySet();
      for (final String key : _keySet) {
        this.statisticsHeaderBuffer.add(key);
      }
      _xblockexpression = this.statisticsDataBuffer.add(statistics);
    }
    return _xblockexpression;
  }
  
  public void flushStatistics() {
    if ((this.statisticsWorkspace != null)) {
      StringConcatenation _builder = new StringConcatenation();
      {
        boolean _hasElements = false;
        for(final String key : this.statisticsHeaderBuffer) {
          if (!_hasElements) {
            _hasElements = true;
          } else {
            _builder.appendImmediate(ScriptConsole.delimier, "");
          }
          _builder.append(key);
        }
      }
      _builder.newLineIfNotEmpty();
      {
        for(final Map<String, ?> line : this.statisticsDataBuffer) {
          {
            boolean _hasElements_1 = false;
            for(final String key_1 : this.statisticsHeaderBuffer) {
              if (!_hasElements_1) {
                _hasElements_1 = true;
              } else {
                _builder.appendImmediate(ScriptConsole.delimier, "");
              }
              {
                boolean _containsKey = line.containsKey(key_1);
                if (_containsKey) {
                  Object _get = line.get(key_1);
                  _builder.append(_get);
                } else {
                  _builder.append(ScriptConsole.empty);
                }
              }
            }
          }
          _builder.newLineIfNotEmpty();
        }
      }
      final String message = _builder.toString();
      this.statisticsWorkspace.writeText(this.statisticsFileName, message);
      this.statisticsHeaderBuffer.clear();
      this.statisticsDataBuffer.clear();
    }
  }
  
  private ReasonerWorkspace prepareWorkspace(final URI uri, final List<String> errors) {
    if ((uri == null)) {
      return null;
    } else {
      try {
        final URI folderURI = uri.trimSegments(1);
        boolean _isFile = folderURI.isFile();
        if (_isFile) {
          String _string = folderURI.toString();
          FileSystemWorkspace _fileSystemWorkspace = new FileSystemWorkspace(_string, "");
          final Procedure1<FileSystemWorkspace> _function = (FileSystemWorkspace it) -> {
            it.init();
          };
          return ObjectExtensions.<FileSystemWorkspace>operator_doubleArrow(_fileSystemWorkspace, _function);
        } else {
          boolean _isPlatformResource = folderURI.isPlatformResource();
          if (_isPlatformResource) {
            String _string_1 = folderURI.toString();
            ProjectWorkspace _projectWorkspace = new ProjectWorkspace(_string_1, "");
            final Procedure1<ProjectWorkspace> _function_1 = (ProjectWorkspace it) -> {
              it.init();
            };
            return ObjectExtensions.<ProjectWorkspace>operator_doubleArrow(_projectWorkspace, _function_1);
          } else {
            StringConcatenation _builder = new StringConcatenation();
            _builder.append("Unsupported file usi: \"");
            _builder.append(uri);
            _builder.append("\"!");
            throw new UnsupportedOperationException(_builder.toString());
          }
        }
      } catch (final Throwable _t) {
        if (_t instanceof Exception) {
          final Exception e = (Exception)_t;
          String _message = e.getMessage();
          errors.add(_message);
          return null;
        } else {
          throw Exceptions.sneakyThrow(_t);
        }
      }
    }
  }
  
  private String prepareFileName(final URI uri) {
    Object _xifexpression = null;
    if ((uri != null)) {
      return uri.lastSegment();
    } else {
      _xifexpression = null;
    }
    return ((String)_xifexpression);
  }
  
  private String resolveToText(final CharSequence message, final String separator, final ScriptConsoleDecorator[] decorators) {
    final String messageString = message.toString();
    Iterable<String> _xifexpression = null;
    boolean _startsWith = messageString.startsWith(separator, (-1));
    if (_startsWith) {
      String[] _split = messageString.split(separator, (-1));
      _xifexpression = Iterables.<String>concat(Collections.<String>unmodifiableList(CollectionLiterals.<String>newArrayList("")), ((Iterable<? extends String>)Conversions.doWrapArray(_split)));
    } else {
      _xifexpression = IterableExtensions.<String>toList(((Iterable<String>)Conversions.doWrapArray(messageString.split(separator, (-1)))));
    }
    final Iterable<String> separatedMessage = _xifexpression;
    int _size = IterableExtensions.size(separatedMessage);
    int _minus = (_size - 1);
    int _size_1 = ((List<ScriptConsoleDecorator>)Conversions.doWrapArray(decorators)).size();
    boolean _tripleNotEquals = (_minus != _size_1);
    if (_tripleNotEquals) {
      throw new IllegalArgumentException();
    }
    StringConcatenation _builder = new StringConcatenation();
    {
      int _size_2 = ((List<ScriptConsoleDecorator>)Conversions.doWrapArray(decorators)).size();
      ExclusiveRange _doubleDotLessThan = new ExclusiveRange(0, _size_2, true);
      for(final Integer i : _doubleDotLessThan) {
        String _get = ((String[])Conversions.unwrapArray(separatedMessage, String.class))[(i).intValue()];
        _builder.append(_get);
        _builder.append("[");
        String _text = (decorators[(i).intValue()]).getText();
        _builder.append(_text);
        _builder.append("]");
      }
    }
    String _last = IterableExtensions.<String>last(separatedMessage);
    _builder.append(_last);
    return _builder.toString();
  }
}
