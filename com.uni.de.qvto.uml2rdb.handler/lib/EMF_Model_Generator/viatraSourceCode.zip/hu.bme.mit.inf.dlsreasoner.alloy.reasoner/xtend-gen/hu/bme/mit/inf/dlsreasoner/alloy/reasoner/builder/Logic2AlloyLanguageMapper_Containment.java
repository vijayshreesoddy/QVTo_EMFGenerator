package hu.bme.mit.inf.dlsreasoner.alloy.reasoner.builder;

import com.google.common.collect.Iterables;
import hu.bme.mit.inf.dlsreasoner.alloy.reasoner.builder.Logic2AlloyLanguageMapper;
import hu.bme.mit.inf.dlsreasoner.alloy.reasoner.builder.Logic2AlloyLanguageMapperTrace;
import hu.bme.mit.inf.dlsreasoner.alloy.reasoner.builder.Logic2AlloyLanguageMapper_Support;
import hu.bme.mit.inf.dslreasoner.alloyLanguage.ALSDirectProduct;
import hu.bme.mit.inf.dslreasoner.alloyLanguage.ALSEquals;
import hu.bme.mit.inf.dslreasoner.alloyLanguage.ALSFactDeclaration;
import hu.bme.mit.inf.dslreasoner.alloyLanguage.ALSFieldDeclaration;
import hu.bme.mit.inf.dslreasoner.alloyLanguage.ALSIff;
import hu.bme.mit.inf.dslreasoner.alloyLanguage.ALSJoin;
import hu.bme.mit.inf.dslreasoner.alloyLanguage.ALSMultiplicity;
import hu.bme.mit.inf.dslreasoner.alloyLanguage.ALSOr;
import hu.bme.mit.inf.dslreasoner.alloyLanguage.ALSQuantifiedEx;
import hu.bme.mit.inf.dslreasoner.alloyLanguage.ALSReference;
import hu.bme.mit.inf.dslreasoner.alloyLanguage.ALSSignatureDeclaration;
import hu.bme.mit.inf.dslreasoner.alloyLanguage.ALSSubset;
import hu.bme.mit.inf.dslreasoner.alloyLanguage.ALSTerm;
import hu.bme.mit.inf.dslreasoner.alloyLanguage.ALSVariableDeclaration;
import hu.bme.mit.inf.dslreasoner.alloyLanguage.AlSTransitiveClosure;
import hu.bme.mit.inf.dslreasoner.alloyLanguage.AlloyLanguageFactory;
import hu.bme.mit.inf.dslreasoner.logic.model.logiclanguage.LogiclanguageFactory;
import hu.bme.mit.inf.dslreasoner.logic.model.logiclanguage.Relation;
import hu.bme.mit.inf.dslreasoner.logic.model.logiclanguage.RelationDeclaration;
import hu.bme.mit.inf.dslreasoner.logic.model.logiclanguage.SymbolicValue;
import hu.bme.mit.inf.dslreasoner.logic.model.logiclanguage.Term;
import hu.bme.mit.inf.dslreasoner.logic.model.logiclanguage.Type;
import hu.bme.mit.inf.dslreasoner.logic.model.logiclanguage.Variable;
import hu.bme.mit.inf.dslreasoner.logic.model.logicproblem.ContainmentHierarchy;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import org.eclipse.emf.common.util.EList;
import org.eclipse.xtext.xbase.lib.CollectionLiterals;
import org.eclipse.xtext.xbase.lib.Extension;
import org.eclipse.xtext.xbase.lib.Functions.Function1;
import org.eclipse.xtext.xbase.lib.IterableExtensions;
import org.eclipse.xtext.xbase.lib.ListExtensions;
import org.eclipse.xtext.xbase.lib.ObjectExtensions;
import org.eclipse.xtext.xbase.lib.Procedures.Procedure1;

@SuppressWarnings("all")
public class Logic2AlloyLanguageMapper_Containment {
  @Extension
  private final AlloyLanguageFactory factory = AlloyLanguageFactory.eINSTANCE;
  
  private final Logic2AlloyLanguageMapper_Support support = new Logic2AlloyLanguageMapper_Support();
  
  private final Logic2AlloyLanguageMapper base;
  
  public Logic2AlloyLanguageMapper_Containment(final Logic2AlloyLanguageMapper base) {
    this.base = base;
  }
  
  protected boolean transformContainmentHierarchy(final ContainmentHierarchy containment, final Logic2AlloyLanguageMapperTrace trace) {
    boolean _xblockexpression = false;
    {
      ALSFieldDeclaration _createALSFieldDeclaration = this.factory.createALSFieldDeclaration();
      final Procedure1<ALSFieldDeclaration> _function = (ALSFieldDeclaration it) -> {
        it.setName(this.support.toID(Collections.<String>unmodifiableList(CollectionLiterals.<String>newArrayList("util", "root"))));
        it.setMultiplicity(ALSMultiplicity.ONE);
        it.setType(this.typesOrderedInContainment(containment, trace));
      };
      final ALSFieldDeclaration rootField = ObjectExtensions.<ALSFieldDeclaration>operator_doubleArrow(_createALSFieldDeclaration, _function);
      EList<ALSFieldDeclaration> _fields = trace.logicLanguageBody.getFields();
      _fields.add(rootField);
      ALSFieldDeclaration _createALSFieldDeclaration_1 = this.factory.createALSFieldDeclaration();
      final Procedure1<ALSFieldDeclaration> _function_1 = (ALSFieldDeclaration it) -> {
        it.setName(this.support.toID(Collections.<String>unmodifiableList(CollectionLiterals.<String>newArrayList("util", "contains"))));
        ALSDirectProduct _createALSDirectProduct = this.factory.createALSDirectProduct();
        final Procedure1<ALSDirectProduct> _function_2 = (ALSDirectProduct it_1) -> {
          it_1.setLeftMultiplicit(ALSMultiplicity.LONE);
          it_1.setRightMultiplicit(ALSMultiplicity.SET);
          it_1.setLeftOperand(this.typesOrderedInContainment(containment, trace));
          it_1.setRightOperand(this.typesOrderedInContainment(containment, trace));
        };
        ALSDirectProduct _doubleArrow = ObjectExtensions.<ALSDirectProduct>operator_doubleArrow(_createALSDirectProduct, _function_2);
        it.setType(_doubleArrow);
      };
      final ALSFieldDeclaration contains = ObjectExtensions.<ALSFieldDeclaration>operator_doubleArrow(_createALSFieldDeclaration_1, _function_1);
      EList<ALSFieldDeclaration> _fields_1 = trace.logicLanguageBody.getFields();
      _fields_1.add(contains);
      ALSFactDeclaration _createALSFactDeclaration = this.factory.createALSFactDeclaration();
      final Procedure1<ALSFactDeclaration> _function_2 = (ALSFactDeclaration it) -> {
        it.setName(this.support.toID(Collections.<String>unmodifiableList(CollectionLiterals.<String>newArrayList("util", "containmentDefinition"))));
      };
      final ALSFactDeclaration containmentRelationDefinition = ObjectExtensions.<ALSFactDeclaration>operator_doubleArrow(_createALSFactDeclaration, _function_2);
      final Function1<Relation, Boolean> _function_3 = (Relation it) -> {
        return Boolean.valueOf((it instanceof RelationDeclaration));
      };
      boolean _forall = IterableExtensions.<Relation>forall(containment.getContainmentRelations(), _function_3);
      if (_forall) {
        final Function1<RelationDeclaration, ALSTerm> _function_4 = (RelationDeclaration relation) -> {
          return this.base.getRelationMapper().transformRelationReference(relation, trace);
        };
        final List<ALSTerm> containmentRelations = IterableExtensions.<ALSTerm>toList(IterableExtensions.<RelationDeclaration, ALSTerm>map(Iterables.<RelationDeclaration>filter(containment.getContainmentRelations(), RelationDeclaration.class), _function_4));
        ALSEquals _createALSEquals = this.factory.createALSEquals();
        final Procedure1<ALSEquals> _function_5 = (ALSEquals it) -> {
          ALSJoin _createALSJoin = this.factory.createALSJoin();
          final Procedure1<ALSJoin> _function_6 = (ALSJoin it_1) -> {
            ALSReference _createALSReference = this.factory.createALSReference();
            final Procedure1<ALSReference> _function_7 = (ALSReference it_2) -> {
              it_2.setReferred(trace.logicLanguage);
            };
            ALSReference _doubleArrow = ObjectExtensions.<ALSReference>operator_doubleArrow(_createALSReference, _function_7);
            it_1.setLeftOperand(_doubleArrow);
            ALSReference _createALSReference_1 = this.factory.createALSReference();
            final Procedure1<ALSReference> _function_8 = (ALSReference it_2) -> {
              it_2.setReferred(contains);
            };
            ALSReference _doubleArrow_1 = ObjectExtensions.<ALSReference>operator_doubleArrow(_createALSReference_1, _function_8);
            it_1.setRightOperand(_doubleArrow_1);
          };
          ALSJoin _doubleArrow = ObjectExtensions.<ALSJoin>operator_doubleArrow(_createALSJoin, _function_6);
          it.setLeftOperand(_doubleArrow);
          it.setRightOperand(this.support.unfoldPlus(containmentRelations));
        };
        ALSEquals _doubleArrow = ObjectExtensions.<ALSEquals>operator_doubleArrow(_createALSEquals, _function_5);
        containmentRelationDefinition.setTerm(_doubleArrow);
      } else {
        ALSVariableDeclaration _createALSVariableDeclaration = this.factory.createALSVariableDeclaration();
        final Procedure1<ALSVariableDeclaration> _function_6 = (ALSVariableDeclaration it) -> {
          it.setName("parent");
          it.setRange(this.typesOrderedInContainment(containment, trace));
        };
        final ALSVariableDeclaration parent = ObjectExtensions.<ALSVariableDeclaration>operator_doubleArrow(_createALSVariableDeclaration, _function_6);
        ALSVariableDeclaration _createALSVariableDeclaration_1 = this.factory.createALSVariableDeclaration();
        final Procedure1<ALSVariableDeclaration> _function_7 = (ALSVariableDeclaration it) -> {
          it.setName("child");
          it.setRange(this.typesOrderedInContainment(containment, trace));
        };
        final ALSVariableDeclaration child = ObjectExtensions.<ALSVariableDeclaration>operator_doubleArrow(_createALSVariableDeclaration_1, _function_7);
        final LogiclanguageFactory logicFactory = LogiclanguageFactory.eINSTANCE;
        final Variable logicParentVariable = logicFactory.createVariable();
        final Variable logicChildVariable = logicFactory.createVariable();
        SymbolicValue _createSymbolicValue = logicFactory.createSymbolicValue();
        final Procedure1<SymbolicValue> _function_8 = (SymbolicValue it) -> {
          it.setSymbolicReference(logicParentVariable);
        };
        final SymbolicValue logicParent = ObjectExtensions.<SymbolicValue>operator_doubleArrow(_createSymbolicValue, _function_8);
        SymbolicValue _createSymbolicValue_1 = logicFactory.createSymbolicValue();
        final Procedure1<SymbolicValue> _function_9 = (SymbolicValue it) -> {
          it.setSymbolicReference(logicChildVariable);
        };
        final SymbolicValue logicChild = ObjectExtensions.<SymbolicValue>operator_doubleArrow(_createSymbolicValue_1, _function_9);
        HashMap<Variable, ALSVariableDeclaration> _hashMap = new HashMap<Variable, ALSVariableDeclaration>();
        final Procedure1<HashMap<Variable, ALSVariableDeclaration>> _function_10 = (HashMap<Variable, ALSVariableDeclaration> it) -> {
          it.put(logicParentVariable, parent);
          it.put(logicChildVariable, child);
        };
        final HashMap<Variable, ALSVariableDeclaration> variableMap = ObjectExtensions.<HashMap<Variable, ALSVariableDeclaration>>operator_doubleArrow(_hashMap, _function_10);
        final Function1<Relation, ALSTerm> _function_11 = (Relation relation) -> {
          return this.base.transformSymbolicReference(relation, Collections.<Term>unmodifiableList(CollectionLiterals.<Term>newArrayList(logicParent, logicChild)), trace, variableMap);
        };
        final List<ALSTerm> possibleRelations = ListExtensions.<Relation, ALSTerm>map(containment.getContainmentRelations(), _function_11);
        ALSQuantifiedEx _createALSQuantifiedEx = this.factory.createALSQuantifiedEx();
        final Procedure1<ALSQuantifiedEx> _function_12 = (ALSQuantifiedEx it) -> {
          it.setType(ALSMultiplicity.ALL);
          EList<ALSVariableDeclaration> _variables = it.getVariables();
          _variables.add(parent);
          EList<ALSVariableDeclaration> _variables_1 = it.getVariables();
          _variables_1.add(child);
          ALSIff _createALSIff = this.factory.createALSIff();
          final Procedure1<ALSIff> _function_13 = (ALSIff it_1) -> {
            ALSSubset _createALSSubset = this.factory.createALSSubset();
            final Procedure1<ALSSubset> _function_14 = (ALSSubset it_2) -> {
              ALSDirectProduct _createALSDirectProduct = this.factory.createALSDirectProduct();
              final Procedure1<ALSDirectProduct> _function_15 = (ALSDirectProduct it_3) -> {
                ALSReference _createALSReference = this.factory.createALSReference();
                final Procedure1<ALSReference> _function_16 = (ALSReference it_4) -> {
                  it_4.setReferred(child);
                };
                ALSReference _doubleArrow_1 = ObjectExtensions.<ALSReference>operator_doubleArrow(_createALSReference, _function_16);
                it_3.setLeftOperand(_doubleArrow_1);
                ALSReference _createALSReference_1 = this.factory.createALSReference();
                final Procedure1<ALSReference> _function_17 = (ALSReference it_4) -> {
                  it_4.setReferred(parent);
                };
                ALSReference _doubleArrow_2 = ObjectExtensions.<ALSReference>operator_doubleArrow(_createALSReference_1, _function_17);
                it_3.setRightOperand(_doubleArrow_2);
              };
              ALSDirectProduct _doubleArrow_1 = ObjectExtensions.<ALSDirectProduct>operator_doubleArrow(_createALSDirectProduct, _function_15);
              it_2.setLeftOperand(_doubleArrow_1);
              ALSJoin _createALSJoin = this.factory.createALSJoin();
              final Procedure1<ALSJoin> _function_16 = (ALSJoin it_3) -> {
                ALSReference _createALSReference = this.factory.createALSReference();
                final Procedure1<ALSReference> _function_17 = (ALSReference it_4) -> {
                  it_4.setReferred(trace.logicLanguage);
                };
                ALSReference _doubleArrow_2 = ObjectExtensions.<ALSReference>operator_doubleArrow(_createALSReference, _function_17);
                it_3.setLeftOperand(_doubleArrow_2);
                ALSReference _createALSReference_1 = this.factory.createALSReference();
                final Procedure1<ALSReference> _function_18 = (ALSReference it_4) -> {
                  it_4.setReferred(contains);
                };
                ALSReference _doubleArrow_3 = ObjectExtensions.<ALSReference>operator_doubleArrow(_createALSReference_1, _function_18);
                it_3.setRightOperand(_doubleArrow_3);
              };
              ALSJoin _doubleArrow_2 = ObjectExtensions.<ALSJoin>operator_doubleArrow(_createALSJoin, _function_16);
              it_2.setRightOperand(_doubleArrow_2);
            };
            ALSSubset _doubleArrow_1 = ObjectExtensions.<ALSSubset>operator_doubleArrow(_createALSSubset, _function_14);
            it_1.setLeftOperand(_doubleArrow_1);
            it_1.setRightOperand(this.support.unfoldOr(possibleRelations, trace));
          };
          ALSIff _doubleArrow_1 = ObjectExtensions.<ALSIff>operator_doubleArrow(_createALSIff, _function_13);
          it.setExpression(_doubleArrow_1);
        };
        ALSQuantifiedEx _doubleArrow_1 = ObjectExtensions.<ALSQuantifiedEx>operator_doubleArrow(_createALSQuantifiedEx, _function_12);
        containmentRelationDefinition.setTerm(_doubleArrow_1);
      }
      EList<ALSFactDeclaration> _factDeclarations = trace.specification.getFactDeclarations();
      _factDeclarations.add(containmentRelationDefinition);
      EList<ALSFactDeclaration> _factDeclarations_1 = trace.specification.getFactDeclarations();
      ALSFactDeclaration _createALSFactDeclaration_1 = this.factory.createALSFactDeclaration();
      final Procedure1<ALSFactDeclaration> _function_13 = (ALSFactDeclaration it) -> {
        it.setName(this.support.toID(Collections.<String>unmodifiableList(CollectionLiterals.<String>newArrayList("util", "noParentForRoot"))));
        ALSQuantifiedEx _createALSQuantifiedEx_1 = this.factory.createALSQuantifiedEx();
        final Procedure1<ALSQuantifiedEx> _function_14 = (ALSQuantifiedEx it_1) -> {
          it_1.setType(ALSMultiplicity.NO);
          ALSVariableDeclaration _createALSVariableDeclaration_2 = this.factory.createALSVariableDeclaration();
          final Procedure1<ALSVariableDeclaration> _function_15 = (ALSVariableDeclaration it_2) -> {
            it_2.setName("parent");
            it_2.setRange(this.typesOrderedInContainment(containment, trace));
          };
          final ALSVariableDeclaration parent_1 = ObjectExtensions.<ALSVariableDeclaration>operator_doubleArrow(_createALSVariableDeclaration_2, _function_15);
          EList<ALSVariableDeclaration> _variables = it_1.getVariables();
          _variables.add(parent_1);
          ALSSubset _createALSSubset = this.factory.createALSSubset();
          final Procedure1<ALSSubset> _function_16 = (ALSSubset it_2) -> {
            ALSDirectProduct _createALSDirectProduct = this.factory.createALSDirectProduct();
            final Procedure1<ALSDirectProduct> _function_17 = (ALSDirectProduct it_3) -> {
              ALSReference _createALSReference = this.factory.createALSReference();
              final Procedure1<ALSReference> _function_18 = (ALSReference it_4) -> {
                it_4.setReferred(parent_1);
              };
              ALSReference _doubleArrow_2 = ObjectExtensions.<ALSReference>operator_doubleArrow(_createALSReference, _function_18);
              it_3.setLeftOperand(_doubleArrow_2);
              ALSJoin _createALSJoin = this.factory.createALSJoin();
              final Procedure1<ALSJoin> _function_19 = (ALSJoin it_4) -> {
                ALSReference _createALSReference_1 = this.factory.createALSReference();
                final Procedure1<ALSReference> _function_20 = (ALSReference it_5) -> {
                  it_5.setReferred(trace.logicLanguage);
                };
                ALSReference _doubleArrow_3 = ObjectExtensions.<ALSReference>operator_doubleArrow(_createALSReference_1, _function_20);
                it_4.setLeftOperand(_doubleArrow_3);
                ALSReference _createALSReference_2 = this.factory.createALSReference();
                final Procedure1<ALSReference> _function_21 = (ALSReference it_5) -> {
                  it_5.setReferred(rootField);
                };
                ALSReference _doubleArrow_4 = ObjectExtensions.<ALSReference>operator_doubleArrow(_createALSReference_2, _function_21);
                it_4.setRightOperand(_doubleArrow_4);
              };
              ALSJoin _doubleArrow_3 = ObjectExtensions.<ALSJoin>operator_doubleArrow(_createALSJoin, _function_19);
              it_3.setRightOperand(_doubleArrow_3);
            };
            ALSDirectProduct _doubleArrow_2 = ObjectExtensions.<ALSDirectProduct>operator_doubleArrow(_createALSDirectProduct, _function_17);
            it_2.setLeftOperand(_doubleArrow_2);
            ALSJoin _createALSJoin = this.factory.createALSJoin();
            final Procedure1<ALSJoin> _function_18 = (ALSJoin it_3) -> {
              ALSReference _createALSReference = this.factory.createALSReference();
              final Procedure1<ALSReference> _function_19 = (ALSReference it_4) -> {
                it_4.setReferred(trace.logicLanguage);
              };
              ALSReference _doubleArrow_3 = ObjectExtensions.<ALSReference>operator_doubleArrow(_createALSReference, _function_19);
              it_3.setLeftOperand(_doubleArrow_3);
              ALSReference _createALSReference_1 = this.factory.createALSReference();
              final Procedure1<ALSReference> _function_20 = (ALSReference it_4) -> {
                it_4.setReferred(contains);
              };
              ALSReference _doubleArrow_4 = ObjectExtensions.<ALSReference>operator_doubleArrow(_createALSReference_1, _function_20);
              it_3.setRightOperand(_doubleArrow_4);
            };
            ALSJoin _doubleArrow_3 = ObjectExtensions.<ALSJoin>operator_doubleArrow(_createALSJoin, _function_18);
            it_2.setRightOperand(_doubleArrow_3);
          };
          ALSSubset _doubleArrow_2 = ObjectExtensions.<ALSSubset>operator_doubleArrow(_createALSSubset, _function_16);
          it_1.setExpression(_doubleArrow_2);
        };
        ALSQuantifiedEx _doubleArrow_2 = ObjectExtensions.<ALSQuantifiedEx>operator_doubleArrow(_createALSQuantifiedEx_1, _function_14);
        it.setTerm(_doubleArrow_2);
      };
      ALSFactDeclaration _doubleArrow_2 = ObjectExtensions.<ALSFactDeclaration>operator_doubleArrow(_createALSFactDeclaration_1, _function_13);
      _factDeclarations_1.add(_doubleArrow_2);
      EList<ALSFactDeclaration> _factDeclarations_2 = trace.specification.getFactDeclarations();
      ALSFactDeclaration _createALSFactDeclaration_2 = this.factory.createALSFactDeclaration();
      final Procedure1<ALSFactDeclaration> _function_14 = (ALSFactDeclaration it) -> {
        it.setName(this.support.toID(Collections.<String>unmodifiableList(CollectionLiterals.<String>newArrayList("util", "atLeastOneParent"))));
        ALSQuantifiedEx _createALSQuantifiedEx_1 = this.factory.createALSQuantifiedEx();
        final Procedure1<ALSQuantifiedEx> _function_15 = (ALSQuantifiedEx it_1) -> {
          it_1.setType(ALSMultiplicity.ALL);
          ALSVariableDeclaration _createALSVariableDeclaration_2 = this.factory.createALSVariableDeclaration();
          final Procedure1<ALSVariableDeclaration> _function_16 = (ALSVariableDeclaration it_2) -> {
            it_2.setName("child");
            it_2.setRange(this.typesOrderedInContainment(containment, trace));
          };
          final ALSVariableDeclaration child_1 = ObjectExtensions.<ALSVariableDeclaration>operator_doubleArrow(_createALSVariableDeclaration_2, _function_16);
          EList<ALSVariableDeclaration> _variables = it_1.getVariables();
          _variables.add(child_1);
          ALSOr _createALSOr = this.factory.createALSOr();
          final Procedure1<ALSOr> _function_17 = (ALSOr it_2) -> {
            ALSEquals _createALSEquals_1 = this.factory.createALSEquals();
            final Procedure1<ALSEquals> _function_18 = (ALSEquals it_3) -> {
              ALSReference _createALSReference = this.factory.createALSReference();
              final Procedure1<ALSReference> _function_19 = (ALSReference it_4) -> {
                it_4.setReferred(child_1);
              };
              ALSReference _doubleArrow_3 = ObjectExtensions.<ALSReference>operator_doubleArrow(_createALSReference, _function_19);
              it_3.setLeftOperand(_doubleArrow_3);
              ALSJoin _createALSJoin = this.factory.createALSJoin();
              final Procedure1<ALSJoin> _function_20 = (ALSJoin it_4) -> {
                ALSReference _createALSReference_1 = this.factory.createALSReference();
                final Procedure1<ALSReference> _function_21 = (ALSReference it_5) -> {
                  it_5.setReferred(trace.logicLanguage);
                };
                ALSReference _doubleArrow_4 = ObjectExtensions.<ALSReference>operator_doubleArrow(_createALSReference_1, _function_21);
                it_4.setLeftOperand(_doubleArrow_4);
                ALSReference _createALSReference_2 = this.factory.createALSReference();
                final Procedure1<ALSReference> _function_22 = (ALSReference it_5) -> {
                  it_5.setReferred(rootField);
                };
                ALSReference _doubleArrow_5 = ObjectExtensions.<ALSReference>operator_doubleArrow(_createALSReference_2, _function_22);
                it_4.setRightOperand(_doubleArrow_5);
              };
              ALSJoin _doubleArrow_4 = ObjectExtensions.<ALSJoin>operator_doubleArrow(_createALSJoin, _function_20);
              it_3.setRightOperand(_doubleArrow_4);
            };
            ALSEquals _doubleArrow_3 = ObjectExtensions.<ALSEquals>operator_doubleArrow(_createALSEquals_1, _function_18);
            it_2.setLeftOperand(_doubleArrow_3);
            ALSQuantifiedEx _createALSQuantifiedEx_2 = this.factory.createALSQuantifiedEx();
            final Procedure1<ALSQuantifiedEx> _function_19 = (ALSQuantifiedEx it_3) -> {
              it_3.setType(ALSMultiplicity.SOME);
              ALSVariableDeclaration _createALSVariableDeclaration_3 = this.factory.createALSVariableDeclaration();
              final Procedure1<ALSVariableDeclaration> _function_20 = (ALSVariableDeclaration it_4) -> {
                it_4.setName("parent");
                it_4.setRange(this.typesOrderedInContainment(containment, trace));
              };
              final ALSVariableDeclaration parent_1 = ObjectExtensions.<ALSVariableDeclaration>operator_doubleArrow(_createALSVariableDeclaration_3, _function_20);
              EList<ALSVariableDeclaration> _variables_1 = it_3.getVariables();
              _variables_1.add(parent_1);
              ALSSubset _createALSSubset = this.factory.createALSSubset();
              final Procedure1<ALSSubset> _function_21 = (ALSSubset it_4) -> {
                ALSDirectProduct _createALSDirectProduct = this.factory.createALSDirectProduct();
                final Procedure1<ALSDirectProduct> _function_22 = (ALSDirectProduct it_5) -> {
                  ALSReference _createALSReference = this.factory.createALSReference();
                  final Procedure1<ALSReference> _function_23 = (ALSReference it_6) -> {
                    it_6.setReferred(parent_1);
                  };
                  ALSReference _doubleArrow_4 = ObjectExtensions.<ALSReference>operator_doubleArrow(_createALSReference, _function_23);
                  it_5.setLeftOperand(_doubleArrow_4);
                  ALSReference _createALSReference_1 = this.factory.createALSReference();
                  final Procedure1<ALSReference> _function_24 = (ALSReference it_6) -> {
                    it_6.setReferred(child_1);
                  };
                  ALSReference _doubleArrow_5 = ObjectExtensions.<ALSReference>operator_doubleArrow(_createALSReference_1, _function_24);
                  it_5.setRightOperand(_doubleArrow_5);
                };
                ALSDirectProduct _doubleArrow_4 = ObjectExtensions.<ALSDirectProduct>operator_doubleArrow(_createALSDirectProduct, _function_22);
                it_4.setLeftOperand(_doubleArrow_4);
                ALSJoin _createALSJoin = this.factory.createALSJoin();
                final Procedure1<ALSJoin> _function_23 = (ALSJoin it_5) -> {
                  ALSReference _createALSReference = this.factory.createALSReference();
                  final Procedure1<ALSReference> _function_24 = (ALSReference it_6) -> {
                    it_6.setReferred(trace.logicLanguage);
                  };
                  ALSReference _doubleArrow_5 = ObjectExtensions.<ALSReference>operator_doubleArrow(_createALSReference, _function_24);
                  it_5.setLeftOperand(_doubleArrow_5);
                  ALSReference _createALSReference_1 = this.factory.createALSReference();
                  final Procedure1<ALSReference> _function_25 = (ALSReference it_6) -> {
                    it_6.setReferred(contains);
                  };
                  ALSReference _doubleArrow_6 = ObjectExtensions.<ALSReference>operator_doubleArrow(_createALSReference_1, _function_25);
                  it_5.setRightOperand(_doubleArrow_6);
                };
                ALSJoin _doubleArrow_5 = ObjectExtensions.<ALSJoin>operator_doubleArrow(_createALSJoin, _function_23);
                it_4.setRightOperand(_doubleArrow_5);
              };
              ALSSubset _doubleArrow_4 = ObjectExtensions.<ALSSubset>operator_doubleArrow(_createALSSubset, _function_21);
              it_3.setExpression(_doubleArrow_4);
            };
            ALSQuantifiedEx _doubleArrow_4 = ObjectExtensions.<ALSQuantifiedEx>operator_doubleArrow(_createALSQuantifiedEx_2, _function_19);
            it_2.setRightOperand(_doubleArrow_4);
          };
          ALSOr _doubleArrow_3 = ObjectExtensions.<ALSOr>operator_doubleArrow(_createALSOr, _function_17);
          it_1.setExpression(_doubleArrow_3);
        };
        ALSQuantifiedEx _doubleArrow_3 = ObjectExtensions.<ALSQuantifiedEx>operator_doubleArrow(_createALSQuantifiedEx_1, _function_15);
        it.setTerm(_doubleArrow_3);
      };
      ALSFactDeclaration _doubleArrow_3 = ObjectExtensions.<ALSFactDeclaration>operator_doubleArrow(_createALSFactDeclaration_2, _function_14);
      _factDeclarations_2.add(_doubleArrow_3);
      EList<ALSFactDeclaration> _factDeclarations_3 = trace.specification.getFactDeclarations();
      ALSFactDeclaration _createALSFactDeclaration_3 = this.factory.createALSFactDeclaration();
      final Procedure1<ALSFactDeclaration> _function_15 = (ALSFactDeclaration it) -> {
        it.setName(this.support.toID(Collections.<String>unmodifiableList(CollectionLiterals.<String>newArrayList("util", "noCircularContainment"))));
        ALSQuantifiedEx _createALSQuantifiedEx_1 = this.factory.createALSQuantifiedEx();
        final Procedure1<ALSQuantifiedEx> _function_16 = (ALSQuantifiedEx it_1) -> {
          it_1.setType(ALSMultiplicity.NO);
          ALSVariableDeclaration _createALSVariableDeclaration_2 = this.factory.createALSVariableDeclaration();
          final Procedure1<ALSVariableDeclaration> _function_17 = (ALSVariableDeclaration it_2) -> {
            it_2.setName("circle");
            it_2.setRange(this.typesOrderedInContainment(containment, trace));
          };
          final ALSVariableDeclaration variable = ObjectExtensions.<ALSVariableDeclaration>operator_doubleArrow(_createALSVariableDeclaration_2, _function_17);
          EList<ALSVariableDeclaration> _variables = it_1.getVariables();
          _variables.add(variable);
          ALSSubset _createALSSubset = this.factory.createALSSubset();
          final Procedure1<ALSSubset> _function_18 = (ALSSubset it_2) -> {
            ALSDirectProduct _createALSDirectProduct = this.factory.createALSDirectProduct();
            final Procedure1<ALSDirectProduct> _function_19 = (ALSDirectProduct it_3) -> {
              ALSReference _createALSReference = this.factory.createALSReference();
              final Procedure1<ALSReference> _function_20 = (ALSReference it_4) -> {
                it_4.setReferred(variable);
              };
              ALSReference _doubleArrow_4 = ObjectExtensions.<ALSReference>operator_doubleArrow(_createALSReference, _function_20);
              it_3.setLeftOperand(_doubleArrow_4);
              ALSReference _createALSReference_1 = this.factory.createALSReference();
              final Procedure1<ALSReference> _function_21 = (ALSReference it_4) -> {
                it_4.setReferred(variable);
              };
              ALSReference _doubleArrow_5 = ObjectExtensions.<ALSReference>operator_doubleArrow(_createALSReference_1, _function_21);
              it_3.setRightOperand(_doubleArrow_5);
            };
            ALSDirectProduct _doubleArrow_4 = ObjectExtensions.<ALSDirectProduct>operator_doubleArrow(_createALSDirectProduct, _function_19);
            it_2.setLeftOperand(_doubleArrow_4);
            AlSTransitiveClosure _createAlSTransitiveClosure = this.factory.createAlSTransitiveClosure();
            final Procedure1<AlSTransitiveClosure> _function_20 = (AlSTransitiveClosure it_3) -> {
              ALSJoin _createALSJoin = this.factory.createALSJoin();
              final Procedure1<ALSJoin> _function_21 = (ALSJoin it_4) -> {
                ALSReference _createALSReference = this.factory.createALSReference();
                final Procedure1<ALSReference> _function_22 = (ALSReference it_5) -> {
                  it_5.setReferred(trace.logicLanguage);
                };
                ALSReference _doubleArrow_5 = ObjectExtensions.<ALSReference>operator_doubleArrow(_createALSReference, _function_22);
                it_4.setLeftOperand(_doubleArrow_5);
                ALSReference _createALSReference_1 = this.factory.createALSReference();
                final Procedure1<ALSReference> _function_23 = (ALSReference it_5) -> {
                  it_5.setReferred(contains);
                };
                ALSReference _doubleArrow_6 = ObjectExtensions.<ALSReference>operator_doubleArrow(_createALSReference_1, _function_23);
                it_4.setRightOperand(_doubleArrow_6);
              };
              ALSJoin _doubleArrow_5 = ObjectExtensions.<ALSJoin>operator_doubleArrow(_createALSJoin, _function_21);
              it_3.setOperand(_doubleArrow_5);
            };
            AlSTransitiveClosure _doubleArrow_5 = ObjectExtensions.<AlSTransitiveClosure>operator_doubleArrow(_createAlSTransitiveClosure, _function_20);
            it_2.setRightOperand(_doubleArrow_5);
          };
          ALSSubset _doubleArrow_4 = ObjectExtensions.<ALSSubset>operator_doubleArrow(_createALSSubset, _function_18);
          it_1.setExpression(_doubleArrow_4);
        };
        ALSQuantifiedEx _doubleArrow_4 = ObjectExtensions.<ALSQuantifiedEx>operator_doubleArrow(_createALSQuantifiedEx_1, _function_16);
        it.setTerm(_doubleArrow_4);
      };
      ALSFactDeclaration _doubleArrow_4 = ObjectExtensions.<ALSFactDeclaration>operator_doubleArrow(_createALSFactDeclaration_3, _function_15);
      _xblockexpression = _factDeclarations_3.add(_doubleArrow_4);
    }
    return _xblockexpression;
  }
  
  /**
   * def boolean coveringSignatureNotInContainment(ALSSignatureDeclaration target, List<ALSSignatureDeclaration> signaturesInContainment, SubsetMatcher matcher) {
   * val subtypes = matcher.getAllValuesOfx(target);
   * for(subType : subtypes) {
   * val isSubtypeOfASignatureInContainment = signaturesInContainment.exists[contained |
   * matcher.hasMatch(subType,contained)
   * ]
   * if(!isSubtypeOfASignatureInContainment) {
   * return false
   * }
   * }
   * return true
   * }
   */
  protected ALSTerm typesOrderedInContainment(final ContainmentHierarchy containment, final Logic2AlloyLanguageMapperTrace trace) {
    final EList<Type> types = containment.getTypesOrderedInHierarchy();
    final Function1<Type, List<ALSSignatureDeclaration>> _function = (Type it) -> {
      return this.base.getTypeMapper().transformTypeReference(it, this.base, trace);
    };
    final Iterable<ALSSignatureDeclaration> signaturesInContainment = Iterables.<ALSSignatureDeclaration>concat(ListExtensions.<Type, List<ALSSignatureDeclaration>>map(types, _function));
    final Function1<ALSSignatureDeclaration, ALSReference> _function_1 = (ALSSignatureDeclaration sig) -> {
      ALSReference _createALSReference = this.factory.createALSReference();
      final Procedure1<ALSReference> _function_2 = (ALSReference it) -> {
        it.setReferred(sig);
      };
      return ObjectExtensions.<ALSReference>operator_doubleArrow(_createALSReference, _function_2);
    };
    final List<ALSReference> typeReferences = IterableExtensions.<ALSReference>toList(IterableExtensions.<ALSSignatureDeclaration, ALSReference>map(signaturesInContainment, _function_1));
    return this.support.unfoldPlus(typeReferences);
  }
}
