package hu.bme.mit.inf.dlsreasoner.alloy.reasoner.builder;

import hu.bme.mit.inf.dlsreasoner.alloy.reasoner.builder.AlloyModelInterpretation_TypeInterpretation;
import hu.bme.mit.inf.dlsreasoner.alloy.reasoner.builder.Logic2AlloyLanguageMapper;
import hu.bme.mit.inf.dlsreasoner.alloy.reasoner.builder.Logic2AlloyLanguageMapperTrace;
import hu.bme.mit.inf.dslreasoner.alloyLanguage.ALSSignatureDeclaration;
import hu.bme.mit.inf.dslreasoner.alloyLanguage.ALSTerm;
import hu.bme.mit.inf.dslreasoner.logic.model.logiclanguage.DefinedElement;
import hu.bme.mit.inf.dslreasoner.logic.model.logiclanguage.Type;
import java.util.Collection;
import java.util.List;

@SuppressWarnings("all")
public interface Logic2AlloyLanguageMapper_TypeMapper {
  void transformTypes(final Collection<Type> types, final Collection<DefinedElement> elements, final Logic2AlloyLanguageMapper mapper, final Logic2AlloyLanguageMapperTrace trace);
  
  List<ALSSignatureDeclaration> transformTypeReference(final Type referred, final Logic2AlloyLanguageMapper mapper, final Logic2AlloyLanguageMapperTrace trace);
  
  ALSSignatureDeclaration getUndefinedSupertype(final Logic2AlloyLanguageMapperTrace trace);
  
  int getUndefinedSupertypeScope(final int undefinedScope, final Logic2AlloyLanguageMapperTrace trace);
  
  ALSTerm transformReference(final DefinedElement referred, final Logic2AlloyLanguageMapperTrace trace);
  
  AlloyModelInterpretation_TypeInterpretation getTypeInterpreter();
}
