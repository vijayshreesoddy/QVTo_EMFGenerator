package hu.bme.mit.inf.dlsreasoner.alloy.reasoner.builder;

import hu.bme.mit.inf.dlsreasoner.alloy.reasoner.builder.Logic2AlloyLanguageMapper_TypeMapperTrace;
import hu.bme.mit.inf.dslreasoner.alloyLanguage.ALSDocument;
import hu.bme.mit.inf.dslreasoner.alloyLanguage.ALSEnumDeclaration;
import hu.bme.mit.inf.dslreasoner.alloyLanguage.ALSEnumLiteral;
import hu.bme.mit.inf.dslreasoner.alloyLanguage.ALSFieldDeclaration;
import hu.bme.mit.inf.dslreasoner.alloyLanguage.ALSFunctionDefinition;
import hu.bme.mit.inf.dslreasoner.alloyLanguage.ALSRelationDefinition;
import hu.bme.mit.inf.dslreasoner.alloyLanguage.ALSSignatureBody;
import hu.bme.mit.inf.dslreasoner.alloyLanguage.ALSSignatureDeclaration;
import hu.bme.mit.inf.dslreasoner.logic.model.logiclanguage.ConstantDeclaration;
import hu.bme.mit.inf.dslreasoner.logic.model.logiclanguage.ConstantDefinition;
import hu.bme.mit.inf.dslreasoner.logic.model.logiclanguage.FunctionDeclaration;
import hu.bme.mit.inf.dslreasoner.logic.model.logiclanguage.FunctionDefinition;
import hu.bme.mit.inf.dslreasoner.logic.model.logiclanguage.Relation;
import hu.bme.mit.inf.dslreasoner.logic.model.logiclanguage.RelationDeclaration;
import hu.bme.mit.inf.dslreasoner.logic.model.logiclanguage.RelationDefinition;
import java.util.HashMap;
import java.util.Map;
import org.eclipse.viatra.query.runtime.api.ViatraQueryEngine;

@SuppressWarnings("all")
public class Logic2AlloyLanguageMapperTrace {
  public ViatraQueryEngine incqueryEngine;
  
  public ALSDocument specification;
  
  public ALSSignatureDeclaration logicLanguage;
  
  public ALSSignatureBody logicLanguageBody;
  
  public ALSEnumDeclaration boolType;
  
  public ALSEnumLiteral boolTrue;
  
  public ALSEnumLiteral boolFalse;
  
  public Logic2AlloyLanguageMapper_TypeMapperTrace typeMapperTrace;
  
  public final Map<ConstantDeclaration, ALSFieldDeclaration> constantDeclaration2LanguageField = new HashMap<ConstantDeclaration, ALSFieldDeclaration>();
  
  public final Map<ConstantDefinition, ALSFunctionDefinition> constantDefinition2Function = new HashMap<ConstantDefinition, ALSFunctionDefinition>();
  
  public final Map<FunctionDeclaration, ALSFieldDeclaration> functionDeclaration2HostedField = new HashMap<FunctionDeclaration, ALSFieldDeclaration>();
  
  public final Map<FunctionDeclaration, ALSFieldDeclaration> functionDeclaration2LanguageField = new HashMap<FunctionDeclaration, ALSFieldDeclaration>();
  
  public final Map<FunctionDefinition, ALSFunctionDefinition> functionDefinition2Function = new HashMap<FunctionDefinition, ALSFunctionDefinition>();
  
  public final Map<RelationDeclaration, ALSFieldDeclaration> relationDeclaration2Global = new HashMap<RelationDeclaration, ALSFieldDeclaration>();
  
  public final Map<RelationDeclaration, ALSFieldDeclaration> relationDeclaration2Field = new HashMap<RelationDeclaration, ALSFieldDeclaration>();
  
  public final Map<RelationDefinition, ALSRelationDefinition> relationDefinition2Predicate = new HashMap<RelationDefinition, ALSRelationDefinition>();
  
  public final Map<RelationDeclaration, ALSFieldDeclaration> transitiveClosureTarget2Global = new HashMap<RelationDeclaration, ALSFieldDeclaration>();
  
  public final Map<RelationDeclaration, ALSFieldDeclaration> transitiveClosureTarget2Field = new HashMap<RelationDeclaration, ALSFieldDeclaration>();
  
  public Map<ConstantDeclaration, ConstantDefinition> constantDefinitions;
  
  public Map<FunctionDeclaration, FunctionDefinition> functionDefinitions;
  
  public Map<RelationDeclaration, RelationDefinition> relationDefinitions;
  
  public Map<Relation, ALSFieldDeclaration> relationInTransitiveToGlobalField = new HashMap<Relation, ALSFieldDeclaration>();
  
  public Map<Relation, ALSFieldDeclaration> relationInTransitiveToHosterField = new HashMap<Relation, ALSFieldDeclaration>();
}
