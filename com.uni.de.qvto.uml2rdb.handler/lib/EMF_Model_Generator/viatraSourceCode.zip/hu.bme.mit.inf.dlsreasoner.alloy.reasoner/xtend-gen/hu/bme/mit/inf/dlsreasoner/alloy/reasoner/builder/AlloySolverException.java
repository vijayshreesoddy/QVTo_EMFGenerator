package hu.bme.mit.inf.dlsreasoner.alloy.reasoner.builder;

import java.util.List;
import org.eclipse.xtext.xbase.lib.IterableExtensions;

@SuppressWarnings("all")
public class AlloySolverException extends Exception {
  public AlloySolverException(final String s) {
    super(s);
  }
  
  public AlloySolverException(final String s, final Exception e) {
    super(s, e);
  }
  
  public AlloySolverException(final String s, final List<String> errors, final Exception e) {
    super(((s + "\n") + IterableExtensions.join(errors, "\n")), e);
  }
}
