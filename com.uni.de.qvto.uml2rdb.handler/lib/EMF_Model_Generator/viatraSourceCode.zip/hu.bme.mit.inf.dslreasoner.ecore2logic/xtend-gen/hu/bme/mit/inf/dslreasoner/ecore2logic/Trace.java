package hu.bme.mit.inf.dslreasoner.ecore2logic;

@SuppressWarnings("all")
public interface Trace<Mapper extends Object> {
}
