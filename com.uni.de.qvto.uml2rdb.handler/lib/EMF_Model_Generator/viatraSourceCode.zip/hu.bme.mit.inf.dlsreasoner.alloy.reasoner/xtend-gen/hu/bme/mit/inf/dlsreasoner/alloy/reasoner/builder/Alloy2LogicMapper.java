package hu.bme.mit.inf.dlsreasoner.alloy.reasoner.builder;

import com.google.common.collect.Iterables;
import edu.mit.csail.sdg.alloy4compiler.translator.A4Solution;
import hu.bme.mit.inf.dlsreasoner.alloy.reasoner.builder.Logic2AlloyLanguageMapperTrace;
import hu.bme.mit.inf.dlsreasoner.alloy.reasoner.builder.MonitoredAlloySolution;
import hu.bme.mit.inf.dslreasoner.logic.model.logicproblem.LogicProblem;
import hu.bme.mit.inf.dslreasoner.logic.model.logicresult.InconsistencyResult;
import hu.bme.mit.inf.dslreasoner.logic.model.logicresult.InsuficientResourcesResult;
import hu.bme.mit.inf.dslreasoner.logic.model.logicresult.IntStatisticEntry;
import hu.bme.mit.inf.dslreasoner.logic.model.logicresult.LogicResult;
import hu.bme.mit.inf.dslreasoner.logic.model.logicresult.LogicresultFactory;
import hu.bme.mit.inf.dslreasoner.logic.model.logicresult.ModelResult;
import hu.bme.mit.inf.dslreasoner.logic.model.logicresult.StatisticEntry;
import hu.bme.mit.inf.dslreasoner.logic.model.logicresult.Statistics;
import hu.bme.mit.inf.dslreasoner.logic.model.logicresult.StringStatisticEntry;
import java.util.List;
import org.eclipse.emf.common.util.EList;
import org.eclipse.xtend2.lib.StringConcatenation;
import org.eclipse.xtext.xbase.lib.ExclusiveRange;
import org.eclipse.xtext.xbase.lib.Extension;
import org.eclipse.xtext.xbase.lib.Functions.Function1;
import org.eclipse.xtext.xbase.lib.Functions.Function2;
import org.eclipse.xtext.xbase.lib.IterableExtensions;
import org.eclipse.xtext.xbase.lib.ListExtensions;
import org.eclipse.xtext.xbase.lib.ObjectExtensions;
import org.eclipse.xtext.xbase.lib.Pair;
import org.eclipse.xtext.xbase.lib.Procedures.Procedure1;

@SuppressWarnings("all")
public class Alloy2LogicMapper {
  @Extension
  private final LogicresultFactory resultFactory = LogicresultFactory.eINSTANCE;
  
  public LogicResult transformOutput(final LogicProblem problem, final int requiredNumberOfSolution, final MonitoredAlloySolution monitoredAlloySolution, final Logic2AlloyLanguageMapperTrace trace, final long transformationTime) {
    final Function1<Pair<A4Solution, Long>, A4Solution> _function = (Pair<A4Solution, Long> it) -> {
      return it.getKey();
    };
    final List<A4Solution> models = IterableExtensions.<A4Solution>toList(ListExtensions.<Pair<A4Solution, Long>, A4Solution>map(monitoredAlloySolution.getAswers(), _function));
    if ((models.isEmpty() || (!monitoredAlloySolution.isFinishedBeforeTimeout()))) {
      InsuficientResourcesResult _createInsuficientResourcesResult = this.resultFactory.createInsuficientResourcesResult();
      final Procedure1<InsuficientResourcesResult> _function_1 = (InsuficientResourcesResult it) -> {
        it.setProblem(problem);
        EList<Object> _representation = it.getRepresentation();
        Iterables.<Object>addAll(_representation, models);
        it.setTrace(trace);
        it.setStatistics(this.transformStatistics(monitoredAlloySolution, transformationTime));
      };
      return ObjectExtensions.<InsuficientResourcesResult>operator_doubleArrow(_createInsuficientResourcesResult, _function_1);
    } else {
      if ((IterableExtensions.<A4Solution>last(models).satisfiable() || (requiredNumberOfSolution == (-1)))) {
        ModelResult _createModelResult = this.resultFactory.createModelResult();
        final Procedure1<ModelResult> _function_2 = (ModelResult it) -> {
          it.setProblem(problem);
          EList<Object> _representation = it.getRepresentation();
          Iterables.<Object>addAll(_representation, models);
          it.setTrace(trace);
          it.setStatistics(this.transformStatistics(monitoredAlloySolution, transformationTime));
        };
        return ObjectExtensions.<ModelResult>operator_doubleArrow(_createModelResult, _function_2);
      } else {
        InconsistencyResult _createInconsistencyResult = this.resultFactory.createInconsistencyResult();
        final Procedure1<InconsistencyResult> _function_3 = (InconsistencyResult it) -> {
          it.setProblem(problem);
          EList<Object> _representation = it.getRepresentation();
          Iterables.<Object>addAll(_representation, models);
          it.setTrace(trace);
          it.setStatistics(this.transformStatistics(monitoredAlloySolution, transformationTime));
        };
        return ObjectExtensions.<InconsistencyResult>operator_doubleArrow(_createInconsistencyResult, _function_3);
      }
    }
  }
  
  public Statistics transformStatistics(final MonitoredAlloySolution solution, final long transformationTime) {
    Statistics _createStatistics = this.resultFactory.createStatistics();
    final Procedure1<Statistics> _function = (Statistics it) -> {
      it.setTransformationTime(((int) transformationTime));
      int _size = solution.getAswers().size();
      ExclusiveRange _doubleDotLessThan = new ExclusiveRange(0, _size, true);
      for (final Integer solutionIndex : _doubleDotLessThan) {
        {
          final Long solutionTime = solution.getAswers().get((solutionIndex).intValue()).getValue();
          EList<StatisticEntry> _entries = it.getEntries();
          IntStatisticEntry _createIntStatisticEntry = this.resultFactory.createIntStatisticEntry();
          final Procedure1<IntStatisticEntry> _function_1 = (IntStatisticEntry it_1) -> {
            StringConcatenation _builder = new StringConcatenation();
            _builder.append("Answer");
            _builder.append(solutionIndex);
            _builder.append("Time");
            it_1.setName(_builder.toString());
            it_1.setValue(solutionTime.intValue());
          };
          IntStatisticEntry _doubleArrow = ObjectExtensions.<IntStatisticEntry>operator_doubleArrow(_createIntStatisticEntry, _function_1);
          _entries.add(_doubleArrow);
        }
      }
      EList<StatisticEntry> _entries = it.getEntries();
      IntStatisticEntry _createIntStatisticEntry = this.resultFactory.createIntStatisticEntry();
      final Procedure1<IntStatisticEntry> _function_1 = (IntStatisticEntry it_1) -> {
        it_1.setName("Alloy2KodKodTransformationTime");
        long _kodkodTime = solution.getKodkodTime();
        it_1.setValue(((int) _kodkodTime));
      };
      IntStatisticEntry _doubleArrow = ObjectExtensions.<IntStatisticEntry>operator_doubleArrow(_createIntStatisticEntry, _function_1);
      _entries.add(_doubleArrow);
      EList<StatisticEntry> _entries_1 = it.getEntries();
      IntStatisticEntry _createIntStatisticEntry_1 = this.resultFactory.createIntStatisticEntry();
      final Procedure1<IntStatisticEntry> _function_2 = (IntStatisticEntry it_1) -> {
        it_1.setName("Alloy2KodKodTransformationTime");
        long _kodkodTime = solution.getKodkodTime();
        it_1.setValue(((int) _kodkodTime));
      };
      IntStatisticEntry _doubleArrow_1 = ObjectExtensions.<IntStatisticEntry>operator_doubleArrow(_createIntStatisticEntry_1, _function_2);
      _entries_1.add(_doubleArrow_1);
      EList<StatisticEntry> _entries_2 = it.getEntries();
      StringStatisticEntry _createStringStatisticEntry = this.resultFactory.createStringStatisticEntry();
      final Procedure1<StringStatisticEntry> _function_3 = (StringStatisticEntry it_1) -> {
        it_1.setName("warnings");
        StringConcatenation _builder = new StringConcatenation();
        _builder.append("[");
        {
          List<String> _warnings = solution.getWarnings();
          boolean _hasElements = false;
          for(final String warning : _warnings) {
            if (!_hasElements) {
              _hasElements = true;
            } else {
              _builder.appendImmediate(",", "");
            }
            _builder.append(warning);
          }
        }
        _builder.append("]");
        it_1.setValue(_builder.toString());
      };
      StringStatisticEntry _doubleArrow_2 = ObjectExtensions.<StringStatisticEntry>operator_doubleArrow(_createStringStatisticEntry, _function_3);
      _entries_2.add(_doubleArrow_2);
    };
    return ObjectExtensions.<Statistics>operator_doubleArrow(_createStatistics, _function);
  }
  
  public Long sum(final Iterable<Long> ints) {
    final Function2<Long, Long, Long> _function = (Long p1, Long p2) -> {
      return Long.valueOf(((p1).longValue() + (p2).longValue()));
    };
    return IterableExtensions.<Long>reduce(ints, _function);
  }
}
