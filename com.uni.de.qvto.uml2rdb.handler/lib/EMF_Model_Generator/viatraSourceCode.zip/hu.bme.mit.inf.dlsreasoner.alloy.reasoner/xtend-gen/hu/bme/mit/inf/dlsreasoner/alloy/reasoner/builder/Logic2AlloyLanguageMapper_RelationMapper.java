package hu.bme.mit.inf.dlsreasoner.alloy.reasoner.builder;

import hu.bme.mit.inf.dlsreasoner.alloy.reasoner.builder.Logic2AlloyLanguageMapper;
import hu.bme.mit.inf.dlsreasoner.alloy.reasoner.builder.Logic2AlloyLanguageMapperTrace;
import hu.bme.mit.inf.dlsreasoner.alloy.reasoner.builder.Logic2AlloyLanguageMapper_Support;
import hu.bme.mit.inf.dslreasoner.alloyLanguage.ALSDirectProduct;
import hu.bme.mit.inf.dslreasoner.alloyLanguage.ALSFactDeclaration;
import hu.bme.mit.inf.dslreasoner.alloyLanguage.ALSFieldDeclaration;
import hu.bme.mit.inf.dslreasoner.alloyLanguage.ALSFunctionCall;
import hu.bme.mit.inf.dslreasoner.alloyLanguage.ALSIff;
import hu.bme.mit.inf.dslreasoner.alloyLanguage.ALSJoin;
import hu.bme.mit.inf.dslreasoner.alloyLanguage.ALSMultiplicity;
import hu.bme.mit.inf.dslreasoner.alloyLanguage.ALSQuantifiedEx;
import hu.bme.mit.inf.dslreasoner.alloyLanguage.ALSReference;
import hu.bme.mit.inf.dslreasoner.alloyLanguage.ALSRelationDefinition;
import hu.bme.mit.inf.dslreasoner.alloyLanguage.ALSSignatureBody;
import hu.bme.mit.inf.dslreasoner.alloyLanguage.ALSSignatureDeclaration;
import hu.bme.mit.inf.dslreasoner.alloyLanguage.ALSSubset;
import hu.bme.mit.inf.dslreasoner.alloyLanguage.ALSTerm;
import hu.bme.mit.inf.dslreasoner.alloyLanguage.ALSVariableDeclaration;
import hu.bme.mit.inf.dslreasoner.alloyLanguage.AlSTransitiveClosure;
import hu.bme.mit.inf.dslreasoner.alloyLanguage.AlloyLanguageFactory;
import hu.bme.mit.inf.dslreasoner.logic.model.logiclanguage.ComplexTypeReference;
import hu.bme.mit.inf.dslreasoner.logic.model.logiclanguage.Relation;
import hu.bme.mit.inf.dslreasoner.logic.model.logiclanguage.RelationDeclaration;
import hu.bme.mit.inf.dslreasoner.logic.model.logiclanguage.RelationDefinition;
import hu.bme.mit.inf.dslreasoner.logic.model.logiclanguage.Type;
import hu.bme.mit.inf.dslreasoner.logic.model.logiclanguage.TypeReference;
import hu.bme.mit.inf.dslreasoner.logic.model.logiclanguage.Variable;
import hu.bme.mit.inf.dslreasoner.util.CollectionsUtil;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import org.eclipse.emf.common.util.EList;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.xtend2.lib.StringConcatenation;
import org.eclipse.xtext.xbase.lib.Extension;
import org.eclipse.xtext.xbase.lib.IterableExtensions;
import org.eclipse.xtext.xbase.lib.ObjectExtensions;
import org.eclipse.xtext.xbase.lib.Procedures.Procedure1;

@SuppressWarnings("all")
public class Logic2AlloyLanguageMapper_RelationMapper {
  @Extension
  private final AlloyLanguageFactory factory = AlloyLanguageFactory.eINSTANCE;
  
  private final Logic2AlloyLanguageMapper_Support support = new Logic2AlloyLanguageMapper_Support();
  
  private final Logic2AlloyLanguageMapper base;
  
  public Logic2AlloyLanguageMapper_RelationMapper(final Logic2AlloyLanguageMapper base) {
    this.base = base;
  }
  
  public void _transformRelation(final RelationDeclaration r, final Logic2AlloyLanguageMapperTrace trace) {
    boolean _containsKey = trace.relationDefinitions.containsKey(r);
    boolean _not = (!_containsKey);
    if (_not) {
      boolean _transformToHostedField = this.transformToHostedField(r, trace);
      if (_transformToHostedField) {
        this.transformRelationDeclarationToHostedField(r, trace);
      } else {
        this.transformRelationDeclarationToGlobalField(r, trace);
      }
    }
  }
  
  public ALSFieldDeclaration createRelationDeclaration(final String name, final List<TypeReference> paramTypes, final Logic2AlloyLanguageMapperTrace trace) {
    ALSFieldDeclaration _createALSFieldDeclaration = this.factory.createALSFieldDeclaration();
    final Procedure1<ALSFieldDeclaration> _function = (ALSFieldDeclaration it) -> {
      it.setName(this.support.toID(name));
      it.setType(this.support.unfoldReferenceDirectProduct(this.base, paramTypes, trace));
    };
    final ALSFieldDeclaration field = ObjectExtensions.<ALSFieldDeclaration>operator_doubleArrow(_createALSFieldDeclaration, _function);
    EList<ALSFieldDeclaration> _fields = trace.logicLanguageBody.getFields();
    _fields.add(field);
    return field;
  }
  
  protected boolean transformToHostedField(final RelationDeclaration r, final Logic2AlloyLanguageMapperTrace trace) {
    final TypeReference first = r.getParameters().get(0);
    int _size = r.getParameters().size();
    boolean _equals = (_size == 2);
    if (_equals) {
      if ((first instanceof ComplexTypeReference)) {
        final List<ALSSignatureDeclaration> types = this.base.getTypeMapper().transformTypeReference(((ComplexTypeReference)first).getReferred(), this.base, trace);
        int _size_1 = types.size();
        boolean _equals_1 = (_size_1 == 1);
        if (_equals_1) {
          return true;
        }
      }
    }
    return false;
  }
  
  protected ALSFieldDeclaration transformRelationDeclarationToHostedField(final RelationDeclaration r, final Logic2AlloyLanguageMapperTrace trace) {
    ALSFieldDeclaration _xblockexpression = null;
    {
      TypeReference _head = IterableExtensions.<TypeReference>head(r.getParameters());
      final Type hostType = ((ComplexTypeReference) _head).getReferred();
      EObject _eContainer = this.base.getTypeMapper().transformTypeReference(hostType, this.base, trace).get(0).eContainer();
      final ALSSignatureBody targetBody = ((ALSSignatureBody) _eContainer);
      ALSFieldDeclaration _createALSFieldDeclaration = this.factory.createALSFieldDeclaration();
      final Procedure1<ALSFieldDeclaration> _function = (ALSFieldDeclaration it) -> {
        it.setName(this.support.toID(r.getName()));
        it.setMultiplicity(ALSMultiplicity.SET);
        it.setType(this.base.transformTypeReference(r.getParameters().get(1), trace));
      };
      final ALSFieldDeclaration field = ObjectExtensions.<ALSFieldDeclaration>operator_doubleArrow(_createALSFieldDeclaration, _function);
      EList<ALSFieldDeclaration> _fields = targetBody.getFields();
      _fields.add(field);
      _xblockexpression = trace.relationDeclaration2Field.put(r, field);
    }
    return _xblockexpression;
  }
  
  protected ALSFieldDeclaration transformRelationDeclarationToGlobalField(final RelationDeclaration r, final Logic2AlloyLanguageMapperTrace trace) {
    ALSFieldDeclaration _xblockexpression = null;
    {
      ALSFieldDeclaration _createALSFieldDeclaration = this.factory.createALSFieldDeclaration();
      final Procedure1<ALSFieldDeclaration> _function = (ALSFieldDeclaration it) -> {
        it.setName(this.support.toID(r.getName()));
        it.setType(this.support.unfoldReferenceDirectProduct(this.base, r.getParameters(), trace));
      };
      final ALSFieldDeclaration field = ObjectExtensions.<ALSFieldDeclaration>operator_doubleArrow(_createALSFieldDeclaration, _function);
      EList<ALSFieldDeclaration> _fields = trace.logicLanguageBody.getFields();
      _fields.add(field);
      _xblockexpression = trace.relationDeclaration2Global.put(r, field);
    }
    return _xblockexpression;
  }
  
  public void _transformRelation(final RelationDefinition r, final Logic2AlloyLanguageMapperTrace trace) {
    ALSRelationDefinition _createALSRelationDefinition = this.factory.createALSRelationDefinition();
    final Procedure1<ALSRelationDefinition> _function = (ALSRelationDefinition it) -> {
      it.setName(this.support.toID(r.getName()));
    };
    final ALSRelationDefinition res = ObjectExtensions.<ALSRelationDefinition>operator_doubleArrow(_createALSRelationDefinition, _function);
    trace.relationDefinition2Predicate.put(r, res);
    EList<ALSRelationDefinition> _relationDefinitions = trace.specification.getRelationDefinitions();
    _relationDefinitions.add(res);
  }
  
  protected void transformRelationDefinitionSpecification(final RelationDefinition r, final Logic2AlloyLanguageMapperTrace trace) {
    final ALSRelationDefinition predicate = CollectionsUtil.<RelationDefinition, ALSRelationDefinition>lookup(r, trace.relationDefinition2Predicate);
    if ((predicate != null)) {
      final HashMap<Variable, ALSVariableDeclaration> variableMap = new HashMap<Variable, ALSVariableDeclaration>();
      EList<Variable> _variables = r.getVariables();
      for (final Variable variable : _variables) {
        {
          ALSVariableDeclaration _createALSVariableDeclaration = this.factory.createALSVariableDeclaration();
          final Procedure1<ALSVariableDeclaration> _function = (ALSVariableDeclaration it) -> {
            it.setName(this.support.toID(variable.getName()));
            it.setRange(this.base.transformTypeReference(variable.getRange(), trace));
          };
          final ALSVariableDeclaration v = ObjectExtensions.<ALSVariableDeclaration>operator_doubleArrow(_createALSVariableDeclaration, _function);
          EList<ALSVariableDeclaration> _variables_1 = predicate.getVariables();
          _variables_1.add(v);
          variableMap.put(variable, v);
        }
      }
      predicate.setValue(this.base.transformTerm(r.getValue(), trace, variableMap));
    }
  }
  
  public ALSTerm transformRelationReference(final RelationDeclaration relation, final Logic2AlloyLanguageMapperTrace trace) {
    boolean _transformToHostedField = this.transformToHostedField(relation, trace);
    if (_transformToHostedField) {
      ALSReference _createALSReference = this.factory.createALSReference();
      final Procedure1<ALSReference> _function = (ALSReference it) -> {
        it.setReferred(CollectionsUtil.<RelationDeclaration, ALSFieldDeclaration>lookup(relation, trace.relationDeclaration2Field));
      };
      return ObjectExtensions.<ALSReference>operator_doubleArrow(_createALSReference, _function);
    } else {
      ALSJoin _createALSJoin = this.factory.createALSJoin();
      final Procedure1<ALSJoin> _function_1 = (ALSJoin it) -> {
        ALSReference _createALSReference_1 = this.factory.createALSReference();
        final Procedure1<ALSReference> _function_2 = (ALSReference it_1) -> {
          it_1.setReferred(trace.logicLanguage);
        };
        ALSReference _doubleArrow = ObjectExtensions.<ALSReference>operator_doubleArrow(_createALSReference_1, _function_2);
        it.setLeftOperand(_doubleArrow);
        ALSReference _createALSReference_2 = this.factory.createALSReference();
        final Procedure1<ALSReference> _function_3 = (ALSReference it_1) -> {
          it_1.setReferred(CollectionsUtil.<RelationDeclaration, ALSFieldDeclaration>lookup(relation, trace.relationDeclaration2Global));
        };
        ALSReference _doubleArrow_1 = ObjectExtensions.<ALSReference>operator_doubleArrow(_createALSReference_2, _function_3);
        it.setRightOperand(_doubleArrow_1);
      };
      return ObjectExtensions.<ALSJoin>operator_doubleArrow(_createALSJoin, _function_1);
    }
  }
  
  public ALSFieldDeclaration getRelationReference(final RelationDeclaration relation, final Logic2AlloyLanguageMapperTrace trace) {
    boolean _transformToHostedField = this.transformToHostedField(relation, trace);
    if (_transformToHostedField) {
      return CollectionsUtil.<RelationDeclaration, ALSFieldDeclaration>lookup(relation, trace.relationDeclaration2Field);
    } else {
      return CollectionsUtil.<RelationDeclaration, ALSFieldDeclaration>lookup(relation, trace.relationDeclaration2Global);
    }
  }
  
  public void _prepareTransitiveClosure(final RelationDeclaration relation, final Logic2AlloyLanguageMapperTrace trace) {
    boolean _transformToHostedField = this.transformToHostedField(relation, trace);
    if (_transformToHostedField) {
      trace.relationInTransitiveToHosterField.put(relation, CollectionsUtil.<RelationDeclaration, ALSFieldDeclaration>lookup(relation, trace.relationDeclaration2Field));
    } else {
      trace.relationInTransitiveToGlobalField.put(relation, CollectionsUtil.<RelationDeclaration, ALSFieldDeclaration>lookup(relation, trace.relationDeclaration2Global));
    }
  }
  
  public void _prepareTransitiveClosure(final RelationDefinition relation, final Logic2AlloyLanguageMapperTrace trace) {
    int _size = relation.getParameters().size();
    boolean _tripleEquals = (_size == 2);
    if (_tripleEquals) {
      StringConcatenation _builder = new StringConcatenation();
      _builder.append("AsDeclaration ");
      String _name = relation.getName();
      _builder.append(_name);
      final ALSFieldDeclaration declaration = this.createRelationDeclaration(this.support.toID(_builder.toString()), relation.getParameters(), trace);
      trace.relationInTransitiveToHosterField.put(relation, declaration);
      ALSFactDeclaration _createALSFactDeclaration = this.factory.createALSFactDeclaration();
      final Procedure1<ALSFactDeclaration> _function = (ALSFactDeclaration it) -> {
        StringConcatenation _builder_1 = new StringConcatenation();
        _builder_1.append("EqualsAsDeclaration ");
        String _name_1 = relation.getName();
        _builder_1.append(_name_1);
        it.setName(this.support.toID(_builder_1.toString()));
        ALSQuantifiedEx _createALSQuantifiedEx = this.factory.createALSQuantifiedEx();
        final Procedure1<ALSQuantifiedEx> _function_1 = (ALSQuantifiedEx it_1) -> {
          ALSVariableDeclaration _createALSVariableDeclaration = this.factory.createALSVariableDeclaration();
          final Procedure1<ALSVariableDeclaration> _function_2 = (ALSVariableDeclaration it_2) -> {
            it_2.setName("a");
            it_2.setRange(this.base.transformTypeReference(relation.getParameters().get(0), trace));
          };
          final ALSVariableDeclaration a = ObjectExtensions.<ALSVariableDeclaration>operator_doubleArrow(_createALSVariableDeclaration, _function_2);
          ALSVariableDeclaration _createALSVariableDeclaration_1 = this.factory.createALSVariableDeclaration();
          final Procedure1<ALSVariableDeclaration> _function_3 = (ALSVariableDeclaration it_2) -> {
            it_2.setName("b");
            it_2.setRange(this.base.transformTypeReference(relation.getParameters().get(1), trace));
          };
          final ALSVariableDeclaration b = ObjectExtensions.<ALSVariableDeclaration>operator_doubleArrow(_createALSVariableDeclaration_1, _function_3);
          EList<ALSVariableDeclaration> _variables = it_1.getVariables();
          _variables.add(a);
          EList<ALSVariableDeclaration> _variables_1 = it_1.getVariables();
          _variables_1.add(b);
          it_1.setType(ALSMultiplicity.ALL);
          ALSIff _createALSIff = this.factory.createALSIff();
          final Procedure1<ALSIff> _function_4 = (ALSIff it_2) -> {
            ALSFunctionCall _createALSFunctionCall = this.factory.createALSFunctionCall();
            final Procedure1<ALSFunctionCall> _function_5 = (ALSFunctionCall it_3) -> {
              it_3.setReferredDefinition(CollectionsUtil.<RelationDefinition, ALSRelationDefinition>lookup(relation, trace.relationDefinition2Predicate));
              EList<ALSTerm> _params = it_3.getParams();
              ALSReference _createALSReference = this.factory.createALSReference();
              final Procedure1<ALSReference> _function_6 = (ALSReference it_4) -> {
                it_4.setReferred(a);
              };
              ALSReference _doubleArrow = ObjectExtensions.<ALSReference>operator_doubleArrow(_createALSReference, _function_6);
              _params.add(_doubleArrow);
              EList<ALSTerm> _params_1 = it_3.getParams();
              ALSReference _createALSReference_1 = this.factory.createALSReference();
              final Procedure1<ALSReference> _function_7 = (ALSReference it_4) -> {
                it_4.setReferred(b);
              };
              ALSReference _doubleArrow_1 = ObjectExtensions.<ALSReference>operator_doubleArrow(_createALSReference_1, _function_7);
              _params_1.add(_doubleArrow_1);
            };
            ALSFunctionCall _doubleArrow = ObjectExtensions.<ALSFunctionCall>operator_doubleArrow(_createALSFunctionCall, _function_5);
            it_2.setLeftOperand(_doubleArrow);
            ALSSubset _createALSSubset = this.factory.createALSSubset();
            final Procedure1<ALSSubset> _function_6 = (ALSSubset it_3) -> {
              ALSDirectProduct _createALSDirectProduct = this.factory.createALSDirectProduct();
              final Procedure1<ALSDirectProduct> _function_7 = (ALSDirectProduct it_4) -> {
                ALSReference _createALSReference = this.factory.createALSReference();
                final Procedure1<ALSReference> _function_8 = (ALSReference it_5) -> {
                  it_5.setReferred(a);
                };
                ALSReference _doubleArrow_1 = ObjectExtensions.<ALSReference>operator_doubleArrow(_createALSReference, _function_8);
                it_4.setLeftOperand(_doubleArrow_1);
                ALSReference _createALSReference_1 = this.factory.createALSReference();
                final Procedure1<ALSReference> _function_9 = (ALSReference it_5) -> {
                  it_5.setReferred(b);
                };
                ALSReference _doubleArrow_2 = ObjectExtensions.<ALSReference>operator_doubleArrow(_createALSReference_1, _function_9);
                it_4.setRightOperand(_doubleArrow_2);
              };
              ALSDirectProduct _doubleArrow_1 = ObjectExtensions.<ALSDirectProduct>operator_doubleArrow(_createALSDirectProduct, _function_7);
              it_3.setLeftOperand(_doubleArrow_1);
              ALSJoin _createALSJoin = this.factory.createALSJoin();
              final Procedure1<ALSJoin> _function_8 = (ALSJoin it_4) -> {
                ALSReference _createALSReference = this.factory.createALSReference();
                final Procedure1<ALSReference> _function_9 = (ALSReference it_5) -> {
                  it_5.setReferred(trace.logicLanguage);
                };
                ALSReference _doubleArrow_2 = ObjectExtensions.<ALSReference>operator_doubleArrow(_createALSReference, _function_9);
                it_4.setLeftOperand(_doubleArrow_2);
                ALSReference _createALSReference_1 = this.factory.createALSReference();
                final Procedure1<ALSReference> _function_10 = (ALSReference it_5) -> {
                  it_5.setReferred(declaration);
                };
                ALSReference _doubleArrow_3 = ObjectExtensions.<ALSReference>operator_doubleArrow(_createALSReference_1, _function_10);
                it_4.setRightOperand(_doubleArrow_3);
              };
              ALSJoin _doubleArrow_2 = ObjectExtensions.<ALSJoin>operator_doubleArrow(_createALSJoin, _function_8);
              it_3.setRightOperand(_doubleArrow_2);
            };
            ALSSubset _doubleArrow_1 = ObjectExtensions.<ALSSubset>operator_doubleArrow(_createALSSubset, _function_6);
            it_2.setRightOperand(_doubleArrow_1);
          };
          ALSIff _doubleArrow = ObjectExtensions.<ALSIff>operator_doubleArrow(_createALSIff, _function_4);
          it_1.setExpression(_doubleArrow);
        };
        ALSQuantifiedEx _doubleArrow = ObjectExtensions.<ALSQuantifiedEx>operator_doubleArrow(_createALSQuantifiedEx, _function_1);
        it.setTerm(_doubleArrow);
      };
      final ALSFactDeclaration fact = ObjectExtensions.<ALSFactDeclaration>operator_doubleArrow(_createALSFactDeclaration, _function);
      EList<ALSFactDeclaration> _factDeclarations = trace.specification.getFactDeclarations();
      _factDeclarations.add(fact);
      return;
    } else {
      StringConcatenation _builder_1 = new StringConcatenation();
      _builder_1.append("A non-binary relation \"");
      String _name_1 = relation.getName();
      _builder_1.append(_name_1);
      _builder_1.append("\" is used in transitive clousure!");
      throw new AssertionError(_builder_1);
    }
  }
  
  public ALSSubset transformTransitiveRelationReference(final Relation relation, final ALSTerm source, final ALSTerm target, final Logic2AlloyLanguageMapperTrace trace) {
    ALSJoin _xifexpression = null;
    boolean _containsKey = trace.relationInTransitiveToGlobalField.containsKey(relation);
    if (_containsKey) {
      ALSJoin _createALSJoin = this.factory.createALSJoin();
      final Procedure1<ALSJoin> _function = (ALSJoin it) -> {
        ALSReference _createALSReference = this.factory.createALSReference();
        final Procedure1<ALSReference> _function_1 = (ALSReference it_1) -> {
          it_1.setReferred(trace.logicLanguage);
        };
        ALSReference _doubleArrow = ObjectExtensions.<ALSReference>operator_doubleArrow(_createALSReference, _function_1);
        it.setLeftOperand(_doubleArrow);
        ALSReference _createALSReference_1 = this.factory.createALSReference();
        final Procedure1<ALSReference> _function_2 = (ALSReference it_1) -> {
          it_1.setReferred(CollectionsUtil.<Relation, ALSFieldDeclaration>lookup(relation, trace.relationInTransitiveToGlobalField));
        };
        ALSReference _doubleArrow_1 = ObjectExtensions.<ALSReference>operator_doubleArrow(_createALSReference_1, _function_2);
        it.setRightOperand(_doubleArrow_1);
      };
      _xifexpression = ObjectExtensions.<ALSJoin>operator_doubleArrow(_createALSJoin, _function);
    } else {
      ALSJoin _xifexpression_1 = null;
      boolean _containsKey_1 = trace.relationInTransitiveToHosterField.containsKey(relation);
      if (_containsKey_1) {
        ALSJoin _createALSJoin_1 = this.factory.createALSJoin();
        final Procedure1<ALSJoin> _function_1 = (ALSJoin it) -> {
          ALSReference _createALSReference = this.factory.createALSReference();
          final Procedure1<ALSReference> _function_2 = (ALSReference it_1) -> {
            it_1.setReferred(trace.logicLanguage);
          };
          ALSReference _doubleArrow = ObjectExtensions.<ALSReference>operator_doubleArrow(_createALSReference, _function_2);
          it.setLeftOperand(_doubleArrow);
          ALSReference _createALSReference_1 = this.factory.createALSReference();
          final Procedure1<ALSReference> _function_3 = (ALSReference it_1) -> {
            it_1.setReferred(CollectionsUtil.<Relation, ALSFieldDeclaration>lookup(relation, trace.relationInTransitiveToHosterField));
          };
          ALSReference _doubleArrow_1 = ObjectExtensions.<ALSReference>operator_doubleArrow(_createALSReference_1, _function_3);
          it.setRightOperand(_doubleArrow_1);
        };
        _xifexpression_1 = ObjectExtensions.<ALSJoin>operator_doubleArrow(_createALSJoin_1, _function_1);
      } else {
        StringConcatenation _builder = new StringConcatenation();
        _builder.append("Relation ");
        String _name = relation.getName();
        _builder.append(_name);
        _builder.append(" is not prepared to transitive closure!");
        throw new AssertionError(_builder);
      }
      _xifexpression = _xifexpression_1;
    }
    final ALSJoin alsTargetRelation = _xifexpression;
    ALSSubset _createALSSubset = this.factory.createALSSubset();
    final Procedure1<ALSSubset> _function_2 = (ALSSubset it) -> {
      ALSDirectProduct _createALSDirectProduct = this.factory.createALSDirectProduct();
      final Procedure1<ALSDirectProduct> _function_3 = (ALSDirectProduct it_1) -> {
        it_1.setLeftOperand(source);
        it_1.setRightOperand(target);
      };
      ALSDirectProduct _doubleArrow = ObjectExtensions.<ALSDirectProduct>operator_doubleArrow(_createALSDirectProduct, _function_3);
      it.setLeftOperand(_doubleArrow);
      AlSTransitiveClosure _createAlSTransitiveClosure = this.factory.createAlSTransitiveClosure();
      final Procedure1<AlSTransitiveClosure> _function_4 = (AlSTransitiveClosure it_1) -> {
        it_1.setOperand(alsTargetRelation);
      };
      AlSTransitiveClosure _doubleArrow_1 = ObjectExtensions.<AlSTransitiveClosure>operator_doubleArrow(_createAlSTransitiveClosure, _function_4);
      it.setRightOperand(_doubleArrow_1);
    };
    return ObjectExtensions.<ALSSubset>operator_doubleArrow(_createALSSubset, _function_2);
  }
  
  public void transformRelation(final Relation r, final Logic2AlloyLanguageMapperTrace trace) {
    if (r instanceof RelationDeclaration) {
      _transformRelation((RelationDeclaration)r, trace);
      return;
    } else if (r instanceof RelationDefinition) {
      _transformRelation((RelationDefinition)r, trace);
      return;
    } else {
      throw new IllegalArgumentException("Unhandled parameter types: " +
        Arrays.<Object>asList(r, trace).toString());
    }
  }
  
  public void prepareTransitiveClosure(final Relation relation, final Logic2AlloyLanguageMapperTrace trace) {
    if (relation instanceof RelationDeclaration) {
      _prepareTransitiveClosure((RelationDeclaration)relation, trace);
      return;
    } else if (relation instanceof RelationDefinition) {
      _prepareTransitiveClosure((RelationDefinition)relation, trace);
      return;
    } else {
      throw new IllegalArgumentException("Unhandled parameter types: " +
        Arrays.<Object>asList(relation, trace).toString());
    }
  }
}
