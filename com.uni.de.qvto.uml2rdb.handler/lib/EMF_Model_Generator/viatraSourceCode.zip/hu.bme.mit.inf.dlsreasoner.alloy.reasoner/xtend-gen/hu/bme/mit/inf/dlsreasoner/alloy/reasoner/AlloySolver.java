package hu.bme.mit.inf.dlsreasoner.alloy.reasoner;

import edu.mit.csail.sdg.alloy4compiler.translator.A4Solution;
import hu.bme.mit.inf.dlsreasoner.alloy.reasoner.AlloySolverConfiguration;
import hu.bme.mit.inf.dlsreasoner.alloy.reasoner.builder.Alloy2LogicMapper;
import hu.bme.mit.inf.dlsreasoner.alloy.reasoner.builder.AlloyHandler;
import hu.bme.mit.inf.dlsreasoner.alloy.reasoner.builder.AlloyModelInterpretation;
import hu.bme.mit.inf.dlsreasoner.alloy.reasoner.builder.AlloyModelInterpretation_TypeInterpretation;
import hu.bme.mit.inf.dlsreasoner.alloy.reasoner.builder.Logic2AlloyLanguageMapper;
import hu.bme.mit.inf.dlsreasoner.alloy.reasoner.builder.Logic2AlloyLanguageMapperTrace;
import hu.bme.mit.inf.dlsreasoner.alloy.reasoner.builder.Logic2AlloyLanguageMapper_TypeMapper;
import hu.bme.mit.inf.dlsreasoner.alloy.reasoner.builder.Logic2AlloyLanguageMapper_TypeMapper_InheritanceAndHorizontal;
import hu.bme.mit.inf.dlsreasoner.alloy.reasoner.builder.MonitoredAlloySolution;
import hu.bme.mit.inf.dslreasoner.AlloyLanguageStandaloneSetupGenerated;
import hu.bme.mit.inf.dslreasoner.alloyLanguage.ALSDocument;
import hu.bme.mit.inf.dslreasoner.alloyLanguage.AlloyLanguagePackage;
import hu.bme.mit.inf.dslreasoner.logic.model.builder.DocumentationLevel;
import hu.bme.mit.inf.dslreasoner.logic.model.builder.LogicModelInterpretation;
import hu.bme.mit.inf.dslreasoner.logic.model.builder.LogicReasoner;
import hu.bme.mit.inf.dslreasoner.logic.model.builder.LogicReasonerException;
import hu.bme.mit.inf.dslreasoner.logic.model.builder.LogicSolverConfiguration;
import hu.bme.mit.inf.dslreasoner.logic.model.builder.TracedOutput;
import hu.bme.mit.inf.dslreasoner.logic.model.logicproblem.LogicProblem;
import hu.bme.mit.inf.dslreasoner.logic.model.logicresult.LogicResult;
import hu.bme.mit.inf.dslreasoner.logic.model.logicresult.ModelResult;
import hu.bme.mit.inf.dslreasoner.workspace.ReasonerWorkspace;
import java.util.List;
import org.eclipse.emf.common.util.EList;
import org.eclipse.xtend2.lib.StringConcatenation;
import org.eclipse.xtext.xbase.lib.Functions.Function1;
import org.eclipse.xtext.xbase.lib.ListExtensions;

@SuppressWarnings("all")
public class AlloySolver extends LogicReasoner {
  public AlloySolver() {
    AlloyLanguagePackage.eINSTANCE.eClass();
    final AlloyLanguageStandaloneSetupGenerated x = new AlloyLanguageStandaloneSetupGenerated();
    x.createInjectorAndDoEMFRegistration();
  }
  
  private final Logic2AlloyLanguageMapper_TypeMapper typeMapper = new Logic2AlloyLanguageMapper_TypeMapper_InheritanceAndHorizontal();
  
  private final Logic2AlloyLanguageMapper forwardMapper = new Logic2AlloyLanguageMapper(this.typeMapper);
  
  private final AlloyHandler handler = new AlloyHandler();
  
  private final Alloy2LogicMapper backwardMapper = new Alloy2LogicMapper();
  
  private final String fileName = "problem.als";
  
  @Override
  public LogicResult solve(final LogicProblem problem, final LogicSolverConfiguration configuration, final ReasonerWorkspace workspace) throws LogicReasonerException {
    final AlloySolverConfiguration alloyConfig = this.asConfig(configuration);
    final boolean writeFile = ((configuration.documentationLevel == DocumentationLevel.NORMAL) || 
      (configuration.documentationLevel == DocumentationLevel.FULL));
    final long transformationStart = System.currentTimeMillis();
    final TracedOutput<ALSDocument, Logic2AlloyLanguageMapperTrace> result = this.forwardMapper.transformProblem(problem, alloyConfig);
    final ALSDocument alloyProblem = result.getOutput();
    final Logic2AlloyLanguageMapperTrace forwardTrace = result.getTrace();
    String alloyCode = workspace.writeModelToString(alloyProblem, this.fileName);
    if (writeFile) {
      workspace.writeModel(alloyProblem, this.fileName);
    }
    long _currentTimeMillis = System.currentTimeMillis();
    final long transformationTime = (_currentTimeMillis - transformationStart);
    alloyConfig.progressMonitor.workedForwardTransformation();
    final MonitoredAlloySolution result2 = this.handler.callSolver(alloyProblem, workspace, alloyConfig, alloyCode);
    alloyConfig.progressMonitor.workedSearchFinished();
    final LogicResult logicResult = this.backwardMapper.transformOutput(problem, configuration.solutionScope.numberOfRequiredSolutions, result2, forwardTrace, transformationTime);
    alloyConfig.progressMonitor.workedBackwardTransformationFinished();
    return logicResult;
  }
  
  public AlloySolverConfiguration asConfig(final LogicSolverConfiguration configuration) {
    if ((configuration instanceof AlloySolverConfiguration)) {
      return ((AlloySolverConfiguration)configuration);
    } else {
      StringConcatenation _builder = new StringConcatenation();
      _builder.append("The configuration has to be an ");
      String _simpleName = AlloySolverConfiguration.class.getSimpleName();
      _builder.append(_simpleName);
      _builder.append("!");
      throw new IllegalArgumentException(_builder.toString());
    }
  }
  
  @Override
  public List<? extends LogicModelInterpretation> getInterpretations(final ModelResult modelResult) {
    List<AlloyModelInterpretation> _xblockexpression = null;
    {
      final EList<Object> sols = modelResult.getRepresentation();
      final Function1<Object, AlloyModelInterpretation> _function = (Object it) -> {
        AlloyModelInterpretation_TypeInterpretation _typeInterpreter = this.forwardMapper.getTypeMapper().getTypeInterpreter();
        Object _trace = modelResult.getTrace();
        return new AlloyModelInterpretation(_typeInterpreter, 
          ((A4Solution) it), 
          this.forwardMapper, 
          ((Logic2AlloyLanguageMapperTrace) _trace));
      };
      _xblockexpression = ListExtensions.<Object, AlloyModelInterpretation>map(sols, _function);
    }
    return _xblockexpression;
  }
}
