package hu.bme.mit.inf.dslreasoner.application.execution;

import com.google.inject.Binder;
import com.google.inject.binder.ScopedBindingBuilder;
import com.google.inject.multibindings.Multibinder;
import com.google.inject.name.Names;
import org.eclipse.viatra.query.patternlanguage.emf.EMFPatternLanguageRuntimeModule;
import org.eclipse.viatra.query.patternlanguage.emf.scoping.CompoundMetamodelProviderService;
import org.eclipse.viatra.query.patternlanguage.emf.scoping.EMFPatternLanguageImportNamespaceProvider;
import org.eclipse.viatra.query.patternlanguage.emf.scoping.IMetamodelProvider;
import org.eclipse.viatra.query.patternlanguage.emf.scoping.IMetamodelProviderInstance;
import org.eclipse.viatra.query.patternlanguage.emf.scoping.MetamodelProviderService;
import org.eclipse.viatra.query.patternlanguage.emf.scoping.ResourceSetMetamodelProviderService;
import org.eclipse.viatra.query.patternlanguage.emf.types.EMFTypeInferrer;
import org.eclipse.viatra.query.patternlanguage.emf.types.EMFTypeSystem;
import org.eclipse.viatra.query.patternlanguage.emf.types.ITypeInferrer;
import org.eclipse.viatra.query.patternlanguage.emf.types.ITypeSystem;
import org.eclipse.xtext.scoping.IScopeProvider;
import org.eclipse.xtext.scoping.impl.AbstractDeclarativeScopeProvider;

@SuppressWarnings("all")
public class PatternLanguageWithRSModule extends EMFPatternLanguageRuntimeModule {
  @Override
  public void configureIScopeProviderDelegate(final Binder binder) {
    binder.<IScopeProvider>bind(IScopeProvider.class).annotatedWith(Names.named(AbstractDeclarativeScopeProvider.NAMED_DELEGATE)).to(EMFPatternLanguageImportNamespaceProvider.class);
    Multibinder.<IMetamodelProviderInstance>newSetBinder(binder, IMetamodelProviderInstance.class);
  }
  
  @Override
  public Class<? extends IMetamodelProvider> bindIMetamodelProvider() {
    return CompoundMetamodelProviderService.class;
  }
  
  public ScopedBindingBuilder configureMetamodelProviderInstance(final Binder binder) {
    ScopedBindingBuilder _xblockexpression = null;
    {
      final Multibinder<IMetamodelProviderInstance> metamodelProviderBinder = Multibinder.<IMetamodelProviderInstance>newSetBinder(binder, IMetamodelProviderInstance.class);
      metamodelProviderBinder.addBinding().to(MetamodelProviderService.class);
      _xblockexpression = metamodelProviderBinder.addBinding().to(ResourceSetMetamodelProviderService.class);
    }
    return _xblockexpression;
  }
  
  @Override
  public Class<? extends ITypeSystem> bindITypeSystem() {
    return EMFTypeSystem.class;
  }
  
  @Override
  public Class<? extends ITypeInferrer> bindITypeInferrer() {
    return EMFTypeInferrer.class;
  }
}
