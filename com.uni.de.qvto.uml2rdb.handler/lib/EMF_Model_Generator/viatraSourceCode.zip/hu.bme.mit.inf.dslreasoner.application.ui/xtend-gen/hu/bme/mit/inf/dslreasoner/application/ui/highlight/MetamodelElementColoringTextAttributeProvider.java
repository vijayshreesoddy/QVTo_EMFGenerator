package hu.bme.mit.inf.dslreasoner.application.ui.highlight;

import com.google.inject.Inject;
import hu.bme.mit.inf.dslreasoner.application.ui.highlight.ApplicationConfigurationSemanticHighlightingCalculator;
import java.util.WeakHashMap;
import org.eclipse.jface.text.TextAttribute;
import org.eclipse.swt.graphics.Color;
import org.eclipse.swt.graphics.Font;
import org.eclipse.swt.graphics.RGB;
import org.eclipse.xtext.ui.editor.preferences.IPreferenceStoreAccess;
import org.eclipse.xtext.ui.editor.syntaxcoloring.IHighlightingConfiguration;
import org.eclipse.xtext.ui.editor.syntaxcoloring.PreferenceStoreAccessor;
import org.eclipse.xtext.ui.editor.syntaxcoloring.TextAttributeProvider;
import org.eclipse.xtext.ui.editor.utils.EditorUtils;
import org.eclipse.xtext.ui.editor.utils.TextStyle;

@SuppressWarnings("all")
public class MetamodelElementColoringTextAttributeProvider extends TextAttributeProvider {
  private final TextStyle defaultTextStyle = new TextStyle();
  
  private final WeakHashMap<String, TextAttribute> colorID2TextAttribute = new WeakHashMap<String, TextAttribute>();
  
  @Inject
  public MetamodelElementColoringTextAttributeProvider(final IHighlightingConfiguration highlightingConfig, final IPreferenceStoreAccess preferenceStoreAccess, final PreferenceStoreAccessor prefStoreAccessor) {
    super(highlightingConfig, preferenceStoreAccess, prefStoreAccessor);
  }
  
  @Override
  public TextAttribute getAttribute(final String id) {
    TextAttribute _xifexpression = null;
    boolean _isMetamodelElementColorID = this.isMetamodelElementColorID(id);
    if (_isMetamodelElementColorID) {
      boolean _containsKey = this.colorID2TextAttribute.containsKey(id);
      if (_containsKey) {
        return this.colorID2TextAttribute.get(id);
      } else {
        final TextAttribute style = this.metamodelElementTextStyle(id);
        this.colorID2TextAttribute.put(id, style);
        return style;
      }
    } else {
      _xifexpression = super.getAttribute(id);
    }
    return _xifexpression;
  }
  
  private boolean isMetamodelElementColorID(final String id) {
    return id.startsWith(ApplicationConfigurationSemanticHighlightingCalculator.MetamodelElementIDPrefix);
  }
  
  private TextAttribute metamodelElementTextStyle(final String id) {
    final String[] texts = id.split(" ");
    int _parseInt = Integer.parseInt(texts[1]);
    int _parseInt_1 = Integer.parseInt(texts[2]);
    int _parseInt_2 = Integer.parseInt(texts[3]);
    final RGB backgroundColor = new RGB(_parseInt, _parseInt_1, _parseInt_2);
    Color _colorFromRGB = EditorUtils.colorFromRGB(this.defaultTextStyle.getColor());
    Color _colorFromRGB_1 = EditorUtils.colorFromRGB(backgroundColor);
    int _style = this.defaultTextStyle.getStyle();
    Font _fontFromFontData = EditorUtils.fontFromFontData(this.defaultTextStyle.getFontData());
    return new TextAttribute(_colorFromRGB, _colorFromRGB_1, _style, _fontFromFontData);
  }
}
