package hu.bme.mit.inf.dslreasoner.application.execution;

import com.google.common.collect.Iterables;
import hu.bme.mit.inf.dslreasoner.application.applicationConfiguration.AllPatternEntry;
import hu.bme.mit.inf.dslreasoner.application.applicationConfiguration.ConfigurationScript;
import hu.bme.mit.inf.dslreasoner.application.applicationConfiguration.PatternElement;
import hu.bme.mit.inf.dslreasoner.application.applicationConfiguration.PatternEntry;
import hu.bme.mit.inf.dslreasoner.application.applicationConfiguration.PatternSpecification;
import hu.bme.mit.inf.dslreasoner.application.applicationConfiguration.ViatraImport;
import hu.bme.mit.inf.dslreasoner.util.CollectionsUtil;
import hu.bme.mit.inf.dslreasoner.viatra2logic.ViatraQuerySetDescriptor;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Set;
import org.eclipse.emf.common.util.EList;
import org.eclipse.emf.ecore.EAnnotation;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EClassifier;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.EPackage;
import org.eclipse.emf.ecore.EStructuralFeature;
import org.eclipse.viatra.query.patternlanguage.emf.specification.SpecificationBuilder;
import org.eclipse.viatra.query.patternlanguage.emf.vql.Annotation;
import org.eclipse.viatra.query.patternlanguage.emf.vql.CallableRelation;
import org.eclipse.viatra.query.patternlanguage.emf.vql.Constraint;
import org.eclipse.viatra.query.patternlanguage.emf.vql.PackageImport;
import org.eclipse.viatra.query.patternlanguage.emf.vql.Pattern;
import org.eclipse.viatra.query.patternlanguage.emf.vql.PatternBody;
import org.eclipse.viatra.query.patternlanguage.emf.vql.PatternCall;
import org.eclipse.viatra.query.patternlanguage.emf.vql.PatternCompositionConstraint;
import org.eclipse.viatra.query.patternlanguage.emf.vql.PatternModel;
import org.eclipse.viatra.query.runtime.api.IPatternMatch;
import org.eclipse.viatra.query.runtime.api.IQuerySpecification;
import org.eclipse.viatra.query.runtime.api.ViatraQueryMatcher;
import org.eclipse.xtext.EcoreUtil2;
import org.eclipse.xtext.xbase.lib.CollectionLiterals;
import org.eclipse.xtext.xbase.lib.Functions.Function1;
import org.eclipse.xtext.xbase.lib.IterableExtensions;
import org.eclipse.xtext.xbase.lib.ListExtensions;
import org.eclipse.xtext.xbase.lib.Pair;

@SuppressWarnings("all")
public class QueryLoader {
  private final SpecificationBuilder builder = new SpecificationBuilder();
  
  public Pair<ViatraQuerySetDescriptor, Set<Pattern>> loadQueries(final PatternSpecification specification) {
    final LinkedHashSet<Pattern> patterns = new LinkedHashSet<Pattern>();
    EList<PatternEntry> _entries = specification.getEntries();
    for (final PatternEntry entry : _entries) {
      List<Pattern> _patterns = this.getPatterns(entry);
      Iterables.<Pattern>addAll(patterns, _patterns);
    }
    final Set<Pattern> allConcernedPatterns = this.allReferredPatterns(patterns);
    final LinkedHashMap<Pattern, IQuerySpecification<?>> pattern2Specification = this.translatePatterns(allConcernedPatterns);
    final List<IQuerySpecification<?>> patternsToTranslate = IterableExtensions.<IQuerySpecification<?>>toList(pattern2Specification.values());
    final Function1<Pattern, Boolean> _function = (Pattern it) -> {
      final Function1<Annotation, Boolean> _function_1 = (Annotation it_1) -> {
        return Boolean.valueOf(it_1.getName().equals("Constraint"));
      };
      return Boolean.valueOf(IterableExtensions.<Annotation>exists(it.getAnnotations(), _function_1));
    };
    final Function1<Pattern, IQuerySpecification<?>> _function_1 = (Pattern it) -> {
      return CollectionsUtil.<Pattern, IQuerySpecification<?>>lookup(it, pattern2Specification);
    };
    final Set<IQuerySpecification<?>> validationPatterns = IterableExtensions.<IQuerySpecification<?>>toSet(IterableExtensions.<Pattern, IQuerySpecification<?>>map(IterableExtensions.<Pattern>filter(patterns, _function), _function_1));
    final Function1<Pattern, IQuerySpecification<?>> _function_2 = (Pattern it) -> {
      return CollectionsUtil.<Pattern, IQuerySpecification<?>>lookup(it, pattern2Specification);
    };
    final HashMap<IQuerySpecification<?>, EStructuralFeature> derivedFeatures = this.calculateDerivedFeatures(this.referredEcoreModels(patterns), IterableExtensions.<Pattern, IQuerySpecification<?>>map(patterns, _function_2));
    ViatraQuerySetDescriptor _viatraQuerySetDescriptor = new ViatraQuerySetDescriptor(patternsToTranslate, validationPatterns, derivedFeatures);
    return Pair.<ViatraQuerySetDescriptor, Set<Pattern>>of(_viatraQuerySetDescriptor, allConcernedPatterns);
  }
  
  protected List<Pattern> _getPatterns(final AllPatternEntry entry) {
    final Function1<PatternElement, List<Pattern>> _function = (PatternElement it) -> {
      return this.getPatterns(it);
    };
    final List<List<Pattern>> excluded = ListExtensions.<PatternElement, List<Pattern>>map(entry.getExclusuion(), _function);
    PatternModel _package = entry.getPackage();
    final Set<PatternModel> referredPatternModels = IterableExtensions.<PatternModel>toSet(this.allPatternsWithSamePackage(entry, ((PatternModel) _package)));
    final Function1<PatternModel, EList<Pattern>> _function_1 = (PatternModel it) -> {
      return it.getPatterns();
    };
    final Iterable<Pattern> patterns = Iterables.<Pattern>concat(IterableExtensions.<PatternModel, EList<Pattern>>map(referredPatternModels, _function_1));
    final Function1<Pattern, Boolean> _function_2 = (Pattern it) -> {
      boolean _contains = excluded.contains(it);
      return Boolean.valueOf((!_contains));
    };
    return IterableExtensions.<Pattern>toList(IterableExtensions.<Pattern>filter(patterns, _function_2));
  }
  
  protected List<Pattern> _getPatterns(final PatternElement entry) {
    Pattern _pattern = entry.getPattern();
    return Collections.<Pattern>unmodifiableList(CollectionLiterals.<Pattern>newArrayList(_pattern));
  }
  
  private Iterable<PatternModel> allPatternsWithSamePackage(final PatternEntry entry, final PatternModel model) {
    final String packageURI = model.getPackageName();
    final ConfigurationScript document = EcoreUtil2.<ConfigurationScript>getContainerOfType(entry, ConfigurationScript.class);
    final Function1<ViatraImport, PatternModel> _function = (ViatraImport it) -> {
      return it.getImportedViatra();
    };
    final Function1<PatternModel, Boolean> _function_1 = (PatternModel it) -> {
      return Boolean.valueOf(it.getPackageName().equals(packageURI));
    };
    final Iterable<PatternModel> viatraImportsWithSamePackage = IterableExtensions.<PatternModel>filter(IterableExtensions.<PatternModel>filterNull(IterableExtensions.<ViatraImport, PatternModel>map(Iterables.<ViatraImport>filter(document.getImports(), ViatraImport.class), _function)), _function_1);
    return viatraImportsWithSamePackage;
  }
  
  /**
   * Adds all referred patterns to a given set of patterns.
   */
  private Set<Pattern> allReferredPatterns(final Set<Pattern> patterns) {
    final LinkedHashSet<Pattern> res = new LinkedHashSet<Pattern>();
    Iterables.<Pattern>addAll(res, patterns);
    boolean changed = false;
    do {
      {
        changed = false;
        final Function1<Pattern, Set<Pattern>> _function = (Pattern it) -> {
          return this.directlyReferredPatterns(it);
        };
        final Function1<Pattern, Boolean> _function_1 = (Pattern it) -> {
          boolean _contains = res.contains(it);
          return Boolean.valueOf((!_contains));
        };
        final Iterable<Pattern> newElements = IterableExtensions.<Pattern>filter(Iterables.<Pattern>concat(IterableExtensions.<Pattern, Set<Pattern>>map(res, _function)), _function_1);
        boolean _isEmpty = IterableExtensions.isEmpty(newElements);
        boolean _not = (!_isEmpty);
        if (_not) {
          changed = true;
          Iterables.<Pattern>addAll(res, newElements);
        }
      }
    } while(changed);
    return res;
  }
  
  private Set<Pattern> directlyReferredPatterns(final Pattern pattern) {
    final Function1<PatternBody, EList<Constraint>> _function = (PatternBody it) -> {
      return it.getConstraints();
    };
    final Function1<PatternCompositionConstraint, Pattern> _function_1 = (PatternCompositionConstraint it) -> {
      CallableRelation _call = it.getCall();
      return ((PatternCall) _call).getPatternRef();
    };
    return IterableExtensions.<Pattern>toSet(IterableExtensions.<PatternCompositionConstraint, Pattern>map(Iterables.<PatternCompositionConstraint>filter((Iterables.<Constraint>concat(ListExtensions.<PatternBody, EList<Constraint>>map(pattern.getBodies(), _function))), PatternCompositionConstraint.class), _function_1));
  }
  
  private Set<EPackage> referredEcoreModels(final Set<Pattern> patterns) {
    final Function1<Pattern, PatternModel> _function = (Pattern it) -> {
      EObject _eContainer = it.eContainer();
      return ((PatternModel) _eContainer);
    };
    final Function1<PatternModel, Iterable<EPackage>> _function_1 = (PatternModel it) -> {
      final Function1<PackageImport, EPackage> _function_2 = (PackageImport it_1) -> {
        return it_1.getEPackage();
      };
      return IterableExtensions.<EPackage>filterNull(ListExtensions.<PackageImport, EPackage>map(it.getImportPackages().getPackageImport(), _function_2));
    };
    return IterableExtensions.<EPackage>toSet(Iterables.<EPackage>concat(IterableExtensions.<PatternModel, Iterable<EPackage>>map(IterableExtensions.<Pattern, PatternModel>map(patterns, _function), _function_1)));
  }
  
  private LinkedHashMap<Pattern, IQuerySpecification<?>> translatePatterns(final Set<Pattern> xtextPattern) {
    final LinkedHashMap<Pattern, IQuerySpecification<?>> res = new LinkedHashMap<Pattern, IQuerySpecification<?>>();
    final LinkedList<IQuerySpecification<?>> patterns = new LinkedList<IQuerySpecification<?>>();
    for (final Pattern pattern : xtextPattern) {
      {
        final IQuerySpecification<? extends ViatraQueryMatcher<? extends IPatternMatch>> querySpecification = this.builder.getOrCreateSpecification(pattern, patterns, true);
        res.put(pattern, querySpecification);
        patterns.add(querySpecification);
      }
    }
    return res;
  }
  
  private HashMap<IQuerySpecification<?>, EStructuralFeature> calculateDerivedFeatures(final Set<EPackage> packages, final Iterable<IQuerySpecification<?>> patterns) {
    final Function1<EPackage, EList<EClassifier>> _function = (EPackage it) -> {
      return it.getEClassifiers();
    };
    final Function1<EClass, EList<EStructuralFeature>> _function_1 = (EClass it) -> {
      return it.getEStructuralFeatures();
    };
    final Iterable<EStructuralFeature> features = Iterables.<EStructuralFeature>concat(IterableExtensions.<EClass, EList<EStructuralFeature>>map(Iterables.<EClass>filter((Iterables.<EClassifier>concat(IterableExtensions.<EPackage, EList<EClassifier>>map(packages, _function))), EClass.class), _function_1));
    final HashMap<IQuerySpecification<?>, EStructuralFeature> res = new HashMap<IQuerySpecification<?>, EStructuralFeature>();
    for (final EStructuralFeature feature : features) {
      {
        final Function1<EAnnotation, Boolean> _function_2 = (EAnnotation it) -> {
          return Boolean.valueOf(it.getSource().equals("org.eclipse.viatra.query.querybasedfeature"));
        };
        final EAnnotation QBFAnnotation = IterableExtensions.<EAnnotation>head(IterableExtensions.<EAnnotation>filter(feature.getEAnnotations(), _function_2));
        if ((QBFAnnotation != null)) {
          final String targetFQN = QBFAnnotation.getDetails().get("patternFQN");
          final Function1<IQuerySpecification<?>, Boolean> _function_3 = (IQuerySpecification<?> it) -> {
            boolean _xblockexpression = false;
            {
              final String fqn = it.getFullyQualifiedName();
              _xblockexpression = fqn.equals(targetFQN);
            }
            return Boolean.valueOf(_xblockexpression);
          };
          final IQuerySpecification<?> referredPattern = IterableExtensions.<IQuerySpecification<?>>head(IterableExtensions.<IQuerySpecification<?>>filter(patterns, _function_3));
          if ((referredPattern != null)) {
            res.put(referredPattern, feature);
          }
        }
      }
    }
    return res;
  }
  
  public List<Pattern> getPatterns(final PatternEntry entry) {
    if (entry instanceof AllPatternEntry) {
      return _getPatterns((AllPatternEntry)entry);
    } else if (entry instanceof PatternElement) {
      return _getPatterns((PatternElement)entry);
    } else {
      throw new IllegalArgumentException("Unhandled parameter types: " +
        Arrays.<Object>asList(entry).toString());
    }
  }
}
