package hu.bme.mit.inf.dlsreasoner.alloy.reasoner;

@SuppressWarnings("all")
public enum AlloyBackendSolver {
  BerkMinPIPE,
  
  SpearPIPE,
  
  MiniSatJNI,
  
  MiniSatProverJNI,
  
  LingelingJNI,
  
  PLingelingJNI,
  
  GlucoseJNI,
  
  CryptoMiniSatJNI,
  
  SAT4J,
  
  CNF,
  
  KodKod;
}
