package hu.bme.mit.inf.dlsreasoner.alloy.reasoner.builder;

import com.google.common.base.Objects;
import hu.bme.mit.inf.dlsreasoner.alloy.reasoner.builder.AlloyModelInterpretation_TypeInterpretation;
import hu.bme.mit.inf.dlsreasoner.alloy.reasoner.builder.AlloyModelInterpretation_TypeInterpretation_InheritanceAndHorizontal;
import hu.bme.mit.inf.dlsreasoner.alloy.reasoner.builder.Logic2AlloyLanguageMapper;
import hu.bme.mit.inf.dlsreasoner.alloy.reasoner.builder.Logic2AlloyLanguageMapperTrace;
import hu.bme.mit.inf.dlsreasoner.alloy.reasoner.builder.Logic2AlloyLanguageMapper_Support;
import hu.bme.mit.inf.dlsreasoner.alloy.reasoner.builder.Logic2AlloyLanguageMapper_TypeMapper;
import hu.bme.mit.inf.dlsreasoner.alloy.reasoner.builder.Logic2AlloyLanguageMapper_TypeMapperTrace;
import hu.bme.mit.inf.dlsreasoner.alloy.reasoner.builder.Logic2AlloyLanguageMapper_TypeMapperTrace_FilteredTypes;
import hu.bme.mit.inf.dlsreasoner.alloy.reasoner.builder.Logic2AlloyLanguageMapper_TypeMapperTrace_InheritanceAndHorizontal;
import hu.bme.mit.inf.dslreasoner.alloyLanguage.ALSMultiplicity;
import hu.bme.mit.inf.dslreasoner.alloyLanguage.ALSReference;
import hu.bme.mit.inf.dslreasoner.alloyLanguage.ALSSignatureBody;
import hu.bme.mit.inf.dslreasoner.alloyLanguage.ALSSignatureDeclaration;
import hu.bme.mit.inf.dslreasoner.alloyLanguage.ALSTerm;
import hu.bme.mit.inf.dslreasoner.alloyLanguage.AlloyLanguageFactory;
import hu.bme.mit.inf.dslreasoner.logic.model.logiclanguage.DefinedElement;
import hu.bme.mit.inf.dslreasoner.logic.model.logiclanguage.Type;
import hu.bme.mit.inf.dslreasoner.logic.model.logiclanguage.TypeDefinition;
import hu.bme.mit.inf.dslreasoner.logic.model.logicproblem.LogicproblemPackage;
import java.util.Collection;
import java.util.Collections;
import java.util.LinkedList;
import java.util.List;
import org.eclipse.emf.common.util.EList;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.xtend2.lib.StringConcatenation;
import org.eclipse.xtext.xbase.lib.CollectionLiterals;
import org.eclipse.xtext.xbase.lib.Extension;
import org.eclipse.xtext.xbase.lib.Functions.Function1;
import org.eclipse.xtext.xbase.lib.IterableExtensions;
import org.eclipse.xtext.xbase.lib.ObjectExtensions;
import org.eclipse.xtext.xbase.lib.Procedures.Procedure1;

@SuppressWarnings("all")
public class Logic2AlloyLanguageMapper_TypeMapper_InheritanceAndHorizontal implements Logic2AlloyLanguageMapper_TypeMapper {
  @Extension
  private final AlloyLanguageFactory factory = AlloyLanguageFactory.eINSTANCE;
  
  private final Logic2AlloyLanguageMapper_Support support = new Logic2AlloyLanguageMapper_Support();
  
  public Logic2AlloyLanguageMapper_TypeMapper_InheritanceAndHorizontal() {
    LogicproblemPackage.eINSTANCE.getClass();
  }
  
  @Override
  public void transformTypes(final Collection<Type> types, final Collection<DefinedElement> elements, final Logic2AlloyLanguageMapper mapper, final Logic2AlloyLanguageMapperTrace trace) {
    final Logic2AlloyLanguageMapper_TypeMapperTrace_InheritanceAndHorizontal typeTrace = new Logic2AlloyLanguageMapper_TypeMapperTrace_InheritanceAndHorizontal();
    trace.typeMapperTrace = typeTrace;
    ALSSignatureDeclaration _createALSSignatureDeclaration = this.factory.createALSSignatureDeclaration();
    final Procedure1<ALSSignatureDeclaration> _function = (ALSSignatureDeclaration it) -> {
      it.setName(this.support.toID(Collections.<String>unmodifiableList(CollectionLiterals.<String>newArrayList("util", "Object"))));
    };
    final ALSSignatureDeclaration objectSig = ObjectExtensions.<ALSSignatureDeclaration>operator_doubleArrow(_createALSSignatureDeclaration, _function);
    ALSSignatureBody _createALSSignatureBody = this.factory.createALSSignatureBody();
    final Procedure1<ALSSignatureBody> _function_1 = (ALSSignatureBody it) -> {
      EList<ALSSignatureDeclaration> _declarations = it.getDeclarations();
      _declarations.add(objectSig);
      it.setAbstract(true);
    };
    final ALSSignatureBody objectBody = ObjectExtensions.<ALSSignatureBody>operator_doubleArrow(_createALSSignatureBody, _function_1);
    typeTrace.objectSupperClass = objectSig;
    EList<ALSSignatureBody> _signatureBodies = trace.specification.getSignatureBodies();
    _signatureBodies.add(objectBody);
    for (final Type type : types) {
      {
        ALSSignatureDeclaration _createALSSignatureDeclaration_1 = this.factory.createALSSignatureDeclaration();
        final Procedure1<ALSSignatureDeclaration> _function_2 = (ALSSignatureDeclaration it) -> {
          it.setName(this.support.toIDMultiple("type", type.getName()));
        };
        final ALSSignatureDeclaration sig = ObjectExtensions.<ALSSignatureDeclaration>operator_doubleArrow(_createALSSignatureDeclaration_1, _function_2);
        ALSSignatureBody _createALSSignatureBody_1 = this.factory.createALSSignatureBody();
        final Procedure1<ALSSignatureBody> _function_3 = (ALSSignatureBody it) -> {
          EList<ALSSignatureDeclaration> _declarations = it.getDeclarations();
          _declarations.add(sig);
        };
        final ALSSignatureBody body = ObjectExtensions.<ALSSignatureBody>operator_doubleArrow(_createALSSignatureBody_1, _function_3);
        body.setAbstract((type.isIsAbstract() || (type instanceof TypeDefinition)));
        EList<ALSSignatureBody> _signatureBodies_1 = trace.specification.getSignatureBodies();
        _signatureBodies_1.add(body);
        typeTrace.type2ALSType.put(type, sig);
        LinkedList<ALSSignatureDeclaration> _linkedList = new LinkedList<ALSSignatureDeclaration>();
        final Procedure1<LinkedList<ALSSignatureDeclaration>> _function_4 = (LinkedList<ALSSignatureDeclaration> it) -> {
          it.add(sig);
        };
        LinkedList<ALSSignatureDeclaration> _doubleArrow = ObjectExtensions.<LinkedList<ALSSignatureDeclaration>>operator_doubleArrow(_linkedList, _function_4);
        typeTrace.typeSelection.put(type, _doubleArrow);
      }
    }
    for (final DefinedElement element : elements) {
      {
        final Function1<TypeDefinition, Boolean> _function_2 = (TypeDefinition it) -> {
          return Boolean.valueOf(it.getSubtypes().isEmpty());
        };
        final Iterable<TypeDefinition> mostSpecificTypes = IterableExtensions.<TypeDefinition>filter(element.getDefinedInType(), _function_2);
        int _size = IterableExtensions.size(mostSpecificTypes);
        boolean _equals = (_size == 1);
        if (_equals) {
          final TypeDefinition mostSpecificSubtype = IterableExtensions.<TypeDefinition>head(mostSpecificTypes);
          ALSSignatureBody _createALSSignatureBody_1 = this.factory.createALSSignatureBody();
          final Procedure1<ALSSignatureBody> _function_3 = (ALSSignatureBody it) -> {
            it.setMultiplicity(ALSMultiplicity.ONE);
            it.setSupertype(typeTrace.type2ALSType.get(mostSpecificSubtype));
          };
          final ALSSignatureBody elementContainer = ObjectExtensions.<ALSSignatureBody>operator_doubleArrow(_createALSSignatureBody_1, _function_3);
          ALSSignatureDeclaration _createALSSignatureDeclaration_1 = this.factory.createALSSignatureDeclaration();
          final Procedure1<ALSSignatureDeclaration> _function_4 = (ALSSignatureDeclaration it) -> {
            it.setName(this.support.toIDMultiple("element", element.getName()));
          };
          final ALSSignatureDeclaration signature = ObjectExtensions.<ALSSignatureDeclaration>operator_doubleArrow(_createALSSignatureDeclaration_1, _function_4);
          EList<ALSSignatureDeclaration> _declarations = elementContainer.getDeclarations();
          _declarations.add(signature);
          typeTrace.definedElement2Declaration.put(element, signature);
          EList<ALSSignatureBody> _signatureBodies_1 = trace.specification.getSignatureBodies();
          _signatureBodies_1.add(elementContainer);
        } else {
          throw new UnsupportedOperationException();
        }
      }
    }
    for (final Type type_1 : types) {
      {
        int _size = type_1.getSupertypes().size();
        boolean _equals = (_size == 0);
        if (_equals) {
          EObject _eContainer = typeTrace.type2ALSType.get(type_1).eContainer();
          ((ALSSignatureBody) _eContainer).setSupertype(typeTrace.objectSupperClass);
        }
        int _size_1 = type_1.getSupertypes().size();
        boolean _equals_1 = (_size_1 == 1);
        if (_equals_1) {
          final ALSSignatureDeclaration alsType = typeTrace.type2ALSType.get(IterableExtensions.<Type>head(type_1.getSupertypes()));
          EObject _eContainer_1 = typeTrace.type2ALSType.get(type_1).eContainer();
          ((ALSSignatureBody) _eContainer_1).setSupertype(alsType);
        } else {
          int _size_2 = type_1.getSupertypes().size();
          boolean _greaterThan = (_size_2 > 1);
          if (_greaterThan) {
            final ALSSignatureDeclaration alsMainType = typeTrace.type2ALSType.get(IterableExtensions.<Type>head(type_1.getSupertypes()));
            EObject _eContainer_2 = typeTrace.type2ALSType.get(type_1).eContainer();
            ((ALSSignatureBody) _eContainer_2).setSupertype(alsMainType);
            final Function1<Type, Boolean> _function_2 = (Type it) -> {
              return Boolean.valueOf((!Objects.equal(it, alsMainType)));
            };
            Iterable<Type> _filter = IterableExtensions.<Type>filter(type_1.getSupertypes(), _function_2);
            for (final Type otherType : _filter) {
              typeTrace.typeSelection.get(otherType).add(typeTrace.type2ALSType.get(type_1));
            }
          }
        }
      }
    }
  }
  
  private boolean hasDefinedSupertype(final Type type) {
    if ((type instanceof TypeDefinition)) {
      return true;
    } else {
      boolean _isEmpty = type.getSupertypes().isEmpty();
      if (_isEmpty) {
        return false;
      } else {
        final Function1<Type, Boolean> _function = (Type it) -> {
          return Boolean.valueOf(this.hasDefinedSupertype(it));
        };
        return IterableExtensions.<Type>exists(type.getSupertypes(), _function);
      }
    }
  }
  
  public Logic2AlloyLanguageMapper_TypeMapperTrace_InheritanceAndHorizontal getTypeTrace(final Logic2AlloyLanguageMapperTrace trace) {
    final Logic2AlloyLanguageMapper_TypeMapperTrace res = trace.typeMapperTrace;
    if ((res instanceof Logic2AlloyLanguageMapper_TypeMapperTrace_InheritanceAndHorizontal)) {
      return ((Logic2AlloyLanguageMapper_TypeMapperTrace_InheritanceAndHorizontal)res);
    } else {
      StringConcatenation _builder = new StringConcatenation();
      _builder.append("Expected type mapping trace: ");
      String _name = Logic2AlloyLanguageMapper_TypeMapperTrace_FilteredTypes.class.getName();
      _builder.append(_name);
      _builder.append(",");
      _builder.newLineIfNotEmpty();
      _builder.append("but found ");
      String _name_1 = res.getClass().getName();
      _builder.append(_name_1);
      throw new IllegalArgumentException(_builder.toString());
    }
  }
  
  @Override
  public List<ALSSignatureDeclaration> transformTypeReference(final Type referred, final Logic2AlloyLanguageMapper mapper, final Logic2AlloyLanguageMapperTrace trace) {
    return this.getTypeTrace(trace).typeSelection.get(referred);
  }
  
  @Override
  public ALSSignatureDeclaration getUndefinedSupertype(final Logic2AlloyLanguageMapperTrace trace) {
    return this.getTypeTrace(trace).objectSupperClass;
  }
  
  @Override
  public ALSTerm transformReference(final DefinedElement referred, final Logic2AlloyLanguageMapperTrace trace) {
    final ALSSignatureDeclaration r = this.getTypeTrace(trace).definedElement2Declaration.get(referred);
    ALSReference _createALSReference = this.factory.createALSReference();
    final Procedure1<ALSReference> _function = (ALSReference it) -> {
      it.setReferred(r);
    };
    return ObjectExtensions.<ALSReference>operator_doubleArrow(_createALSReference, _function);
  }
  
  @Override
  public int getUndefinedSupertypeScope(final int undefinedScope, final Logic2AlloyLanguageMapperTrace trace) {
    int _size = this.getTypeTrace(trace).definedElement2Declaration.size();
    return (undefinedScope + _size);
  }
  
  @Override
  public AlloyModelInterpretation_TypeInterpretation getTypeInterpreter() {
    return new AlloyModelInterpretation_TypeInterpretation_InheritanceAndHorizontal();
  }
}
