/**
 */
package hu.bme.mit.inf.dslreasoner.alloyLanguage;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>ALS Signature Declaration</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see hu.bme.mit.inf.dslreasoner.alloyLanguage.AlloyLanguagePackage#getALSSignatureDeclaration()
 * @model
 * @generated
 */
public interface ALSSignatureDeclaration extends ALSTypeDeclaration
{
} // ALSSignatureDeclaration
