package hu.bme.mit.inf.dslreasoner.application.ui.execute;

import java.io.File;
import java.net.URI;
import org.eclipse.core.filesystem.EFS;
import org.eclipse.core.filesystem.IFileStore;
import org.eclipse.ui.IWorkbenchPage;
import org.eclipse.ui.PlatformUI;
import org.eclipse.ui.console.IHyperlink;
import org.eclipse.ui.ide.IDE;
import org.eclipse.xtext.xbase.lib.Exceptions;

@SuppressWarnings("all")
public class ScriptConsoleFileHiperlink implements IHyperlink {
  private final URI path;
  
  public ScriptConsoleFileHiperlink(final File file) {
    this.path = file.toURI();
  }
  
  @Override
  public void linkActivated() {
    try {
      final IWorkbenchPage page = PlatformUI.getWorkbench().getActiveWorkbenchWindow().getActivePage();
      final IFileStore fileStore = EFS.getStore(this.path);
      IDE.openEditorOnFileStore(page, fileStore);
    } catch (Throwable _e) {
      throw Exceptions.sneakyThrow(_e);
    }
  }
  
  @Override
  public void linkEntered() {
  }
  
  @Override
  public void linkExited() {
  }
}
