package hu.bme.mit.inf.dslreasoner.application.execution;

import hu.bme.mit.inf.dslreasoner.workspace.ReasonerWorkspace;
import java.io.File;
import java.util.List;
import org.eclipse.emf.common.util.URI;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.resource.Resource;

@SuppressWarnings("all")
public class NullWorkspace extends ReasonerWorkspace {
  public NullWorkspace() {
    super(null, null);
  }
  
  private static final String message = "No workspace is specified!";
  
  @Override
  public ReasonerWorkspace subWorkspace(final String targetFolder, final String prefix) {
    return new NullWorkspace();
  }
  
  @Override
  public URI getWorkspaceURI() {
    throw new UnsupportedOperationException(NullWorkspace.message);
  }
  
  @Override
  public void init() {
  }
  
  @Override
  public void clear() {
  }
  
  @Override
  public void initAndClear() {
  }
  
  @Override
  protected URI getURI(final String name) {
    throw new UnsupportedOperationException(NullWorkspace.message);
  }
  
  @Override
  protected Resource getResource(final String name) {
    throw new UnsupportedOperationException(NullWorkspace.message);
  }
  
  @Override
  public URI writeModel(final EObject modelRoot, final String name) {
    return null;
  }
  
  @Override
  public String writeModelToString(final EObject modelRoot, final String name) {
    return null;
  }
  
  @Override
  public <RootType extends EObject> RootType reloadModel(final Class<RootType> type, final String name) {
    throw new UnsupportedOperationException(NullWorkspace.message);
  }
  
  @Override
  public <RootType extends EObject> RootType readModel(final Class<RootType> type, final String name) {
    throw new UnsupportedOperationException(NullWorkspace.message);
  }
  
  @Override
  public void deactivateModel(final String name) {
  }
  
  @Override
  protected void renameFile(final String name) {
  }
  
  @Override
  public List<String> allFiles() {
    throw new UnsupportedOperationException(NullWorkspace.message);
  }
  
  @Override
  public URI writeText(final String name, final CharSequence content) {
    return null;
  }
  
  @Override
  public String readText(final String name) {
    throw new UnsupportedOperationException(NullWorkspace.message);
  }
  
  @Override
  public File getFile(final String name) {
    throw new UnsupportedOperationException(NullWorkspace.message);
  }
  
  @Override
  public void refreshFile(final String name) {
  }
}
