package hu.bme.mit.inf.dslreasoner.application.execution;

import com.google.inject.Guice;
import com.google.inject.Injector;
import hu.bme.mit.inf.dslreasoner.application.execution.PatternLanguageWithRSModule;
import org.eclipse.viatra.query.patternlanguage.emf.EMFPatternLanguageStandaloneSetup;

@SuppressWarnings("all")
public class PatternLanguageWithRSSetup extends EMFPatternLanguageStandaloneSetup {
  @Override
  public Injector createInjector() {
    PatternLanguageWithRSModule _patternLanguageWithRSModule = new PatternLanguageWithRSModule();
    return Guice.createInjector(_patternLanguageWithRSModule);
  }
}
