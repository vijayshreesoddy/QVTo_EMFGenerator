package hu.bme.mit.inf.dslreasoner.application.execution;

import java.io.File;
import org.eclipse.xtend.lib.annotations.Data;
import org.eclipse.xtext.xbase.lib.Pure;
import org.eclipse.xtext.xbase.lib.util.ToStringBuilder;

@Data
@SuppressWarnings("all")
public class ScriptConsoleDecorator {
  private final String text;
  
  private final File hyperlink;
  
  private final int Red;
  
  private final int Green;
  
  private final int Blue;
  
  public ScriptConsoleDecorator(final String text) {
    this.text = text;
    this.hyperlink = null;
    this.Red = (-1);
    this.Green = (-1);
    this.Blue = (-1);
  }
  
  public ScriptConsoleDecorator(final String text, final File hyperlink) {
    this.text = text;
    this.hyperlink = hyperlink;
    this.Red = (-1);
    this.Green = (-1);
    this.Blue = (-1);
  }
  
  public ScriptConsoleDecorator(final String text, final int red, final int green, final int blue) {
    this.text = text;
    this.hyperlink = null;
    this.Red = red;
    this.Green = green;
    this.Blue = blue;
  }
  
  public ScriptConsoleDecorator(final String text, final File hyperlink, final int red, final int green, final int blue) {
    this.text = text;
    this.hyperlink = hyperlink;
    this.Red = red;
    this.Green = green;
    this.Blue = blue;
  }
  
  @Override
  @Pure
  public int hashCode() {
    final int prime = 31;
    int result = 1;
    result = prime * result + ((this.text== null) ? 0 : this.text.hashCode());
    result = prime * result + ((this.hyperlink== null) ? 0 : this.hyperlink.hashCode());
    result = prime * result + this.Red;
    result = prime * result + this.Green;
    return prime * result + this.Blue;
  }
  
  @Override
  @Pure
  public boolean equals(final Object obj) {
    if (this == obj)
      return true;
    if (obj == null)
      return false;
    if (getClass() != obj.getClass())
      return false;
    ScriptConsoleDecorator other = (ScriptConsoleDecorator) obj;
    if (this.text == null) {
      if (other.text != null)
        return false;
    } else if (!this.text.equals(other.text))
      return false;
    if (this.hyperlink == null) {
      if (other.hyperlink != null)
        return false;
    } else if (!this.hyperlink.equals(other.hyperlink))
      return false;
    if (other.Red != this.Red)
      return false;
    if (other.Green != this.Green)
      return false;
    if (other.Blue != this.Blue)
      return false;
    return true;
  }
  
  @Override
  @Pure
  public String toString() {
    ToStringBuilder b = new ToStringBuilder(this);
    b.add("text", this.text);
    b.add("hyperlink", this.hyperlink);
    b.add("Red", this.Red);
    b.add("Green", this.Green);
    b.add("Blue", this.Blue);
    return b.toString();
  }
  
  @Pure
  public String getText() {
    return this.text;
  }
  
  @Pure
  public File getHyperlink() {
    return this.hyperlink;
  }
  
  @Pure
  public int getRed() {
    return this.Red;
  }
  
  @Pure
  public int getGreen() {
    return this.Green;
  }
  
  @Pure
  public int getBlue() {
    return this.Blue;
  }
}
