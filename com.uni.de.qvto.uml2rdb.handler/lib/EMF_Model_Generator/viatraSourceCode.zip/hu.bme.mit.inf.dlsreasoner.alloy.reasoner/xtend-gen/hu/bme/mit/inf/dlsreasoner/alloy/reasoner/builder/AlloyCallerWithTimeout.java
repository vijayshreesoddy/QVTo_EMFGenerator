package hu.bme.mit.inf.dlsreasoner.alloy.reasoner.builder;

import com.google.common.base.Objects;
import edu.mit.csail.sdg.alloy4.A4Reporter;
import edu.mit.csail.sdg.alloy4compiler.ast.Command;
import edu.mit.csail.sdg.alloy4compiler.parser.CompModule;
import edu.mit.csail.sdg.alloy4compiler.translator.A4Options;
import edu.mit.csail.sdg.alloy4compiler.translator.A4Solution;
import edu.mit.csail.sdg.alloy4compiler.translator.TranslateAlloyToKodkod;
import hu.bme.mit.inf.dlsreasoner.alloy.reasoner.AlloySolverConfiguration;
import java.util.LinkedList;
import java.util.List;
import java.util.concurrent.Callable;
import org.eclipse.xtext.xbase.lib.Exceptions;
import org.eclipse.xtext.xbase.lib.Pair;

@SuppressWarnings("all")
public class AlloyCallerWithTimeout implements Callable<List<Pair<A4Solution, Long>>> {
  private final List<String> warnings;
  
  private final List<String> debugs;
  
  private final A4Reporter reporter;
  
  private final A4Options options;
  
  private final Command command;
  
  private final CompModule compModule;
  
  private final AlloySolverConfiguration configuration;
  
  private final List<Pair<A4Solution, Long>> answers = new LinkedList<Pair<A4Solution, Long>>();
  
  public AlloyCallerWithTimeout(final List<String> warnings, final List<String> debugs, final A4Reporter reporter, final A4Options options, final Command command, final CompModule compModule, final AlloySolverConfiguration configuration) {
    this.warnings = warnings;
    this.debugs = debugs;
    this.reporter = reporter;
    this.options = options;
    this.command = command;
    this.compModule = compModule;
    this.configuration = configuration;
  }
  
  @Override
  public List<Pair<A4Solution, Long>> call() throws Exception {
    final long startTime = System.currentTimeMillis();
    A4Solution lastAnswer = null;
    try {
      boolean _isCancelled = this.configuration.progressMonitor.isCancelled();
      boolean _not = (!_isCancelled);
      if (_not) {
        do {
          {
            boolean _equals = Objects.equal(lastAnswer, null);
            if (_equals) {
              lastAnswer = TranslateAlloyToKodkod.execute_command(this.reporter, this.compModule.getAllSigs(), this.command, this.options);
            } else {
              lastAnswer = lastAnswer.next();
            }
            this.configuration.progressMonitor.workedBackwardTransformation(this.configuration.solutionScope.numberOfRequiredSolutions);
            long _currentTimeMillis = System.currentTimeMillis();
            final long runtime = (_currentTimeMillis - startTime);
            synchronized (this) {
              Pair<A4Solution, Long> _mappedTo = Pair.<A4Solution, Long>of(lastAnswer, Long.valueOf(runtime));
              this.answers.add(_mappedTo);
            }
          }
        } while((((lastAnswer.satisfiable() != false) && (!this.hasEnoughSolution(this.answers))) && (!this.configuration.progressMonitor.isCancelled())));
      }
    } catch (final Throwable _t) {
      if (_t instanceof Exception) {
        final Exception e = (Exception)_t;
        String _message = e.getMessage();
        this.warnings.add(_message);
      } else {
        throw Exceptions.sneakyThrow(_t);
      }
    }
    return this.answers;
  }
  
  public boolean hasEnoughSolution(final List<?> answers) {
    if ((this.configuration.solutionScope.numberOfRequiredSolutions < 0)) {
      return false;
    } else {
      int _size = answers.size();
      return (_size == this.configuration.solutionScope.numberOfRequiredSolutions);
    }
  }
  
  public List<Pair<A4Solution, Long>> getPartialAnswers() {
    return this.answers;
  }
}
