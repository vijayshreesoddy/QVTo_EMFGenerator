package hu.bme.mit.inf.dslreasoner.ecore2logic;

@SuppressWarnings("all")
public class Ecore2LogicConfiguration {
  public boolean singleRoot = true;
  
  public int numberOfObjects = (-1);
  
  public static final int Undefined = (-1);
}
