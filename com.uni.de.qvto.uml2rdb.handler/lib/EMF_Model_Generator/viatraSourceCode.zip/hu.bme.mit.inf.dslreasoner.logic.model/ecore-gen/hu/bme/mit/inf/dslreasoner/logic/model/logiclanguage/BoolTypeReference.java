/**
 */
package hu.bme.mit.inf.dslreasoner.logic.model.logiclanguage;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Bool Type Reference</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see hu.bme.mit.inf.dslreasoner.logic.model.logiclanguage.LogiclanguagePackage#getBoolTypeReference()
 * @model
 * @generated
 */
public interface BoolTypeReference extends PrimitiveTypeReference {
} // BoolTypeReference
