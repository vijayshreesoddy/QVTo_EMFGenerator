package hu.bme.mit.inf.dlsreasoner.alloy.reasoner.builder;

import com.google.common.base.Objects;
import com.google.common.collect.Iterables;
import com.google.common.collect.Iterators;
import hu.bme.mit.inf.dlsreasoner.alloy.reasoner.AlloySolverConfiguration;
import hu.bme.mit.inf.dlsreasoner.alloy.reasoner.builder.Logic2AlloyLanguageMapperTrace;
import hu.bme.mit.inf.dlsreasoner.alloy.reasoner.builder.Logic2AlloyLanguageMapper_ConstantMapper;
import hu.bme.mit.inf.dlsreasoner.alloy.reasoner.builder.Logic2AlloyLanguageMapper_Containment;
import hu.bme.mit.inf.dlsreasoner.alloy.reasoner.builder.Logic2AlloyLanguageMapper_FunctionMapper;
import hu.bme.mit.inf.dlsreasoner.alloy.reasoner.builder.Logic2AlloyLanguageMapper_RelationMapper;
import hu.bme.mit.inf.dlsreasoner.alloy.reasoner.builder.Logic2AlloyLanguageMapper_Support;
import hu.bme.mit.inf.dlsreasoner.alloy.reasoner.builder.Logic2AlloyLanguageMapper_TypeMapper;
import hu.bme.mit.inf.dlsreasoner.alloy.reasoner.builder.RunCommandMapper;
import hu.bme.mit.inf.dslreasoner.alloyLanguage.ALSDirectProduct;
import hu.bme.mit.inf.dslreasoner.alloyLanguage.ALSDocument;
import hu.bme.mit.inf.dslreasoner.alloyLanguage.ALSEnumLiteral;
import hu.bme.mit.inf.dslreasoner.alloyLanguage.ALSEquals;
import hu.bme.mit.inf.dslreasoner.alloyLanguage.ALSFactDeclaration;
import hu.bme.mit.inf.dslreasoner.alloyLanguage.ALSFieldDeclaration;
import hu.bme.mit.inf.dslreasoner.alloyLanguage.ALSFunctionCall;
import hu.bme.mit.inf.dslreasoner.alloyLanguage.ALSFunctionDefinition;
import hu.bme.mit.inf.dslreasoner.alloyLanguage.ALSIff;
import hu.bme.mit.inf.dslreasoner.alloyLanguage.ALSImpl;
import hu.bme.mit.inf.dslreasoner.alloyLanguage.ALSInverseRelation;
import hu.bme.mit.inf.dslreasoner.alloyLanguage.ALSJoin;
import hu.bme.mit.inf.dslreasoner.alloyLanguage.ALSLeq;
import hu.bme.mit.inf.dslreasoner.alloyLanguage.ALSLess;
import hu.bme.mit.inf.dslreasoner.alloyLanguage.ALSMeq;
import hu.bme.mit.inf.dslreasoner.alloyLanguage.ALSMore;
import hu.bme.mit.inf.dslreasoner.alloyLanguage.ALSMultiplicity;
import hu.bme.mit.inf.dslreasoner.alloyLanguage.ALSNot;
import hu.bme.mit.inf.dslreasoner.alloyLanguage.ALSNumberLiteral;
import hu.bme.mit.inf.dslreasoner.alloyLanguage.ALSNumericOperator;
import hu.bme.mit.inf.dslreasoner.alloyLanguage.ALSReference;
import hu.bme.mit.inf.dslreasoner.alloyLanguage.ALSRelationDefinition;
import hu.bme.mit.inf.dslreasoner.alloyLanguage.ALSSignatureBody;
import hu.bme.mit.inf.dslreasoner.alloyLanguage.ALSSignatureDeclaration;
import hu.bme.mit.inf.dslreasoner.alloyLanguage.ALSStringLiteral;
import hu.bme.mit.inf.dslreasoner.alloyLanguage.ALSSubset;
import hu.bme.mit.inf.dslreasoner.alloyLanguage.ALSTerm;
import hu.bme.mit.inf.dslreasoner.alloyLanguage.ALSUnaryMinus;
import hu.bme.mit.inf.dslreasoner.alloyLanguage.ALSVariableDeclaration;
import hu.bme.mit.inf.dslreasoner.alloyLanguage.AlloyLanguageFactory;
import hu.bme.mit.inf.dslreasoner.ecore2logic.ecore2logicannotations.InverseRelationAssertion;
import hu.bme.mit.inf.dslreasoner.ecore2logic.ecore2logicannotations.LowerMultiplicityAssertion;
import hu.bme.mit.inf.dslreasoner.ecore2logic.ecore2logicannotations.UpperMultiplicityAssertion;
import hu.bme.mit.inf.dslreasoner.logic.model.builder.TracedOutput;
import hu.bme.mit.inf.dslreasoner.logic.model.logiclanguage.And;
import hu.bme.mit.inf.dslreasoner.logic.model.logiclanguage.Assertion;
import hu.bme.mit.inf.dslreasoner.logic.model.logiclanguage.BoolLiteral;
import hu.bme.mit.inf.dslreasoner.logic.model.logiclanguage.BoolTypeReference;
import hu.bme.mit.inf.dslreasoner.logic.model.logiclanguage.ComplexTypeReference;
import hu.bme.mit.inf.dslreasoner.logic.model.logiclanguage.Constant;
import hu.bme.mit.inf.dslreasoner.logic.model.logiclanguage.ConstantDeclaration;
import hu.bme.mit.inf.dslreasoner.logic.model.logiclanguage.ConstantDefinition;
import hu.bme.mit.inf.dslreasoner.logic.model.logiclanguage.DefinedElement;
import hu.bme.mit.inf.dslreasoner.logic.model.logiclanguage.Distinct;
import hu.bme.mit.inf.dslreasoner.logic.model.logiclanguage.Divison;
import hu.bme.mit.inf.dslreasoner.logic.model.logiclanguage.Equals;
import hu.bme.mit.inf.dslreasoner.logic.model.logiclanguage.Exists;
import hu.bme.mit.inf.dslreasoner.logic.model.logiclanguage.Forall;
import hu.bme.mit.inf.dslreasoner.logic.model.logiclanguage.Function;
import hu.bme.mit.inf.dslreasoner.logic.model.logiclanguage.FunctionDeclaration;
import hu.bme.mit.inf.dslreasoner.logic.model.logiclanguage.FunctionDefinition;
import hu.bme.mit.inf.dslreasoner.logic.model.logiclanguage.Iff;
import hu.bme.mit.inf.dslreasoner.logic.model.logiclanguage.Impl;
import hu.bme.mit.inf.dslreasoner.logic.model.logiclanguage.InstanceOf;
import hu.bme.mit.inf.dslreasoner.logic.model.logiclanguage.IntLiteral;
import hu.bme.mit.inf.dslreasoner.logic.model.logiclanguage.IntTypeReference;
import hu.bme.mit.inf.dslreasoner.logic.model.logiclanguage.LessOrEqualThan;
import hu.bme.mit.inf.dslreasoner.logic.model.logiclanguage.LessThan;
import hu.bme.mit.inf.dslreasoner.logic.model.logiclanguage.Minus;
import hu.bme.mit.inf.dslreasoner.logic.model.logiclanguage.Mod;
import hu.bme.mit.inf.dslreasoner.logic.model.logiclanguage.MoreOrEqualThan;
import hu.bme.mit.inf.dslreasoner.logic.model.logiclanguage.MoreThan;
import hu.bme.mit.inf.dslreasoner.logic.model.logiclanguage.Multiply;
import hu.bme.mit.inf.dslreasoner.logic.model.logiclanguage.Not;
import hu.bme.mit.inf.dslreasoner.logic.model.logiclanguage.Or;
import hu.bme.mit.inf.dslreasoner.logic.model.logiclanguage.Plus;
import hu.bme.mit.inf.dslreasoner.logic.model.logiclanguage.RealLiteral;
import hu.bme.mit.inf.dslreasoner.logic.model.logiclanguage.RealTypeReference;
import hu.bme.mit.inf.dslreasoner.logic.model.logiclanguage.Relation;
import hu.bme.mit.inf.dslreasoner.logic.model.logiclanguage.RelationDeclaration;
import hu.bme.mit.inf.dslreasoner.logic.model.logiclanguage.RelationDefinition;
import hu.bme.mit.inf.dslreasoner.logic.model.logiclanguage.StringLiteral;
import hu.bme.mit.inf.dslreasoner.logic.model.logiclanguage.StringTypeReference;
import hu.bme.mit.inf.dslreasoner.logic.model.logiclanguage.SymbolicDeclaration;
import hu.bme.mit.inf.dslreasoner.logic.model.logiclanguage.SymbolicValue;
import hu.bme.mit.inf.dslreasoner.logic.model.logiclanguage.Term;
import hu.bme.mit.inf.dslreasoner.logic.model.logiclanguage.TransitiveClosure;
import hu.bme.mit.inf.dslreasoner.logic.model.logiclanguage.TypeReference;
import hu.bme.mit.inf.dslreasoner.logic.model.logiclanguage.Variable;
import hu.bme.mit.inf.dslreasoner.logic.model.logicproblem.Annotation;
import hu.bme.mit.inf.dslreasoner.logic.model.logicproblem.AssertionAnnotation;
import hu.bme.mit.inf.dslreasoner.logic.model.logicproblem.ContainmentHierarchy;
import hu.bme.mit.inf.dslreasoner.logic.model.logicproblem.LogicProblem;
import hu.bme.mit.inf.dslreasoner.util.CollectionsUtil;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.function.Consumer;
import org.eclipse.emf.common.util.EList;
import org.eclipse.viatra.query.runtime.api.ViatraQueryEngine;
import org.eclipse.viatra.query.runtime.emf.EMFScope;
import org.eclipse.xtend.lib.annotations.AccessorType;
import org.eclipse.xtend.lib.annotations.Accessors;
import org.eclipse.xtend2.lib.StringConcatenation;
import org.eclipse.xtext.xbase.lib.CollectionLiterals;
import org.eclipse.xtext.xbase.lib.Extension;
import org.eclipse.xtext.xbase.lib.Functions.Function1;
import org.eclipse.xtext.xbase.lib.IntegerRange;
import org.eclipse.xtext.xbase.lib.IterableExtensions;
import org.eclipse.xtext.xbase.lib.IteratorExtensions;
import org.eclipse.xtext.xbase.lib.ListExtensions;
import org.eclipse.xtext.xbase.lib.ObjectExtensions;
import org.eclipse.xtext.xbase.lib.Procedures.Procedure1;
import org.eclipse.xtext.xbase.lib.Pure;

@SuppressWarnings("all")
public class Logic2AlloyLanguageMapper {
  @Extension
  private final AlloyLanguageFactory factory = AlloyLanguageFactory.eINSTANCE;
  
  private final Logic2AlloyLanguageMapper_Support support = new Logic2AlloyLanguageMapper_Support();
  
  private final RunCommandMapper runCommandMapper;
  
  @Accessors(AccessorType.PUBLIC_GETTER)
  private final Logic2AlloyLanguageMapper_TypeMapper typeMapper;
  
  @Accessors(AccessorType.PUBLIC_GETTER)
  private final Logic2AlloyLanguageMapper_ConstantMapper constantMapper = new Logic2AlloyLanguageMapper_ConstantMapper(this);
  
  @Accessors(AccessorType.PUBLIC_GETTER)
  private final Logic2AlloyLanguageMapper_FunctionMapper functionMapper = new Logic2AlloyLanguageMapper_FunctionMapper(this);
  
  @Accessors(AccessorType.PUBLIC_GETTER)
  private final Logic2AlloyLanguageMapper_RelationMapper relationMapper = new Logic2AlloyLanguageMapper_RelationMapper(this);
  
  @Accessors(AccessorType.PUBLIC_GETTER)
  private final Logic2AlloyLanguageMapper_Containment containmentMapper = new Logic2AlloyLanguageMapper_Containment(this);
  
  public Logic2AlloyLanguageMapper(final Logic2AlloyLanguageMapper_TypeMapper typeMapper) {
    this.typeMapper = typeMapper;
    RunCommandMapper _runCommandMapper = new RunCommandMapper(typeMapper);
    this.runCommandMapper = _runCommandMapper;
  }
  
  public TracedOutput<ALSDocument, Logic2AlloyLanguageMapperTrace> transformProblem(final LogicProblem problem, final AlloySolverConfiguration config) {
    ALSSignatureBody _createALSSignatureBody = this.factory.createALSSignatureBody();
    final Procedure1<ALSSignatureBody> _function = (ALSSignatureBody it) -> {
      it.setMultiplicity(ALSMultiplicity.ONE);
      EList<ALSSignatureDeclaration> _declarations = it.getDeclarations();
      ALSSignatureDeclaration _createALSSignatureDeclaration = this.factory.createALSSignatureDeclaration();
      final Procedure1<ALSSignatureDeclaration> _function_1 = (ALSSignatureDeclaration it_1) -> {
        it_1.setName(this.support.toID(Collections.<String>unmodifiableList(CollectionLiterals.<String>newArrayList("util", "language"))));
      };
      ALSSignatureDeclaration _doubleArrow = ObjectExtensions.<ALSSignatureDeclaration>operator_doubleArrow(_createALSSignatureDeclaration, _function_1);
      _declarations.add(_doubleArrow);
    };
    final ALSSignatureBody logicLanguage = ObjectExtensions.<ALSSignatureBody>operator_doubleArrow(_createALSSignatureBody, _function);
    ALSDocument _createALSDocument = this.factory.createALSDocument();
    final Procedure1<ALSDocument> _function_1 = (ALSDocument it) -> {
      EList<ALSSignatureBody> _signatureBodies = it.getSignatureBodies();
      _signatureBodies.add(logicLanguage);
    };
    final ALSDocument specification = ObjectExtensions.<ALSDocument>operator_doubleArrow(_createALSDocument, _function_1);
    Logic2AlloyLanguageMapperTrace _logic2AlloyLanguageMapperTrace = new Logic2AlloyLanguageMapperTrace();
    final Procedure1<Logic2AlloyLanguageMapperTrace> _function_2 = (Logic2AlloyLanguageMapperTrace it) -> {
      it.specification = specification;
      it.logicLanguage = IterableExtensions.<ALSSignatureDeclaration>head(logicLanguage.getDeclarations());
      it.logicLanguageBody = logicLanguage;
      EMFScope _eMFScope = new EMFScope(problem);
      it.incqueryEngine = ViatraQueryEngine.on(_eMFScope);
    };
    final Logic2AlloyLanguageMapperTrace trace = ObjectExtensions.<Logic2AlloyLanguageMapperTrace>operator_doubleArrow(_logic2AlloyLanguageMapperTrace, _function_2);
    this.transformRandomisation(specification, config.randomise);
    this.typeMapper.transformTypes(problem.getTypes(), problem.getElements(), this, trace);
    trace.constantDefinitions = this.collectConstantDefinitions(problem);
    trace.functionDefinitions = this.collectFunctionDefinitions(problem);
    trace.relationDefinitions = this.collectRelationDefinitions(problem);
    final Set<Relation> calledInTransitiveClosure = this.collectTransitiveRelationCalls(problem);
    final Consumer<Constant> _function_3 = (Constant it) -> {
      this.constantMapper.transformConstant(it, trace);
    };
    problem.getConstants().forEach(_function_3);
    final Consumer<Function> _function_4 = (Function it) -> {
      this.functionMapper.transformFunction(it, trace);
    };
    problem.getFunctions().forEach(_function_4);
    final Consumer<Relation> _function_5 = (Relation it) -> {
      this.relationMapper.transformRelation(it, trace);
    };
    problem.getRelations().forEach(_function_5);
    final Consumer<Relation> _function_6 = (Relation it) -> {
      this.relationMapper.prepareTransitiveClosure(it, trace);
    };
    calledInTransitiveClosure.forEach(_function_6);
    final Consumer<ConstantDefinition> _function_7 = (ConstantDefinition it) -> {
      this.constantMapper.transformConstantDefinitionSpecification(it, trace);
    };
    Iterables.<ConstantDefinition>filter(problem.getConstants(), ConstantDefinition.class).forEach(_function_7);
    final Consumer<FunctionDefinition> _function_8 = (FunctionDefinition it) -> {
      this.functionMapper.transformFunctionDefinitionSpecification(it, trace);
    };
    Iterables.<FunctionDefinition>filter(problem.getFunctions(), FunctionDefinition.class).forEach(_function_8);
    final Consumer<RelationDefinition> _function_9 = (RelationDefinition it) -> {
      this.relationMapper.transformRelationDefinitionSpecification(it, trace);
    };
    Iterables.<RelationDefinition>filter(problem.getRelations(), RelationDefinition.class).forEach(_function_9);
    final ContainmentHierarchy containment = IterableExtensions.<ContainmentHierarchy>head(problem.getContainmentHierarchies());
    if ((containment != null)) {
      this.containmentMapper.transformContainmentHierarchy(containment, trace);
    }
    final HashMap<Assertion, InverseRelationAssertion> assertion2InverseRelation = this.<InverseRelationAssertion>collectAnnotations(problem.getAnnotations(), InverseRelationAssertion.class);
    final HashMap<Assertion, UpperMultiplicityAssertion> assertion2UpperMultiplicityAssertion = this.<UpperMultiplicityAssertion>collectAnnotations(problem.getAnnotations(), UpperMultiplicityAssertion.class);
    final HashMap<Assertion, LowerMultiplicityAssertion> assertion2LowerMultiplicityAssertion = this.<LowerMultiplicityAssertion>collectAnnotations(problem.getAnnotations(), LowerMultiplicityAssertion.class);
    EList<Assertion> _assertions = problem.getAssertions();
    for (final Assertion assertion : _assertions) {
      boolean _containsKey = assertion2InverseRelation.containsKey(assertion);
      if (_containsKey) {
        this.transformInverseAssertion(CollectionsUtil.<Assertion, InverseRelationAssertion>lookup(assertion, assertion2InverseRelation), trace);
      } else {
        boolean _containsKey_1 = assertion2UpperMultiplicityAssertion.containsKey(assertion);
        if (_containsKey_1) {
          this.transformUpperMultiplicityAssertion(CollectionsUtil.<Assertion, UpperMultiplicityAssertion>lookup(assertion, assertion2UpperMultiplicityAssertion), trace);
        } else {
          boolean _containsKey_2 = assertion2LowerMultiplicityAssertion.containsKey(assertion);
          if (_containsKey_2) {
            this.transformLowerMultiplicityAssertion(CollectionsUtil.<Assertion, LowerMultiplicityAssertion>lookup(assertion, assertion2LowerMultiplicityAssertion), trace);
          } else {
            this.transformAssertion(assertion, trace);
          }
        }
      }
    }
    this.runCommandMapper.transformRunCommand(this, specification, trace, config);
    return new TracedOutput<ALSDocument, Logic2AlloyLanguageMapperTrace>(specification, trace);
  }
  
  public boolean transformRandomisation(final ALSDocument document, final int randomisation) {
    boolean _xifexpression = false;
    if ((randomisation != 0)) {
      EList<ALSSignatureBody> _signatureBodies = document.getSignatureBodies();
      ALSSignatureBody _createALSSignatureBody = this.factory.createALSSignatureBody();
      final Procedure1<ALSSignatureBody> _function = (ALSSignatureBody it) -> {
        ALSSignatureDeclaration _createALSSignatureDeclaration = this.factory.createALSSignatureDeclaration();
        final Procedure1<ALSSignatureDeclaration> _function_1 = (ALSSignatureDeclaration it_1) -> {
          it_1.setName(this.support.toID(Collections.<String>unmodifiableList(CollectionLiterals.<String>newArrayList("language", "util", "randomseed"))));
        };
        final ALSSignatureDeclaration declaration = ObjectExtensions.<ALSSignatureDeclaration>operator_doubleArrow(_createALSSignatureDeclaration, _function_1);
        EList<ALSSignatureDeclaration> _declarations = it.getDeclarations();
        _declarations.add(declaration);
        it.setMultiplicity(ALSMultiplicity.ONE);
        IntegerRange _upTo = new IntegerRange(1, randomisation);
        for (final Integer i : _upTo) {
          EList<ALSFieldDeclaration> _fields = it.getFields();
          ALSFieldDeclaration _createALSFieldDeclaration = this.factory.createALSFieldDeclaration();
          final Procedure1<ALSFieldDeclaration> _function_2 = (ALSFieldDeclaration it_1) -> {
            String _string = i.toString();
            it_1.setName(this.support.toID(Collections.<String>unmodifiableList(CollectionLiterals.<String>newArrayList("language", "util", "randomseedField", _string))));
            it_1.setMultiplicity(ALSMultiplicity.ONE);
            ALSReference _createALSReference = this.factory.createALSReference();
            final Procedure1<ALSReference> _function_3 = (ALSReference it_2) -> {
              it_2.setReferred(declaration);
            };
            ALSReference _doubleArrow = ObjectExtensions.<ALSReference>operator_doubleArrow(_createALSReference, _function_3);
            it_1.setType(_doubleArrow);
          };
          ALSFieldDeclaration _doubleArrow = ObjectExtensions.<ALSFieldDeclaration>operator_doubleArrow(_createALSFieldDeclaration, _function_2);
          _fields.add(_doubleArrow);
        }
      };
      ALSSignatureBody _doubleArrow = ObjectExtensions.<ALSSignatureBody>operator_doubleArrow(_createALSSignatureBody, _function);
      _xifexpression = _signatureBodies.add(_doubleArrow);
    }
    return _xifexpression;
  }
  
  public boolean transformInverseAssertion(final InverseRelationAssertion assertion, final Logic2AlloyLanguageMapperTrace trace) {
    boolean _xblockexpression = false;
    {
      final Relation a = assertion.getInverseA();
      final Relation b = assertion.getInverseB();
      boolean _xifexpression = false;
      if (((((a instanceof RelationDeclaration) && (b instanceof RelationDeclaration)) && 
        (!trace.relationDefinitions.containsKey(a))) && (!trace.relationDefinitions.containsKey(b)))) {
        boolean _xblockexpression_1 = false;
        {
          ALSFactDeclaration _createALSFactDeclaration = this.factory.createALSFactDeclaration();
          final Procedure1<ALSFactDeclaration> _function = (ALSFactDeclaration it) -> {
            it.setName(this.support.toID(assertion.getTarget().getName()));
            ALSEquals _createALSEquals = this.factory.createALSEquals();
            final Procedure1<ALSEquals> _function_1 = (ALSEquals it_1) -> {
              it_1.setLeftOperand(this.relationMapper.transformRelationReference(((RelationDeclaration) a), trace));
              ALSInverseRelation _createALSInverseRelation = this.factory.createALSInverseRelation();
              final Procedure1<ALSInverseRelation> _function_2 = (ALSInverseRelation it_2) -> {
                it_2.setOperand(this.relationMapper.transformRelationReference(((RelationDeclaration) b), trace));
              };
              ALSInverseRelation _doubleArrow = ObjectExtensions.<ALSInverseRelation>operator_doubleArrow(_createALSInverseRelation, _function_2);
              it_1.setRightOperand(_doubleArrow);
            };
            ALSEquals _doubleArrow = ObjectExtensions.<ALSEquals>operator_doubleArrow(_createALSEquals, _function_1);
            it.setTerm(_doubleArrow);
          };
          final ALSFactDeclaration fact = ObjectExtensions.<ALSFactDeclaration>operator_doubleArrow(_createALSFactDeclaration, _function);
          EList<ALSFactDeclaration> _factDeclarations = trace.specification.getFactDeclarations();
          _xblockexpression_1 = _factDeclarations.add(fact);
        }
        _xifexpression = _xblockexpression_1;
      } else {
        return this.transformAssertion(assertion.getTarget(), trace);
      }
      _xblockexpression = _xifexpression;
    }
    return _xblockexpression;
  }
  
  public boolean transformUpperMultiplicityAssertion(final UpperMultiplicityAssertion assertion, final Logic2AlloyLanguageMapperTrace trace) {
    final Relation x = assertion.getRelation();
    if (((x instanceof RelationDeclaration) && (!trace.relationDefinitions.containsKey(x)))) {
      final ALSFieldDeclaration relation = this.relationMapper.getRelationReference(((RelationDeclaration) x), trace);
      final ALSTerm type = relation.getType();
      int _upper = assertion.getUpper();
      boolean _tripleEquals = (_upper == 1);
      if (_tripleEquals) {
        if ((type instanceof ALSDirectProduct)) {
          ((ALSDirectProduct)type).setRightMultiplicit(this.addUpper(((ALSDirectProduct)type).getRightMultiplicit()));
        } else {
          relation.setMultiplicity(this.addUpper(relation.getMultiplicity()));
        }
        return true;
      } else {
        return this.transformAssertion(assertion.getTarget(), trace);
      }
    } else {
      return this.transformAssertion(assertion.getTarget(), trace);
    }
  }
  
  public boolean transformLowerMultiplicityAssertion(final LowerMultiplicityAssertion assertion, final Logic2AlloyLanguageMapperTrace trace) {
    final Relation x = assertion.getRelation();
    if (((x instanceof RelationDeclaration) && (!trace.relationDefinitions.containsKey(x)))) {
      final ALSFieldDeclaration relation = this.relationMapper.getRelationReference(((RelationDeclaration) x), trace);
      final ALSTerm type = relation.getType();
      if ((type instanceof ALSDirectProduct)) {
        ((ALSDirectProduct)type).setRightMultiplicit(this.addLower(((ALSDirectProduct)type).getRightMultiplicit()));
      } else {
        relation.setMultiplicity(this.addLower(relation.getMultiplicity()));
      }
      int _lower = assertion.getLower();
      boolean _tripleEquals = (_lower == 1);
      if (_tripleEquals) {
        return true;
      } else {
        return this.transformAssertion(assertion.getTarget(), trace);
      }
    } else {
      return this.transformAssertion(assertion.getTarget(), trace);
    }
  }
  
  private ALSMultiplicity addLower(final ALSMultiplicity multiplicity) {
    if (((multiplicity == ALSMultiplicity.SET) || (multiplicity == null))) {
      return ALSMultiplicity.SOME;
    } else {
      if ((multiplicity == ALSMultiplicity.LONE)) {
        return ALSMultiplicity.ONE;
      } else {
        boolean _equals = Objects.equal(multiplicity, ALSMultiplicity.ONE);
        if (_equals) {
          return ALSMultiplicity.ONE;
        } else {
          StringConcatenation _builder = new StringConcatenation();
          _builder.append("Lower multiplicity is already set!");
          throw new IllegalArgumentException(_builder.toString());
        }
      }
    }
  }
  
  private ALSMultiplicity addUpper(final ALSMultiplicity multiplicity) {
    if ((multiplicity == ALSMultiplicity.ALL)) {
      return ALSMultiplicity.LONE;
    } else {
      if (((multiplicity == ALSMultiplicity.SET) || (multiplicity == null))) {
        return ALSMultiplicity.LONE;
      } else {
        if ((multiplicity == ALSMultiplicity.SOME)) {
          return ALSMultiplicity.ONE;
        } else {
          boolean _equals = Objects.equal(multiplicity, ALSMultiplicity.ONE);
          if (_equals) {
            return ALSMultiplicity.ONE;
          } else {
            StringConcatenation _builder = new StringConcatenation();
            _builder.append("Upper multiplicity is already set!");
            throw new IllegalArgumentException(_builder.toString());
          }
        }
      }
    }
  }
  
  private <T extends AssertionAnnotation> HashMap<Assertion, T> collectAnnotations(final Collection<? extends Annotation> collection, final Class<T> annotationKind) {
    final HashMap<Assertion, T> res = new HashMap<Assertion, T>();
    final Consumer<T> _function = (T it) -> {
      res.put(it.getTarget(), it);
    };
    Iterables.<T>filter(collection, annotationKind).forEach(_function);
    return res;
  }
  
  private HashMap<ConstantDeclaration, ConstantDefinition> collectConstantDefinitions(final LogicProblem problem) {
    final HashMap<ConstantDeclaration, ConstantDefinition> res = new HashMap<ConstantDeclaration, ConstantDefinition>();
    final Function1<ConstantDefinition, Boolean> _function = (ConstantDefinition it) -> {
      ConstantDeclaration _defines = it.getDefines();
      return Boolean.valueOf((_defines != null));
    };
    final Consumer<ConstantDefinition> _function_1 = (ConstantDefinition it) -> {
      res.put(it.getDefines(), it);
    };
    IterableExtensions.<ConstantDefinition>filter(Iterables.<ConstantDefinition>filter(problem.getConstants(), ConstantDefinition.class), _function).forEach(_function_1);
    return res;
  }
  
  private HashMap<FunctionDeclaration, FunctionDefinition> collectFunctionDefinitions(final LogicProblem problem) {
    final HashMap<FunctionDeclaration, FunctionDefinition> res = new HashMap<FunctionDeclaration, FunctionDefinition>();
    final Function1<FunctionDefinition, Boolean> _function = (FunctionDefinition it) -> {
      FunctionDeclaration _defines = it.getDefines();
      return Boolean.valueOf((_defines != null));
    };
    final Consumer<FunctionDefinition> _function_1 = (FunctionDefinition it) -> {
      res.put(it.getDefines(), it);
    };
    IterableExtensions.<FunctionDefinition>filter(Iterables.<FunctionDefinition>filter(problem.getFunctions(), FunctionDefinition.class), _function).forEach(_function_1);
    return res;
  }
  
  private HashMap<RelationDeclaration, RelationDefinition> collectRelationDefinitions(final LogicProblem problem) {
    final HashMap<RelationDeclaration, RelationDefinition> res = new HashMap<RelationDeclaration, RelationDefinition>();
    final Function1<RelationDefinition, Boolean> _function = (RelationDefinition it) -> {
      RelationDeclaration _defines = it.getDefines();
      return Boolean.valueOf((_defines != null));
    };
    final Consumer<RelationDefinition> _function_1 = (RelationDefinition it) -> {
      res.put(it.getDefines(), it);
    };
    IterableExtensions.<RelationDefinition>filter(Iterables.<RelationDefinition>filter(problem.getRelations(), RelationDefinition.class), _function).forEach(_function_1);
    return res;
  }
  
  private Set<Relation> collectTransitiveRelationCalls(final LogicProblem problem) {
    final Function1<TransitiveClosure, Relation> _function = (TransitiveClosure it) -> {
      return it.getRelation();
    };
    return IteratorExtensions.<Relation>toSet(IteratorExtensions.<TransitiveClosure, Relation>map(Iterators.<TransitiveClosure>filter(problem.eAllContents(), TransitiveClosure.class), _function));
  }
  
  protected ALSTerm _transformTypeReference(final BoolTypeReference boolTypeReference, final Logic2AlloyLanguageMapperTrace trace) {
    ALSReference _createALSReference = this.factory.createALSReference();
    final Procedure1<ALSReference> _function = (ALSReference it) -> {
      it.setReferred(this.support.getBooleanType(trace));
    };
    return ObjectExtensions.<ALSReference>operator_doubleArrow(_createALSReference, _function);
  }
  
  protected ALSTerm _transformTypeReference(final IntTypeReference intTypeReference, final Logic2AlloyLanguageMapperTrace trace) {
    return this.factory.createALSInt();
  }
  
  protected ALSTerm _transformTypeReference(final RealTypeReference realTypeReference, final Logic2AlloyLanguageMapperTrace trace) {
    return this.factory.createALSInt();
  }
  
  protected ALSTerm _transformTypeReference(final StringTypeReference stringTypeReference, final Logic2AlloyLanguageMapperTrace trace) {
    return this.factory.createALSString();
  }
  
  protected ALSTerm _transformTypeReference(final ComplexTypeReference complexTypeReference, final Logic2AlloyLanguageMapperTrace trace) {
    final List<ALSSignatureDeclaration> types = this.typeMapper.transformTypeReference(complexTypeReference.getReferred(), this, trace);
    final Function1<ALSSignatureDeclaration, ALSReference> _function = (ALSSignatureDeclaration t) -> {
      ALSReference _createALSReference = this.factory.createALSReference();
      final Procedure1<ALSReference> _function_1 = (ALSReference it) -> {
        it.setReferred(t);
      };
      return ObjectExtensions.<ALSReference>operator_doubleArrow(_createALSReference, _function_1);
    };
    return this.support.unfoldPlus(ListExtensions.<ALSSignatureDeclaration, ALSReference>map(types, _function));
  }
  
  protected boolean transformAssertion(final Assertion assertion, final Logic2AlloyLanguageMapperTrace trace) {
    boolean _xblockexpression = false;
    {
      ALSFactDeclaration _createALSFactDeclaration = this.factory.createALSFactDeclaration();
      final Procedure1<ALSFactDeclaration> _function = (ALSFactDeclaration it) -> {
        it.setName(this.support.toID(assertion.getName()));
        it.setTerm(this.transformTerm(assertion.getValue(), trace, Collections.EMPTY_MAP));
      };
      final ALSFactDeclaration res = ObjectExtensions.<ALSFactDeclaration>operator_doubleArrow(_createALSFactDeclaration, _function);
      EList<ALSFactDeclaration> _factDeclarations = trace.specification.getFactDeclarations();
      _xblockexpression = _factDeclarations.add(res);
    }
    return _xblockexpression;
  }
  
  protected ALSTerm _transformTerm(final BoolLiteral literal, final Logic2AlloyLanguageMapperTrace trace, final Map<Variable, ALSVariableDeclaration> variables) {
    ALSEnumLiteral ref = null;
    boolean _isValue = literal.isValue();
    boolean _equals = (_isValue == true);
    if (_equals) {
      ref = this.support.getBooleanTrue(trace);
    } else {
      ref = this.support.getBooleanFalse(trace);
    }
    final ALSEnumLiteral refFinal = ref;
    ALSReference _createALSReference = this.factory.createALSReference();
    final Procedure1<ALSReference> _function = (ALSReference it) -> {
      it.setReferred(refFinal);
    };
    ALSReference _doubleArrow = ObjectExtensions.<ALSReference>operator_doubleArrow(_createALSReference, _function);
    return this.support.booleanToLogicValue(_doubleArrow, trace);
  }
  
  protected ALSTerm _transformTerm(final RealLiteral literal, final Logic2AlloyLanguageMapperTrace trace, final Map<Variable, ALSVariableDeclaration> variables) {
    ALSTerm _xblockexpression = null;
    {
      final int v = literal.getValue().intValue();
      ALSTerm _xifexpression = null;
      if ((v >= 0)) {
        ALSNumberLiteral _createALSNumberLiteral = this.factory.createALSNumberLiteral();
        final Procedure1<ALSNumberLiteral> _function = (ALSNumberLiteral it) -> {
          it.setValue(v);
        };
        _xifexpression = ObjectExtensions.<ALSNumberLiteral>operator_doubleArrow(_createALSNumberLiteral, _function);
      } else {
        ALSUnaryMinus _createALSUnaryMinus = this.factory.createALSUnaryMinus();
        final Procedure1<ALSUnaryMinus> _function_1 = (ALSUnaryMinus it) -> {
          ALSNumberLiteral _createALSNumberLiteral_1 = this.factory.createALSNumberLiteral();
          final Procedure1<ALSNumberLiteral> _function_2 = (ALSNumberLiteral it_1) -> {
            it_1.setValue(v);
          };
          ALSNumberLiteral _doubleArrow = ObjectExtensions.<ALSNumberLiteral>operator_doubleArrow(_createALSNumberLiteral_1, _function_2);
          it.setOperand(_doubleArrow);
        };
        _xifexpression = ObjectExtensions.<ALSUnaryMinus>operator_doubleArrow(_createALSUnaryMinus, _function_1);
      }
      _xblockexpression = _xifexpression;
    }
    return _xblockexpression;
  }
  
  protected ALSTerm _transformTerm(final IntLiteral literal, final Logic2AlloyLanguageMapperTrace trace, final Map<Variable, ALSVariableDeclaration> variables) {
    ALSTerm _xifexpression = null;
    int _value = literal.getValue();
    boolean _greaterEqualsThan = (_value >= 0);
    if (_greaterEqualsThan) {
      ALSNumberLiteral _createALSNumberLiteral = this.factory.createALSNumberLiteral();
      final Procedure1<ALSNumberLiteral> _function = (ALSNumberLiteral it) -> {
        it.setValue(literal.getValue());
      };
      _xifexpression = ObjectExtensions.<ALSNumberLiteral>operator_doubleArrow(_createALSNumberLiteral, _function);
    } else {
      ALSUnaryMinus _createALSUnaryMinus = this.factory.createALSUnaryMinus();
      final Procedure1<ALSUnaryMinus> _function_1 = (ALSUnaryMinus it) -> {
        ALSNumberLiteral _createALSNumberLiteral_1 = this.factory.createALSNumberLiteral();
        final Procedure1<ALSNumberLiteral> _function_2 = (ALSNumberLiteral it_1) -> {
          it_1.setValue(literal.getValue());
        };
        ALSNumberLiteral _doubleArrow = ObjectExtensions.<ALSNumberLiteral>operator_doubleArrow(_createALSNumberLiteral_1, _function_2);
        it.setOperand(_doubleArrow);
      };
      _xifexpression = ObjectExtensions.<ALSUnaryMinus>operator_doubleArrow(_createALSUnaryMinus, _function_1);
    }
    return _xifexpression;
  }
  
  protected ALSTerm _transformTerm(final StringLiteral literal, final Logic2AlloyLanguageMapperTrace trace, final Map<Variable, ALSVariableDeclaration> variables) {
    ALSStringLiteral _createALSStringLiteral = this.factory.createALSStringLiteral();
    final Procedure1<ALSStringLiteral> _function = (ALSStringLiteral it) -> {
      it.setValue(literal.getValue());
    };
    return ObjectExtensions.<ALSStringLiteral>operator_doubleArrow(_createALSStringLiteral, _function);
  }
  
  protected ALSTerm _transformTerm(final Not not, final Logic2AlloyLanguageMapperTrace trace, final Map<Variable, ALSVariableDeclaration> variables) {
    ALSNot _createALSNot = this.factory.createALSNot();
    final Procedure1<ALSNot> _function = (ALSNot it) -> {
      it.setOperand(this.transformTerm(not.getOperand(), trace, variables));
    };
    return ObjectExtensions.<ALSNot>operator_doubleArrow(_createALSNot, _function);
  }
  
  protected ALSTerm _transformTerm(final And and, final Logic2AlloyLanguageMapperTrace trace, final Map<Variable, ALSVariableDeclaration> variables) {
    final Function1<Term, ALSTerm> _function = (Term it) -> {
      return this.transformTerm(it, trace, variables);
    };
    return this.support.unfoldAnd(ListExtensions.<Term, ALSTerm>map(and.getOperands(), _function));
  }
  
  protected ALSTerm _transformTerm(final Or or, final Logic2AlloyLanguageMapperTrace trace, final Map<Variable, ALSVariableDeclaration> variables) {
    final Function1<Term, ALSTerm> _function = (Term it) -> {
      return this.transformTerm(it, trace, variables);
    };
    return this.support.unfoldOr(ListExtensions.<Term, ALSTerm>map(or.getOperands(), _function), trace);
  }
  
  protected ALSTerm _transformTerm(final Impl impl, final Logic2AlloyLanguageMapperTrace trace, final Map<Variable, ALSVariableDeclaration> variables) {
    ALSImpl _createALSImpl = this.factory.createALSImpl();
    final Procedure1<ALSImpl> _function = (ALSImpl it) -> {
      it.setLeftOperand(this.transformTerm(impl.getLeftOperand(), trace, variables));
      it.setRightOperand(this.transformTerm(impl.getRightOperand(), trace, variables));
    };
    return ObjectExtensions.<ALSImpl>operator_doubleArrow(_createALSImpl, _function);
  }
  
  protected ALSTerm _transformTerm(final Iff iff, final Logic2AlloyLanguageMapperTrace trace, final Map<Variable, ALSVariableDeclaration> variables) {
    ALSIff _createALSIff = this.factory.createALSIff();
    final Procedure1<ALSIff> _function = (ALSIff it) -> {
      it.setLeftOperand(this.transformTerm(iff.getLeftOperand(), trace, variables));
      it.setRightOperand(this.transformTerm(iff.getRightOperand(), trace, variables));
    };
    return ObjectExtensions.<ALSIff>operator_doubleArrow(_createALSIff, _function);
  }
  
  protected ALSTerm _transformTerm(final MoreThan moreThan, final Logic2AlloyLanguageMapperTrace trace, final Map<Variable, ALSVariableDeclaration> variables) {
    ALSMore _createALSMore = this.factory.createALSMore();
    final Procedure1<ALSMore> _function = (ALSMore it) -> {
      it.setLeftOperand(this.transformTerm(moreThan.getLeftOperand(), trace, variables));
      it.setRightOperand(this.transformTerm(moreThan.getRightOperand(), trace, variables));
    };
    return ObjectExtensions.<ALSMore>operator_doubleArrow(_createALSMore, _function);
  }
  
  protected ALSTerm _transformTerm(final LessThan lessThan, final Logic2AlloyLanguageMapperTrace trace, final Map<Variable, ALSVariableDeclaration> variables) {
    ALSLess _createALSLess = this.factory.createALSLess();
    final Procedure1<ALSLess> _function = (ALSLess it) -> {
      it.setLeftOperand(this.transformTerm(lessThan.getLeftOperand(), trace, variables));
      it.setRightOperand(this.transformTerm(lessThan.getRightOperand(), trace, variables));
    };
    return ObjectExtensions.<ALSLess>operator_doubleArrow(_createALSLess, _function);
  }
  
  protected ALSTerm _transformTerm(final MoreOrEqualThan moreThan, final Logic2AlloyLanguageMapperTrace trace, final Map<Variable, ALSVariableDeclaration> variables) {
    ALSMeq _createALSMeq = this.factory.createALSMeq();
    final Procedure1<ALSMeq> _function = (ALSMeq it) -> {
      it.setLeftOperand(this.transformTerm(moreThan.getLeftOperand(), trace, variables));
      it.setRightOperand(this.transformTerm(moreThan.getRightOperand(), trace, variables));
    };
    return ObjectExtensions.<ALSMeq>operator_doubleArrow(_createALSMeq, _function);
  }
  
  protected ALSTerm _transformTerm(final LessOrEqualThan lessThan, final Logic2AlloyLanguageMapperTrace trace, final Map<Variable, ALSVariableDeclaration> variables) {
    ALSLeq _createALSLeq = this.factory.createALSLeq();
    final Procedure1<ALSLeq> _function = (ALSLeq it) -> {
      it.setLeftOperand(this.transformTerm(lessThan.getLeftOperand(), trace, variables));
      it.setRightOperand(this.transformTerm(lessThan.getRightOperand(), trace, variables));
    };
    return ObjectExtensions.<ALSLeq>operator_doubleArrow(_createALSLeq, _function);
  }
  
  protected ALSTerm _transformTerm(final Equals equals, final Logic2AlloyLanguageMapperTrace trace, final Map<Variable, ALSVariableDeclaration> variables) {
    ALSEquals _createALSEquals = this.factory.createALSEquals();
    final Procedure1<ALSEquals> _function = (ALSEquals it) -> {
      it.setLeftOperand(this.transformTerm(equals.getLeftOperand(), trace, variables));
      it.setRightOperand(this.transformTerm(equals.getRightOperand(), trace, variables));
    };
    return ObjectExtensions.<ALSEquals>operator_doubleArrow(_createALSEquals, _function);
  }
  
  protected ALSTerm _transformTerm(final Distinct distinct, final Logic2AlloyLanguageMapperTrace trace, final Map<Variable, ALSVariableDeclaration> variables) {
    return this.support.unfoldDistinctTerms(this, distinct.getOperands(), trace, variables);
  }
  
  protected ALSTerm _transformTerm(final Plus plus, final Logic2AlloyLanguageMapperTrace trace, final Map<Variable, ALSVariableDeclaration> variables) {
    ALSFunctionCall _createALSFunctionCall = this.factory.createALSFunctionCall();
    final Procedure1<ALSFunctionCall> _function = (ALSFunctionCall it) -> {
      EList<ALSTerm> _params = it.getParams();
      ALSTerm _transformTerm = this.transformTerm(plus.getLeftOperand(), trace, variables);
      _params.add(_transformTerm);
      EList<ALSTerm> _params_1 = it.getParams();
      ALSTerm _transformTerm_1 = this.transformTerm(plus.getRightOperand(), trace, variables);
      _params_1.add(_transformTerm_1);
      it.setReferredNumericOperator(ALSNumericOperator.PLUS);
    };
    return ObjectExtensions.<ALSFunctionCall>operator_doubleArrow(_createALSFunctionCall, _function);
  }
  
  protected ALSTerm _transformTerm(final Minus minus, final Logic2AlloyLanguageMapperTrace trace, final Map<Variable, ALSVariableDeclaration> variables) {
    ALSFunctionCall _createALSFunctionCall = this.factory.createALSFunctionCall();
    final Procedure1<ALSFunctionCall> _function = (ALSFunctionCall it) -> {
      EList<ALSTerm> _params = it.getParams();
      ALSTerm _transformTerm = this.transformTerm(minus.getLeftOperand(), trace, variables);
      _params.add(_transformTerm);
      EList<ALSTerm> _params_1 = it.getParams();
      ALSTerm _transformTerm_1 = this.transformTerm(minus.getRightOperand(), trace, variables);
      _params_1.add(_transformTerm_1);
      it.setReferredNumericOperator(ALSNumericOperator.SUB);
    };
    return ObjectExtensions.<ALSFunctionCall>operator_doubleArrow(_createALSFunctionCall, _function);
  }
  
  protected ALSTerm _transformTerm(final Multiply multiply, final Logic2AlloyLanguageMapperTrace trace, final Map<Variable, ALSVariableDeclaration> variables) {
    ALSFunctionCall _createALSFunctionCall = this.factory.createALSFunctionCall();
    final Procedure1<ALSFunctionCall> _function = (ALSFunctionCall it) -> {
      EList<ALSTerm> _params = it.getParams();
      ALSTerm _transformTerm = this.transformTerm(multiply.getLeftOperand(), trace, variables);
      _params.add(_transformTerm);
      EList<ALSTerm> _params_1 = it.getParams();
      ALSTerm _transformTerm_1 = this.transformTerm(multiply.getRightOperand(), trace, variables);
      _params_1.add(_transformTerm_1);
      it.setReferredNumericOperator(ALSNumericOperator.MUL);
    };
    return ObjectExtensions.<ALSFunctionCall>operator_doubleArrow(_createALSFunctionCall, _function);
  }
  
  protected ALSTerm _transformTerm(final Divison div, final Logic2AlloyLanguageMapperTrace trace, final Map<Variable, ALSVariableDeclaration> variables) {
    ALSFunctionCall _createALSFunctionCall = this.factory.createALSFunctionCall();
    final Procedure1<ALSFunctionCall> _function = (ALSFunctionCall it) -> {
      EList<ALSTerm> _params = it.getParams();
      ALSTerm _transformTerm = this.transformTerm(div.getLeftOperand(), trace, variables);
      _params.add(_transformTerm);
      EList<ALSTerm> _params_1 = it.getParams();
      ALSTerm _transformTerm_1 = this.transformTerm(div.getRightOperand(), trace, variables);
      _params_1.add(_transformTerm_1);
      it.setReferredNumericOperator(ALSNumericOperator.DIV);
    };
    return ObjectExtensions.<ALSFunctionCall>operator_doubleArrow(_createALSFunctionCall, _function);
  }
  
  protected ALSTerm _transformTerm(final Mod mod, final Logic2AlloyLanguageMapperTrace trace, final Map<Variable, ALSVariableDeclaration> variables) {
    ALSFunctionCall _createALSFunctionCall = this.factory.createALSFunctionCall();
    final Procedure1<ALSFunctionCall> _function = (ALSFunctionCall it) -> {
      EList<ALSTerm> _params = it.getParams();
      ALSTerm _transformTerm = this.transformTerm(mod.getLeftOperand(), trace, variables);
      _params.add(_transformTerm);
      EList<ALSTerm> _params_1 = it.getParams();
      ALSTerm _transformTerm_1 = this.transformTerm(mod.getRightOperand(), trace, variables);
      _params_1.add(_transformTerm_1);
      it.setReferredNumericOperator(ALSNumericOperator.REM);
    };
    return ObjectExtensions.<ALSFunctionCall>operator_doubleArrow(_createALSFunctionCall, _function);
  }
  
  protected ALSTerm _transformTerm(final Forall forall, final Logic2AlloyLanguageMapperTrace trace, final Map<Variable, ALSVariableDeclaration> variables) {
    return this.support.createQuantifiedExpression(this, forall, ALSMultiplicity.ALL, trace, variables);
  }
  
  protected ALSTerm _transformTerm(final Exists exists, final Logic2AlloyLanguageMapperTrace trace, final Map<Variable, ALSVariableDeclaration> variables) {
    return this.support.createQuantifiedExpression(this, exists, ALSMultiplicity.SOME, trace, variables);
  }
  
  protected ALSTerm _transformTerm(final InstanceOf instanceOf, final Logic2AlloyLanguageMapperTrace trace, final Map<Variable, ALSVariableDeclaration> variables) {
    ALSSubset _createALSSubset = this.factory.createALSSubset();
    final Procedure1<ALSSubset> _function = (ALSSubset it) -> {
      it.setLeftOperand(this.transformTerm(instanceOf.getValue(), trace, variables));
      it.setRightOperand(this.transformTypeReference(instanceOf.getRange(), trace));
    };
    return ObjectExtensions.<ALSSubset>operator_doubleArrow(_createALSSubset, _function);
  }
  
  protected ALSTerm _transformTerm(final TransitiveClosure tc, final Logic2AlloyLanguageMapperTrace trace, final Map<Variable, ALSVariableDeclaration> variables) {
    return this.relationMapper.transformTransitiveRelationReference(
      tc.getRelation(), 
      this.transformTerm(tc.getLeftOperand(), trace, variables), 
      this.transformTerm(tc.getRightOperand(), trace, variables), trace);
  }
  
  protected ALSTerm _transformTerm(final SymbolicValue symbolicValue, final Logic2AlloyLanguageMapperTrace trace, final Map<Variable, ALSVariableDeclaration> variables) {
    return this.transformSymbolicReference(symbolicValue.getSymbolicReference(), symbolicValue.getParameterSubstitutions(), trace, variables);
  }
  
  protected ALSTerm _transformSymbolicReference(final DefinedElement referred, final List<Term> parameterSubstitutions, final Logic2AlloyLanguageMapperTrace trace, final Map<Variable, ALSVariableDeclaration> variables) {
    return this.typeMapper.transformReference(referred, trace);
  }
  
  protected ALSTerm _transformSymbolicReference(final ConstantDeclaration constant, final List<Term> parameterSubstitutions, final Logic2AlloyLanguageMapperTrace trace, final Map<Variable, ALSVariableDeclaration> variables) {
    boolean _containsKey = trace.constantDefinitions.containsKey(constant);
    if (_containsKey) {
      return this.transformSymbolicReference(CollectionsUtil.<ConstantDeclaration, ConstantDefinition>lookup(constant, trace.constantDefinitions), parameterSubstitutions, trace, variables);
    } else {
      ALSJoin _createALSJoin = this.factory.createALSJoin();
      final Procedure1<ALSJoin> _function = (ALSJoin it) -> {
        ALSReference _createALSReference = this.factory.createALSReference();
        final Procedure1<ALSReference> _function_1 = (ALSReference it_1) -> {
          it_1.setReferred(trace.logicLanguage);
        };
        ALSReference _doubleArrow = ObjectExtensions.<ALSReference>operator_doubleArrow(_createALSReference, _function_1);
        it.setLeftOperand(_doubleArrow);
        ALSReference _createALSReference_1 = this.factory.createALSReference();
        final Procedure1<ALSReference> _function_2 = (ALSReference it_1) -> {
          it_1.setReferred(CollectionsUtil.<ConstantDeclaration, ALSFieldDeclaration>lookup(constant, trace.constantDeclaration2LanguageField));
        };
        ALSReference _doubleArrow_1 = ObjectExtensions.<ALSReference>operator_doubleArrow(_createALSReference_1, _function_2);
        it.setRightOperand(_doubleArrow_1);
      };
      final ALSJoin res = ObjectExtensions.<ALSJoin>operator_doubleArrow(_createALSJoin, _function);
      return this.support.postprocessResultOfSymbolicReference(constant.getType(), res, trace);
    }
  }
  
  protected ALSTerm _transformSymbolicReference(final ConstantDefinition constant, final List<Term> parameterSubstitutions, final Logic2AlloyLanguageMapperTrace trace, final Map<Variable, ALSVariableDeclaration> variables) {
    ALSFunctionCall _createALSFunctionCall = this.factory.createALSFunctionCall();
    final Procedure1<ALSFunctionCall> _function = (ALSFunctionCall it) -> {
      it.setReferredDefinition(CollectionsUtil.<ConstantDefinition, ALSFunctionDefinition>lookup(constant, trace.constantDefinition2Function));
    };
    final ALSFunctionCall res = ObjectExtensions.<ALSFunctionCall>operator_doubleArrow(_createALSFunctionCall, _function);
    return this.support.postprocessResultOfSymbolicReference(constant.getType(), res, trace);
  }
  
  protected ALSTerm _transformSymbolicReference(final Variable variable, final List<Term> parameterSubstitutions, final Logic2AlloyLanguageMapperTrace trace, final Map<Variable, ALSVariableDeclaration> variables) {
    ALSReference _createALSReference = this.factory.createALSReference();
    final Procedure1<ALSReference> _function = (ALSReference it) -> {
      it.setReferred(CollectionsUtil.<Variable, ALSVariableDeclaration>lookup(variable, variables));
    };
    final ALSReference res = ObjectExtensions.<ALSReference>operator_doubleArrow(_createALSReference, _function);
    return this.support.postprocessResultOfSymbolicReference(variable.getRange(), res, trace);
  }
  
  protected ALSTerm _transformSymbolicReference(final FunctionDeclaration function, final List<Term> parameterSubstitutions, final Logic2AlloyLanguageMapperTrace trace, final Map<Variable, ALSVariableDeclaration> variables) {
    boolean _containsKey = trace.functionDefinitions.containsKey(function);
    if (_containsKey) {
      return this.transformSymbolicReference(CollectionsUtil.<FunctionDeclaration, FunctionDefinition>lookup(function, trace.functionDefinitions), parameterSubstitutions, trace, variables);
    } else {
      boolean _transformedToHostedField = this.functionMapper.transformedToHostedField(function, trace);
      if (_transformedToHostedField) {
        final ALSTerm param = this.transformTerm(parameterSubstitutions.get(0), trace, variables);
        ALSJoin _createALSJoin = this.factory.createALSJoin();
        final Procedure1<ALSJoin> _function = (ALSJoin it) -> {
          it.setLeftOperand(this.support.prepareParameterOfSymbolicReference(function.getParameters().get(0), param, trace));
          ALSReference _createALSReference = this.factory.createALSReference();
          final Procedure1<ALSReference> _function_1 = (ALSReference it_1) -> {
            it_1.setReferred(CollectionsUtil.<FunctionDeclaration, ALSFieldDeclaration>lookup(function, trace.functionDeclaration2HostedField));
          };
          ALSReference _doubleArrow = ObjectExtensions.<ALSReference>operator_doubleArrow(_createALSReference, _function_1);
          it.setRightOperand(_doubleArrow);
        };
        final ALSJoin res = ObjectExtensions.<ALSJoin>operator_doubleArrow(_createALSJoin, _function);
        return this.support.postprocessResultOfSymbolicReference(function.getRange(), res, trace);
      } else {
        ALSJoin _createALSJoin_1 = this.factory.createALSJoin();
        final Procedure1<ALSJoin> _function_1 = (ALSJoin it) -> {
          ALSReference _createALSReference = this.factory.createALSReference();
          final Procedure1<ALSReference> _function_2 = (ALSReference it_1) -> {
            it_1.setReferred(trace.logicLanguage);
          };
          ALSReference _doubleArrow = ObjectExtensions.<ALSReference>operator_doubleArrow(_createALSReference, _function_2);
          it.setLeftOperand(_doubleArrow);
          ALSReference _createALSReference_1 = this.factory.createALSReference();
          final Procedure1<ALSReference> _function_3 = (ALSReference it_1) -> {
            it_1.setReferred(CollectionsUtil.<FunctionDeclaration, ALSFieldDeclaration>lookup(function, trace.functionDeclaration2LanguageField));
          };
          ALSReference _doubleArrow_1 = ObjectExtensions.<ALSReference>operator_doubleArrow(_createALSReference_1, _function_3);
          it.setRightOperand(_doubleArrow_1);
        };
        final ALSJoin functionExpression = ObjectExtensions.<ALSJoin>operator_doubleArrow(_createALSJoin_1, _function_1);
        final ALSTerm res_1 = this.support.unfoldDotJoin(this, parameterSubstitutions, functionExpression, trace, variables);
        return this.support.postprocessResultOfSymbolicReference(function.getRange(), res_1, trace);
      }
    }
  }
  
  protected ALSTerm _transformSymbolicReference(final FunctionDefinition function, final List<Term> parameterSubstitutions, final Logic2AlloyLanguageMapperTrace trace, final Map<Variable, ALSVariableDeclaration> variables) {
    ALSFunctionCall _createALSFunctionCall = this.factory.createALSFunctionCall();
    final Procedure1<ALSFunctionCall> _function = (ALSFunctionCall it) -> {
      it.setReferredDefinition(CollectionsUtil.<FunctionDefinition, ALSFunctionDefinition>lookup(function, trace.functionDefinition2Function));
      EList<ALSTerm> _params = it.getParams();
      final Function1<Term, ALSTerm> _function_1 = (Term it_1) -> {
        return this.transformTerm(it_1, trace, variables);
      };
      List<ALSTerm> _map = ListExtensions.<Term, ALSTerm>map(parameterSubstitutions, _function_1);
      Iterables.<ALSTerm>addAll(_params, _map);
    };
    final ALSFunctionCall result = ObjectExtensions.<ALSFunctionCall>operator_doubleArrow(_createALSFunctionCall, _function);
    return this.support.postprocessResultOfSymbolicReference(function.getRange(), result, trace);
  }
  
  protected ALSTerm _transformSymbolicReference(final RelationDeclaration relation, final List<Term> parameterSubstitutions, final Logic2AlloyLanguageMapperTrace trace, final Map<Variable, ALSVariableDeclaration> variables) {
    ALSTerm _xifexpression = null;
    boolean _containsKey = trace.relationDefinitions.containsKey(relation);
    if (_containsKey) {
      _xifexpression = this.transformSymbolicReference(CollectionsUtil.<RelationDeclaration, RelationDefinition>lookup(relation, trace.relationDefinitions), parameterSubstitutions, trace, variables);
    } else {
      boolean _transformToHostedField = this.relationMapper.transformToHostedField(relation, trace);
      if (_transformToHostedField) {
        final ALSFieldDeclaration alsRelation = CollectionsUtil.<RelationDeclaration, ALSFieldDeclaration>lookup(relation, trace.relationDeclaration2Field);
        ALSSubset _createALSSubset = this.factory.createALSSubset();
        final Procedure1<ALSSubset> _function = (ALSSubset it) -> {
          it.setLeftOperand(this.transformTerm(parameterSubstitutions.get(1), trace, variables));
          ALSJoin _createALSJoin = this.factory.createALSJoin();
          final Procedure1<ALSJoin> _function_1 = (ALSJoin it_1) -> {
            it_1.setLeftOperand(this.transformTerm(parameterSubstitutions.get(0), trace, variables));
            ALSReference _createALSReference = this.factory.createALSReference();
            final Procedure1<ALSReference> _function_2 = (ALSReference it_2) -> {
              it_2.setReferred(alsRelation);
            };
            ALSReference _doubleArrow = ObjectExtensions.<ALSReference>operator_doubleArrow(_createALSReference, _function_2);
            it_1.setRightOperand(_doubleArrow);
          };
          ALSJoin _doubleArrow = ObjectExtensions.<ALSJoin>operator_doubleArrow(_createALSJoin, _function_1);
          it.setRightOperand(_doubleArrow);
        };
        return ObjectExtensions.<ALSSubset>operator_doubleArrow(_createALSSubset, _function);
      } else {
        ALSJoin _createALSJoin = this.factory.createALSJoin();
        final Procedure1<ALSJoin> _function_1 = (ALSJoin it) -> {
          ALSReference _createALSReference = this.factory.createALSReference();
          final Procedure1<ALSReference> _function_2 = (ALSReference it_1) -> {
            it_1.setReferred(trace.logicLanguage);
          };
          ALSReference _doubleArrow = ObjectExtensions.<ALSReference>operator_doubleArrow(_createALSReference, _function_2);
          it.setLeftOperand(_doubleArrow);
          ALSReference _createALSReference_1 = this.factory.createALSReference();
          final Procedure1<ALSReference> _function_3 = (ALSReference it_1) -> {
            it_1.setReferred(CollectionsUtil.<RelationDeclaration, ALSFieldDeclaration>lookup(relation, trace.relationDeclaration2Global));
          };
          ALSReference _doubleArrow_1 = ObjectExtensions.<ALSReference>operator_doubleArrow(_createALSReference_1, _function_3);
          it.setRightOperand(_doubleArrow_1);
        };
        final ALSJoin target = ObjectExtensions.<ALSJoin>operator_doubleArrow(_createALSJoin, _function_1);
        final ALSTerm source = this.support.unfoldTermDirectProduct(this, parameterSubstitutions, trace, variables);
        ALSSubset _createALSSubset_1 = this.factory.createALSSubset();
        final Procedure1<ALSSubset> _function_2 = (ALSSubset it) -> {
          it.setLeftOperand(source);
          it.setRightOperand(target);
        };
        return ObjectExtensions.<ALSSubset>operator_doubleArrow(_createALSSubset_1, _function_2);
      }
    }
    return _xifexpression;
  }
  
  protected ALSTerm _transformSymbolicReference(final RelationDefinition relation, final List<Term> parameterSubstitutions, final Logic2AlloyLanguageMapperTrace trace, final Map<Variable, ALSVariableDeclaration> variables) {
    ALSFunctionCall _createALSFunctionCall = this.factory.createALSFunctionCall();
    final Procedure1<ALSFunctionCall> _function = (ALSFunctionCall it) -> {
      it.setReferredDefinition(CollectionsUtil.<RelationDefinition, ALSRelationDefinition>lookup(relation, trace.relationDefinition2Predicate));
      EList<ALSTerm> _params = it.getParams();
      final Function1<Term, ALSTerm> _function_1 = (Term p) -> {
        return this.transformTerm(p, trace, variables);
      };
      List<ALSTerm> _map = ListExtensions.<Term, ALSTerm>map(parameterSubstitutions, _function_1);
      Iterables.<ALSTerm>addAll(_params, _map);
    };
    return ObjectExtensions.<ALSFunctionCall>operator_doubleArrow(_createALSFunctionCall, _function);
  }
  
  protected ALSTerm transformTypeReference(final TypeReference boolTypeReference, final Logic2AlloyLanguageMapperTrace trace) {
    if (boolTypeReference instanceof BoolTypeReference) {
      return _transformTypeReference((BoolTypeReference)boolTypeReference, trace);
    } else if (boolTypeReference instanceof IntTypeReference) {
      return _transformTypeReference((IntTypeReference)boolTypeReference, trace);
    } else if (boolTypeReference instanceof RealTypeReference) {
      return _transformTypeReference((RealTypeReference)boolTypeReference, trace);
    } else if (boolTypeReference instanceof StringTypeReference) {
      return _transformTypeReference((StringTypeReference)boolTypeReference, trace);
    } else if (boolTypeReference instanceof ComplexTypeReference) {
      return _transformTypeReference((ComplexTypeReference)boolTypeReference, trace);
    } else {
      throw new IllegalArgumentException("Unhandled parameter types: " +
        Arrays.<Object>asList(boolTypeReference, trace).toString());
    }
  }
  
  protected ALSTerm transformTerm(final Term and, final Logic2AlloyLanguageMapperTrace trace, final Map<Variable, ALSVariableDeclaration> variables) {
    if (and instanceof And) {
      return _transformTerm((And)and, trace, variables);
    } else if (and instanceof BoolLiteral) {
      return _transformTerm((BoolLiteral)and, trace, variables);
    } else if (and instanceof Distinct) {
      return _transformTerm((Distinct)and, trace, variables);
    } else if (and instanceof Divison) {
      return _transformTerm((Divison)and, trace, variables);
    } else if (and instanceof Equals) {
      return _transformTerm((Equals)and, trace, variables);
    } else if (and instanceof Exists) {
      return _transformTerm((Exists)and, trace, variables);
    } else if (and instanceof Forall) {
      return _transformTerm((Forall)and, trace, variables);
    } else if (and instanceof Iff) {
      return _transformTerm((Iff)and, trace, variables);
    } else if (and instanceof Impl) {
      return _transformTerm((Impl)and, trace, variables);
    } else if (and instanceof IntLiteral) {
      return _transformTerm((IntLiteral)and, trace, variables);
    } else if (and instanceof LessOrEqualThan) {
      return _transformTerm((LessOrEqualThan)and, trace, variables);
    } else if (and instanceof LessThan) {
      return _transformTerm((LessThan)and, trace, variables);
    } else if (and instanceof Minus) {
      return _transformTerm((Minus)and, trace, variables);
    } else if (and instanceof Mod) {
      return _transformTerm((Mod)and, trace, variables);
    } else if (and instanceof MoreOrEqualThan) {
      return _transformTerm((MoreOrEqualThan)and, trace, variables);
    } else if (and instanceof MoreThan) {
      return _transformTerm((MoreThan)and, trace, variables);
    } else if (and instanceof Multiply) {
      return _transformTerm((Multiply)and, trace, variables);
    } else if (and instanceof Not) {
      return _transformTerm((Not)and, trace, variables);
    } else if (and instanceof Or) {
      return _transformTerm((Or)and, trace, variables);
    } else if (and instanceof Plus) {
      return _transformTerm((Plus)and, trace, variables);
    } else if (and instanceof RealLiteral) {
      return _transformTerm((RealLiteral)and, trace, variables);
    } else if (and instanceof StringLiteral) {
      return _transformTerm((StringLiteral)and, trace, variables);
    } else if (and instanceof InstanceOf) {
      return _transformTerm((InstanceOf)and, trace, variables);
    } else if (and instanceof SymbolicValue) {
      return _transformTerm((SymbolicValue)and, trace, variables);
    } else if (and instanceof TransitiveClosure) {
      return _transformTerm((TransitiveClosure)and, trace, variables);
    } else {
      throw new IllegalArgumentException("Unhandled parameter types: " +
        Arrays.<Object>asList(and, trace, variables).toString());
    }
  }
  
  protected ALSTerm transformSymbolicReference(final SymbolicDeclaration constant, final List<Term> parameterSubstitutions, final Logic2AlloyLanguageMapperTrace trace, final Map<Variable, ALSVariableDeclaration> variables) {
    if (constant instanceof ConstantDeclaration) {
      return _transformSymbolicReference((ConstantDeclaration)constant, parameterSubstitutions, trace, variables);
    } else if (constant instanceof ConstantDefinition) {
      return _transformSymbolicReference((ConstantDefinition)constant, parameterSubstitutions, trace, variables);
    } else if (constant instanceof FunctionDeclaration) {
      return _transformSymbolicReference((FunctionDeclaration)constant, parameterSubstitutions, trace, variables);
    } else if (constant instanceof FunctionDefinition) {
      return _transformSymbolicReference((FunctionDefinition)constant, parameterSubstitutions, trace, variables);
    } else if (constant instanceof RelationDeclaration) {
      return _transformSymbolicReference((RelationDeclaration)constant, parameterSubstitutions, trace, variables);
    } else if (constant instanceof RelationDefinition) {
      return _transformSymbolicReference((RelationDefinition)constant, parameterSubstitutions, trace, variables);
    } else if (constant instanceof DefinedElement) {
      return _transformSymbolicReference((DefinedElement)constant, parameterSubstitutions, trace, variables);
    } else if (constant instanceof Variable) {
      return _transformSymbolicReference((Variable)constant, parameterSubstitutions, trace, variables);
    } else {
      throw new IllegalArgumentException("Unhandled parameter types: " +
        Arrays.<Object>asList(constant, parameterSubstitutions, trace, variables).toString());
    }
  }
  
  @Pure
  public Logic2AlloyLanguageMapper_TypeMapper getTypeMapper() {
    return this.typeMapper;
  }
  
  @Pure
  public Logic2AlloyLanguageMapper_ConstantMapper getConstantMapper() {
    return this.constantMapper;
  }
  
  @Pure
  public Logic2AlloyLanguageMapper_FunctionMapper getFunctionMapper() {
    return this.functionMapper;
  }
  
  @Pure
  public Logic2AlloyLanguageMapper_RelationMapper getRelationMapper() {
    return this.relationMapper;
  }
  
  @Pure
  public Logic2AlloyLanguageMapper_Containment getContainmentMapper() {
    return this.containmentMapper;
  }
}
