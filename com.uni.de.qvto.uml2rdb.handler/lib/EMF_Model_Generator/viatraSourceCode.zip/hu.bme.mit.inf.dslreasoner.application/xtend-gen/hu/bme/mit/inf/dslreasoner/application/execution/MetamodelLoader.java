package hu.bme.mit.inf.dslreasoner.application.execution;

import com.google.common.collect.Iterables;
import hu.bme.mit.inf.dslreasoner.application.applicationConfiguration.AllPackageEntry;
import hu.bme.mit.inf.dslreasoner.application.applicationConfiguration.MetamodelElement;
import hu.bme.mit.inf.dslreasoner.application.applicationConfiguration.MetamodelEntry;
import hu.bme.mit.inf.dslreasoner.application.applicationConfiguration.MetamodelSpecification;
import hu.bme.mit.inf.dslreasoner.ecore2logic.EcoreMetamodelDescriptor;
import java.util.Collections;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import org.eclipse.emf.common.util.EList;
import org.eclipse.emf.ecore.EAttribute;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EClassifier;
import org.eclipse.emf.ecore.EEnum;
import org.eclipse.emf.ecore.EEnumLiteral;
import org.eclipse.emf.ecore.ENamedElement;
import org.eclipse.emf.ecore.EReference;
import org.eclipse.emf.ecore.EcorePackage;
import org.eclipse.emf.ecore.resource.Resource;
import org.eclipse.emf.ecore.xmi.impl.XMIResourceFactoryImpl;
import org.eclipse.xtend2.lib.StringConcatenation;
import org.eclipse.xtext.xbase.lib.CollectionLiterals;
import org.eclipse.xtext.xbase.lib.Functions.Function1;
import org.eclipse.xtext.xbase.lib.IterableExtensions;
import org.eclipse.xtext.xbase.lib.ListExtensions;

@SuppressWarnings("all")
public class MetamodelLoader {
  private static Object init() {
    Object _xblockexpression = null;
    {
      EcorePackage.eINSTANCE.getEClass();
      Map<String, Object> _extensionToFactoryMap = Resource.Factory.Registry.INSTANCE.getExtensionToFactoryMap();
      XMIResourceFactoryImpl _xMIResourceFactoryImpl = new XMIResourceFactoryImpl();
      _xblockexpression = _extensionToFactoryMap.put("ecore", _xMIResourceFactoryImpl);
    }
    return _xblockexpression;
  }
  
  public MetamodelLoader() {
    MetamodelLoader.init();
  }
  
  public EcoreMetamodelDescriptor loadMetamodel(final MetamodelSpecification specification) throws IllegalArgumentException {
    final Set<EClass> classes = new LinkedHashSet<EClass>();
    final Set<EEnum> enums = new LinkedHashSet<EEnum>();
    final Set<EEnumLiteral> literals = new LinkedHashSet<EEnumLiteral>();
    final Set<EReference> references = new LinkedHashSet<EReference>();
    final Set<EAttribute> attributes = new LinkedHashSet<EAttribute>();
    EList<MetamodelEntry> _entries = specification.getEntries();
    for (final MetamodelEntry entry : _entries) {
      {
        List<EClass> _classes = this.getClasses(entry);
        Iterables.<EClass>addAll(classes, _classes);
        List<EEnum> _enums = this.getEnums(entry);
        Iterables.<EEnum>addAll(enums, _enums);
        List<EEnumLiteral> _literals = this.getLiterals(entry);
        Iterables.<EEnumLiteral>addAll(literals, _literals);
        List<EReference> _references = this.getReferences(entry);
        Iterables.<EReference>addAll(references, _references);
        List<EAttribute> _attributes = this.getAttributes(entry);
        Iterables.<EAttribute>addAll(attributes, _attributes);
      }
    }
    List<EClass> _list = IterableExtensions.<EClass>toList(classes);
    Set<EClass> _emptySet = CollectionLiterals.<EClass>emptySet();
    List<EEnum> _list_1 = IterableExtensions.<EEnum>toList(enums);
    List<EEnumLiteral> _list_2 = IterableExtensions.<EEnumLiteral>toList(literals);
    List<EReference> _list_3 = IterableExtensions.<EReference>toList(references);
    List<EAttribute> _list_4 = IterableExtensions.<EAttribute>toList(attributes);
    return new EcoreMetamodelDescriptor(_list, _emptySet, false, _list_1, _list_2, _list_3, _list_4);
  }
  
  public <T extends Object> List<T> extractElements(final MetamodelEntry entry, final Function1<AllPackageEntry, Iterable<T>> packageEntryExtractor, final Function1<MetamodelElement, Iterable<T>> metamodelElementExtractor) {
    if ((entry instanceof MetamodelElement)) {
      return IterableExtensions.<T>toList(metamodelElementExtractor.apply(((MetamodelElement)entry)));
    } else {
      if ((entry instanceof AllPackageEntry)) {
        final Function1<MetamodelElement, Iterable<T>> _function = (MetamodelElement it) -> {
          return metamodelElementExtractor.apply(it);
        };
        final Set<T> excluded = IterableExtensions.<T>toSet(Iterables.<T>concat(ListExtensions.<MetamodelElement, Iterable<T>>map(((AllPackageEntry)entry).getExclusion(), _function)));
        final Function1<T, Boolean> _function_1 = (T it) -> {
          boolean _contains = excluded.contains(it);
          return Boolean.valueOf((!_contains));
        };
        return IterableExtensions.<T>toList(IterableExtensions.<T>filter(packageEntryExtractor.apply(((AllPackageEntry)entry)), _function_1));
      } else {
        StringConcatenation _builder = new StringConcatenation();
        _builder.append("Unsupported entry type: \"");
        String _simpleName = entry.getClass().getSimpleName();
        _builder.append(_simpleName);
        _builder.append("\"!");
        throw new IllegalArgumentException(_builder.toString());
      }
    }
  }
  
  public List<EClass> getClasses(final MetamodelEntry entry) {
    final Function1<AllPackageEntry, Iterable<EClass>> _function = (AllPackageEntry it) -> {
      return Iterables.<EClass>filter(it.getPackage().getEClassifiers(), EClass.class);
    };
    final Function1<MetamodelElement, Iterable<EClass>> _function_1 = (MetamodelElement it) -> {
      final EClassifier classifier = it.getClassifier();
      if ((classifier instanceof EClass)) {
        ENamedElement _feature = it.getFeature();
        boolean _tripleEquals = (_feature == null);
        if (_tripleEquals) {
          return Collections.<EClass>unmodifiableList(CollectionLiterals.<EClass>newArrayList(((EClass)classifier)));
        }
      }
      return CollectionLiterals.<EClass>emptyList();
    };
    return this.<EClass>extractElements(entry, _function, _function_1);
  }
  
  public List<EEnum> getEnums(final MetamodelEntry entry) {
    final Function1<AllPackageEntry, Iterable<EEnum>> _function = (AllPackageEntry it) -> {
      return Iterables.<EEnum>filter(it.getPackage().getEClassifiers(), EEnum.class);
    };
    final Function1<MetamodelElement, Iterable<EEnum>> _function_1 = (MetamodelElement it) -> {
      final EClassifier classifier = it.getClassifier();
      if ((classifier instanceof EEnum)) {
        ENamedElement _feature = it.getFeature();
        boolean _tripleEquals = (_feature == null);
        if (_tripleEquals) {
          return Collections.<EEnum>unmodifiableList(CollectionLiterals.<EEnum>newArrayList(((EEnum)classifier)));
        }
      }
      return CollectionLiterals.<EEnum>emptyList();
    };
    return this.<EEnum>extractElements(entry, _function, _function_1);
  }
  
  public List<EEnumLiteral> getLiterals(final MetamodelEntry entry) {
    final Function1<AllPackageEntry, Iterable<EEnumLiteral>> _function = (AllPackageEntry it) -> {
      final Function1<EEnum, EList<EEnumLiteral>> _function_1 = (EEnum it_1) -> {
        return it_1.getELiterals();
      };
      return Iterables.<EEnumLiteral>concat(IterableExtensions.<EEnum, EList<EEnumLiteral>>map(Iterables.<EEnum>filter(it.getPackage().getEClassifiers(), EEnum.class), _function_1));
    };
    final Function1<MetamodelElement, Iterable<EEnumLiteral>> _function_1 = (MetamodelElement it) -> {
      final ENamedElement feature = it.getFeature();
      if ((feature instanceof EEnumLiteral)) {
        return Collections.<EEnumLiteral>unmodifiableList(CollectionLiterals.<EEnumLiteral>newArrayList(((EEnumLiteral)feature)));
      }
      return CollectionLiterals.<EEnumLiteral>emptyList();
    };
    return this.<EEnumLiteral>extractElements(entry, _function, _function_1);
  }
  
  public List<EReference> getReferences(final MetamodelEntry entry) {
    final Function1<AllPackageEntry, Iterable<EReference>> _function = (AllPackageEntry it) -> {
      final Function1<EClass, EList<EReference>> _function_1 = (EClass it_1) -> {
        return it_1.getEReferences();
      };
      return Iterables.<EReference>concat(IterableExtensions.<EClass, EList<EReference>>map(Iterables.<EClass>filter(it.getPackage().getEClassifiers(), EClass.class), _function_1));
    };
    final Function1<MetamodelElement, Iterable<EReference>> _function_1 = (MetamodelElement it) -> {
      final ENamedElement feature = it.getFeature();
      if ((feature instanceof EReference)) {
        return Collections.<EReference>unmodifiableList(CollectionLiterals.<EReference>newArrayList(((EReference)feature)));
      }
      return CollectionLiterals.<EReference>emptyList();
    };
    return this.<EReference>extractElements(entry, _function, _function_1);
  }
  
  public List<EAttribute> getAttributes(final MetamodelEntry entry) {
    final Function1<AllPackageEntry, Iterable<EAttribute>> _function = (AllPackageEntry it) -> {
      final Function1<EClass, EList<EAttribute>> _function_1 = (EClass it_1) -> {
        return it_1.getEAttributes();
      };
      return Iterables.<EAttribute>concat(IterableExtensions.<EClass, EList<EAttribute>>map(Iterables.<EClass>filter(it.getPackage().getEClassifiers(), EClass.class), _function_1));
    };
    final Function1<MetamodelElement, Iterable<EAttribute>> _function_1 = (MetamodelElement it) -> {
      final ENamedElement feature = it.getFeature();
      if ((feature instanceof EAttribute)) {
        return Collections.<EAttribute>unmodifiableList(CollectionLiterals.<EAttribute>newArrayList(((EAttribute)feature)));
      }
      return CollectionLiterals.<EAttribute>emptyList();
    };
    return this.<EAttribute>extractElements(entry, _function, _function_1);
  }
}
