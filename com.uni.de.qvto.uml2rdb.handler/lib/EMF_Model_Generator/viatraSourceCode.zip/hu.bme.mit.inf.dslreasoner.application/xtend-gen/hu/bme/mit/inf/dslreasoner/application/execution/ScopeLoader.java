package hu.bme.mit.inf.dslreasoner.application.execution;

import com.google.common.collect.Iterables;
import hu.bme.mit.inf.dslreasoner.application.applicationConfiguration.ClassTypeScope;
import hu.bme.mit.inf.dslreasoner.application.applicationConfiguration.ExactNumber;
import hu.bme.mit.inf.dslreasoner.application.applicationConfiguration.IntEnumberation;
import hu.bme.mit.inf.dslreasoner.application.applicationConfiguration.IntegerTypeScope;
import hu.bme.mit.inf.dslreasoner.application.applicationConfiguration.IntervallNumber;
import hu.bme.mit.inf.dslreasoner.application.applicationConfiguration.MetamodelElement;
import hu.bme.mit.inf.dslreasoner.application.applicationConfiguration.NumberSpecification;
import hu.bme.mit.inf.dslreasoner.application.applicationConfiguration.ObjectTypeScope;
import hu.bme.mit.inf.dslreasoner.application.applicationConfiguration.RealEnumeration;
import hu.bme.mit.inf.dslreasoner.application.applicationConfiguration.RealTypeScope;
import hu.bme.mit.inf.dslreasoner.application.applicationConfiguration.ScopeSpecification;
import hu.bme.mit.inf.dslreasoner.application.applicationConfiguration.StringEnumeration;
import hu.bme.mit.inf.dslreasoner.application.applicationConfiguration.StringTypeScope;
import hu.bme.mit.inf.dslreasoner.application.applicationConfiguration.TypeScope;
import hu.bme.mit.inf.dslreasoner.ecore2logic.Ecore2Logic;
import hu.bme.mit.inf.dslreasoner.ecore2logic.Ecore2Logic_Trace;
import hu.bme.mit.inf.dslreasoner.logic.model.builder.TypeScopes;
import hu.bme.mit.inf.dslreasoner.logic.model.logiclanguage.Assertion;
import hu.bme.mit.inf.dslreasoner.logic.model.logiclanguage.DefinedElement;
import hu.bme.mit.inf.dslreasoner.logic.model.logiclanguage.IntLiteral;
import hu.bme.mit.inf.dslreasoner.logic.model.logiclanguage.RealLiteral;
import hu.bme.mit.inf.dslreasoner.logic.model.logiclanguage.StringLiteral;
import hu.bme.mit.inf.dslreasoner.logic.model.logiclanguage.Type;
import hu.bme.mit.inf.dslreasoner.logic.model.logiclanguage.TypeDefinition;
import hu.bme.mit.inf.dslreasoner.logic.model.logicproblem.LogicProblem;
import hu.bme.mit.inf.dslreasoner.util.CollectionsUtil;
import hu.bme.mit.inf.dslreasoner.viatrasolver.partialinterpretationlanguage.partial2logicannotations.PartialModelRelation2Assertion;
import hu.bme.mit.inf.dslreasoner.viatrasolver.partialinterpretationlanguage.partialinterpretation.BinaryElementRelationLink;
import hu.bme.mit.inf.dslreasoner.viatrasolver.partialinterpretationlanguage.partialinterpretation.NaryRelationLink;
import hu.bme.mit.inf.dslreasoner.viatrasolver.partialinterpretationlanguage.partialinterpretation.RelationLink;
import hu.bme.mit.inf.dslreasoner.viatrasolver.partialinterpretationlanguage.partialinterpretation.UnaryElementRelationLink;
import java.math.BigDecimal;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import org.eclipse.emf.common.util.EList;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EClassifier;
import org.eclipse.emf.ecore.ENamedElement;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.xtend2.lib.StringConcatenation;
import org.eclipse.xtext.xbase.lib.CollectionLiterals;
import org.eclipse.xtext.xbase.lib.Functions.Function1;
import org.eclipse.xtext.xbase.lib.IterableExtensions;
import org.eclipse.xtext.xbase.lib.IteratorExtensions;
import org.eclipse.xtext.xbase.lib.ListExtensions;
import org.eclipse.xtext.xbase.lib.Pair;

@SuppressWarnings("all")
public class ScopeLoader {
  public Pair<TypeScopes, LinkedList<String>> loadScope(final ScopeSpecification specification, final LogicProblem problem, final Ecore2Logic ecore2Logic, final Ecore2Logic_Trace trace) {
    final TypeScopes res = new TypeScopes();
    final Map<Type, Set<DefinedElement>> knownElements = this.initialiseknownElements(problem, res);
    final LinkedList<String> inconsistencies = new LinkedList<String>();
    EList<TypeScope> _scopes = specification.getScopes();
    for (final TypeScope scopeSpecification : _scopes) {
      this.setSpecification(scopeSpecification, res, knownElements, ecore2Logic, trace, inconsistencies);
    }
    return Pair.<TypeScopes, LinkedList<String>>of(res, inconsistencies);
  }
  
  protected Map<Type, Set<DefinedElement>> initialiseknownElements(final LogicProblem p, final TypeScopes s) {
    Map<Type, Set<DefinedElement>> _xblockexpression = null;
    {
      final Map<Type, Set<DefinedElement>> res = new HashMap<Type, Set<DefinedElement>>();
      EList<Type> _types = p.getTypes();
      for (final Type t : _types) {
        HashSet<DefinedElement> _hashSet = new HashSet<DefinedElement>();
        res.put(t, _hashSet);
      }
      Iterable<TypeDefinition> _filter = Iterables.<TypeDefinition>filter(p.getTypes(), TypeDefinition.class);
      for (final TypeDefinition definedType : _filter) {
        {
          final Function1<Type, Iterable<Type>> _function = (Type x) -> {
            return x.getSupertypes();
          };
          final List<Type> supertypes = CollectionsUtil.<Type>transitiveClosureStar(definedType, _function);
          for (final Type supertype : supertypes) {
            EList<DefinedElement> _elements = definedType.getElements();
            for (final DefinedElement element : _elements) {
              res.get(supertype).add(element);
            }
          }
        }
      }
      final Function1<PartialModelRelation2Assertion, Assertion> _function = (PartialModelRelation2Assertion it) -> {
        return it.getTarget();
      };
      final Function1<Assertion, Iterable<EObject>> _function_1 = (Assertion it) -> {
        return IteratorExtensions.<EObject>toIterable(it.eAllContents());
      };
      final List<EObject> partailModelContents = IterableExtensions.<EObject>toList(Iterables.<EObject>concat(ListExtensions.<Assertion, Iterable<EObject>>map(IterableExtensions.<Assertion>toList(IterableExtensions.<PartialModelRelation2Assertion, Assertion>map(Iterables.<PartialModelRelation2Assertion>filter(p.getAnnotations(), PartialModelRelation2Assertion.class), _function)), _function_1)));
      final Function1<IntLiteral, Integer> _function_2 = (IntLiteral it) -> {
        return Integer.valueOf(it.getValue());
      };
      Iterable<Integer> _map = IterableExtensions.<IntLiteral, Integer>map(Iterables.<IntLiteral>filter(partailModelContents, IntLiteral.class), _function_2);
      Iterables.<Integer>addAll(s.knownIntegers, _map);
      final Function1<RealLiteral, BigDecimal> _function_3 = (RealLiteral it) -> {
        return it.getValue();
      };
      Iterable<BigDecimal> _map_1 = IterableExtensions.<RealLiteral, BigDecimal>map(Iterables.<RealLiteral>filter(partailModelContents, RealLiteral.class), _function_3);
      Iterables.<BigDecimal>addAll(s.knownReals, _map_1);
      final Function1<StringLiteral, String> _function_4 = (StringLiteral it) -> {
        return it.getValue();
      };
      Iterable<String> _map_2 = IterableExtensions.<StringLiteral, String>map(Iterables.<StringLiteral>filter(partailModelContents, StringLiteral.class), _function_4);
      Iterables.<String>addAll(s.knownStrings, _map_2);
      _xblockexpression = res;
    }
    return _xblockexpression;
  }
  
  protected List<? extends EObject> _getElements(final UnaryElementRelationLink link) {
    DefinedElement _param1 = link.getParam1();
    return Collections.<DefinedElement>unmodifiableList(CollectionLiterals.<DefinedElement>newArrayList(_param1));
  }
  
  protected List<? extends EObject> _getElements(final BinaryElementRelationLink link) {
    DefinedElement _param1 = link.getParam1();
    DefinedElement _param2 = link.getParam2();
    return Collections.<DefinedElement>unmodifiableList(CollectionLiterals.<DefinedElement>newArrayList(_param1, _param2));
  }
  
  protected List<? extends EObject> _getElements(final NaryRelationLink link) {
    return link.getElements();
  }
  
  protected Object _setSpecification(final ObjectTypeScope scope, final TypeScopes aggregated, final Map<Type, Set<DefinedElement>> knownElements, final Ecore2Logic ecore2Logic, final Ecore2Logic_Trace trace, final List<String> inconsistencies) {
    boolean _xblockexpression = false;
    {
      final int numberOfKnownElements = IterableExtensions.<DefinedElement>toSet(Iterables.<DefinedElement>concat(knownElements.values())).size();
      aggregated.minNewElements = this.updateLowerLimit(scope.isSetsNew(), numberOfKnownElements, Integer.valueOf(aggregated.minNewElements), this.getLowerLimit(scope.getNumber()));
      aggregated.maxNewElements = this.updateUpperLimit(scope.isSetsNew(), numberOfKnownElements, Integer.valueOf(aggregated.maxNewElements), this.getUpperLimit(scope.getNumber()));
      boolean _xifexpression = false;
      if ((aggregated.maxNewElements < 0)) {
        StringConcatenation _builder = new StringConcatenation();
        _builder.append("Inconsistent scope: problem already contains ");
        _builder.append(numberOfKnownElements);
        _builder.append(" elements, but scope sets the upper limit to ");
        int _upperLimit = this.getUpperLimit(scope.getNumber());
        _builder.append(_upperLimit);
        _builder.append("!");
        _xifexpression = inconsistencies.add(_builder.toString());
      }
      _xblockexpression = _xifexpression;
    }
    return Boolean.valueOf(_xblockexpression);
  }
  
  protected Object _setSpecification(final ClassTypeScope scope, final TypeScopes aggregated, final Map<Type, Set<DefinedElement>> knownElements, final Ecore2Logic ecore2Logic, final Ecore2Logic_Trace trace, final List<String> inconsistencies) {
    Integer _xblockexpression = null;
    {
      final MetamodelElement target = scope.getType().getElement();
      Integer _xifexpression = null;
      ENamedElement _feature = target.getFeature();
      boolean _tripleNotEquals = (_feature != null);
      if (_tripleNotEquals) {
        StringConcatenation _builder = new StringConcatenation();
        _builder.append("Feature scopes are not supported: \"");
        String _name = target.getFeature().getName();
        _builder.append(_name);
        _builder.append("\"!");
        throw new IllegalArgumentException(_builder.toString());
      } else {
        Integer _xblockexpression_1 = null;
        {
          final EClassifier targetClassifier = target.getClassifier();
          Integer _xifexpression_1 = null;
          if ((targetClassifier instanceof EClass)) {
            Integer _xblockexpression_2 = null;
            {
              final Type type = ecore2Logic.TypeofEClass(trace, ((EClass)targetClassifier));
              final int known = CollectionsUtil.<Type, Set<DefinedElement>>lookup(type, knownElements).size();
              aggregated.minNewElementsByType.put(type, 
                Integer.valueOf(this.updateLowerLimit(
                  scope.isSetsNew(), known, 
                  aggregated.minNewElementsByType.get(type), 
                  this.getLowerLimit(scope.getNumber()))));
              _xblockexpression_2 = aggregated.maxNewElementsByType.put(type, 
                Integer.valueOf(this.updateUpperLimit(
                  scope.isSetsNew(), known, 
                  aggregated.maxNewElementsByType.get(type), 
                  this.getUpperLimit(scope.getNumber()))));
            }
            _xifexpression_1 = _xblockexpression_2;
          } else {
            StringConcatenation _builder_1 = new StringConcatenation();
            _builder_1.append("Non-EClass scopes are not supported: \"");
            String _name_1 = targetClassifier.getName();
            _builder_1.append(_name_1);
            _builder_1.append("\"!");
            throw new IllegalArgumentException(_builder_1.toString());
          }
          _xblockexpression_1 = _xifexpression_1;
        }
        _xifexpression = _xblockexpression_1;
      }
      _xblockexpression = _xifexpression;
    }
    return _xblockexpression;
  }
  
  protected Object _setSpecification(final IntegerTypeScope scope, final TypeScopes aggregated, final Map<Type, Set<DefinedElement>> knownElements, final Ecore2Logic ecore2Logic, final Ecore2Logic_Trace trace, final List<String> inconsistencies) {
    int _xblockexpression = (int) 0;
    {
      final NumberSpecification number = scope.getNumber();
      int _xifexpression = (int) 0;
      if ((number instanceof IntEnumberation)) {
        int _xblockexpression_1 = (int) 0;
        {
          this.<Integer>addToKnownCollection(aggregated.knownIntegers, ((IntEnumberation)number).getEntry(), scope.isSetsNew(), inconsistencies);
          int _xifexpression_1 = (int) 0;
          boolean _isSetsNew = scope.isSetsNew();
          boolean _not = (!_isSetsNew);
          if (_not) {
            _xifexpression_1 = aggregated.maxNewIntegers = 0;
          }
          _xblockexpression_1 = _xifexpression_1;
        }
        _xifexpression = _xblockexpression_1;
      } else {
        int _xblockexpression_2 = (int) 0;
        {
          aggregated.minNewIntegers = this.updateLowerLimit(scope.isSetsNew(), aggregated.knownIntegers.size(), Integer.valueOf(aggregated.minNewIntegers), this.getLowerLimit(number));
          _xblockexpression_2 = aggregated.maxNewIntegers = this.updateLowerLimit(scope.isSetsNew(), aggregated.knownIntegers.size(), Integer.valueOf(aggregated.maxNewIntegers), this.getUpperLimit(number));
        }
        _xifexpression = _xblockexpression_2;
      }
      _xblockexpression = _xifexpression;
    }
    return Integer.valueOf(_xblockexpression);
  }
  
  protected Object _setSpecification(final RealTypeScope scope, final TypeScopes aggregated, final Map<Type, Set<DefinedElement>> knownElements, final Ecore2Logic ecore2Logic, final Ecore2Logic_Trace trace, final List<String> inconsistencies) {
    int _xblockexpression = (int) 0;
    {
      final NumberSpecification number = scope.getNumber();
      int _xifexpression = (int) 0;
      if ((number instanceof RealEnumeration)) {
        int _xblockexpression_1 = (int) 0;
        {
          final EList<BigDecimal> x = ((RealEnumeration)number).getEntry();
          this.<BigDecimal>addToKnownCollection(aggregated.knownReals, x, scope.isSetsNew(), inconsistencies);
          int _xifexpression_1 = (int) 0;
          boolean _isSetsNew = scope.isSetsNew();
          boolean _not = (!_isSetsNew);
          if (_not) {
            _xifexpression_1 = aggregated.maxNewReals = 0;
          }
          _xblockexpression_1 = _xifexpression_1;
        }
        _xifexpression = _xblockexpression_1;
      } else {
        int _xblockexpression_2 = (int) 0;
        {
          aggregated.minNewReals = this.updateLowerLimit(scope.isSetsNew(), aggregated.knownReals.size(), Integer.valueOf(aggregated.minNewReals), this.getLowerLimit(number));
          _xblockexpression_2 = aggregated.maxNewReals = this.updateLowerLimit(scope.isSetsNew(), aggregated.knownReals.size(), Integer.valueOf(aggregated.maxNewReals), this.getUpperLimit(number));
        }
        _xifexpression = _xblockexpression_2;
      }
      _xblockexpression = _xifexpression;
    }
    return Integer.valueOf(_xblockexpression);
  }
  
  protected Object _setSpecification(final StringTypeScope scope, final TypeScopes aggregated, final Map<Type, Set<DefinedElement>> knownElements, final Ecore2Logic ecore2Logic, final Ecore2Logic_Trace trace, final List<String> inconsistencies) {
    int _xblockexpression = (int) 0;
    {
      final NumberSpecification number = scope.getNumber();
      int _xifexpression = (int) 0;
      if ((number instanceof StringEnumeration)) {
        int _xblockexpression_1 = (int) 0;
        {
          this.<String>addToKnownCollection(aggregated.knownStrings, ((StringEnumeration)number).getEntry(), scope.isSetsNew(), inconsistencies);
          int _xifexpression_1 = (int) 0;
          boolean _isSetsNew = scope.isSetsNew();
          boolean _not = (!_isSetsNew);
          if (_not) {
            _xifexpression_1 = aggregated.maxNewStrings = 0;
          }
          _xblockexpression_1 = _xifexpression_1;
        }
        _xifexpression = _xblockexpression_1;
      } else {
        int _xblockexpression_2 = (int) 0;
        {
          aggregated.minNewStrings = this.updateLowerLimit(scope.isSetsNew(), aggregated.knownStrings.size(), Integer.valueOf(aggregated.minNewStrings), this.getLowerLimit(number));
          _xblockexpression_2 = aggregated.maxNewStrings = this.updateLowerLimit(scope.isSetsNew(), aggregated.knownStrings.size(), Integer.valueOf(aggregated.maxNewStrings), this.getUpperLimit(number));
        }
        _xifexpression = _xblockexpression_2;
      }
      _xblockexpression = _xifexpression;
    }
    return Integer.valueOf(_xblockexpression);
  }
  
  public <Type extends Object> boolean addToKnownCollection(final Set<Type> known, final List<Type> definedInScope, final boolean isSetNew, final List<String> inconsistencies) {
    boolean _xifexpression = false;
    if (isSetNew) {
      _xifexpression = Iterables.<Type>addAll(known, definedInScope);
    } else {
      boolean _xblockexpression = false;
      {
        boolean _containsAll = definedInScope.containsAll(known);
        boolean _not = (!_containsAll);
        if (_not) {
          final Function1<Type, Boolean> _function = (Type it) -> {
            boolean _contains = definedInScope.contains(it);
            return Boolean.valueOf((!_contains));
          };
          final Iterable<Type> notDefinedInScope = IterableExtensions.<Type>filter(known, _function);
          StringConcatenation _builder = new StringConcatenation();
          _builder.append("Inconsistent scope: problem already contains literal");
          {
            int _size = IterableExtensions.size(notDefinedInScope);
            boolean _greaterThan = (_size > 0);
            if (_greaterThan) {
              _builder.append("s");
            }
          }
          _builder.append(" that excluded by a scope: ");
          {
            boolean _hasElements = false;
            for(final Type e : notDefinedInScope) {
              if (!_hasElements) {
                _hasElements = true;
              } else {
                _builder.appendImmediate(", ", "");
              }
              _builder.append(e);
            }
          }
          _builder.append(".");
          inconsistencies.add(_builder.toString());
        }
        _xblockexpression = Iterables.<Type>addAll(known, definedInScope);
      }
      _xifexpression = _xblockexpression;
    }
    return _xifexpression;
  }
  
  public int updateLowerLimit(final boolean isAdditional, final int known, final Integer original, final int value) {
    Integer _xifexpression = null;
    if ((original == null)) {
      _xifexpression = Integer.valueOf(0);
    } else {
      _xifexpression = original;
    }
    final Integer o = _xifexpression;
    if (isAdditional) {
      return Math.max((o).intValue(), value);
    } else {
      return Math.max((o).intValue(), (value - known));
    }
  }
  
  public int updateUpperLimit(final boolean isAdditional, final int known, final Integer original, final int value) {
    Integer _xifexpression = null;
    if ((original == null)) {
      _xifexpression = Integer.valueOf(Integer.MAX_VALUE);
    } else {
      _xifexpression = original;
    }
    final Integer o = _xifexpression;
    if (isAdditional) {
      return Math.min((o).intValue(), value);
    } else {
      int _xifexpression_1 = (int) 0;
      if ((value == Integer.MAX_VALUE)) {
        _xifexpression_1 = Integer.MAX_VALUE;
      } else {
        _xifexpression_1 = (value - known);
      }
      final int target = _xifexpression_1;
      return Math.min((o).intValue(), target);
    }
  }
  
  protected int _getLowerLimit(final IntervallNumber specification) {
    return specification.getMin();
  }
  
  protected int _getLowerLimit(final ExactNumber specification) {
    boolean _isExactUnlimited = specification.isExactUnlimited();
    if (_isExactUnlimited) {
      return 0;
    } else {
      return specification.getExactNumber();
    }
  }
  
  protected int _getLowerLimit(final IntEnumberation specification) {
    return 0;
  }
  
  protected int _getLowerLimit(final RealEnumeration specification) {
    return 0;
  }
  
  protected int _getLowerLimit(final StringEnumeration specification) {
    return 0;
  }
  
  protected int _getUpperLimit(final IntervallNumber specification) {
    boolean _isMaxUnlimited = specification.isMaxUnlimited();
    if (_isMaxUnlimited) {
      return Integer.MAX_VALUE;
    } else {
      return specification.getMaxNumber();
    }
  }
  
  protected int _getUpperLimit(final ExactNumber specification) {
    boolean _isExactUnlimited = specification.isExactUnlimited();
    if (_isExactUnlimited) {
      return Integer.MAX_VALUE;
    } else {
      return specification.getExactNumber();
    }
  }
  
  public List<? extends EObject> getElements(final RelationLink link) {
    if (link instanceof BinaryElementRelationLink) {
      return _getElements((BinaryElementRelationLink)link);
    } else if (link instanceof NaryRelationLink) {
      return _getElements((NaryRelationLink)link);
    } else if (link instanceof UnaryElementRelationLink) {
      return _getElements((UnaryElementRelationLink)link);
    } else {
      throw new IllegalArgumentException("Unhandled parameter types: " +
        Arrays.<Object>asList(link).toString());
    }
  }
  
  public Object setSpecification(final TypeScope scope, final TypeScopes aggregated, final Map<Type, Set<DefinedElement>> knownElements, final Ecore2Logic ecore2Logic, final Ecore2Logic_Trace trace, final List<String> inconsistencies) {
    if (scope instanceof ClassTypeScope) {
      return _setSpecification((ClassTypeScope)scope, aggregated, knownElements, ecore2Logic, trace, inconsistencies);
    } else if (scope instanceof IntegerTypeScope) {
      return _setSpecification((IntegerTypeScope)scope, aggregated, knownElements, ecore2Logic, trace, inconsistencies);
    } else if (scope instanceof ObjectTypeScope) {
      return _setSpecification((ObjectTypeScope)scope, aggregated, knownElements, ecore2Logic, trace, inconsistencies);
    } else if (scope instanceof RealTypeScope) {
      return _setSpecification((RealTypeScope)scope, aggregated, knownElements, ecore2Logic, trace, inconsistencies);
    } else if (scope instanceof StringTypeScope) {
      return _setSpecification((StringTypeScope)scope, aggregated, knownElements, ecore2Logic, trace, inconsistencies);
    } else {
      throw new IllegalArgumentException("Unhandled parameter types: " +
        Arrays.<Object>asList(scope, aggregated, knownElements, ecore2Logic, trace, inconsistencies).toString());
    }
  }
  
  public int getLowerLimit(final NumberSpecification specification) {
    if (specification instanceof ExactNumber) {
      return _getLowerLimit((ExactNumber)specification);
    } else if (specification instanceof IntEnumberation) {
      return _getLowerLimit((IntEnumberation)specification);
    } else if (specification instanceof IntervallNumber) {
      return _getLowerLimit((IntervallNumber)specification);
    } else if (specification instanceof RealEnumeration) {
      return _getLowerLimit((RealEnumeration)specification);
    } else if (specification instanceof StringEnumeration) {
      return _getLowerLimit((StringEnumeration)specification);
    } else {
      throw new IllegalArgumentException("Unhandled parameter types: " +
        Arrays.<Object>asList(specification).toString());
    }
  }
  
  public int getUpperLimit(final NumberSpecification specification) {
    if (specification instanceof ExactNumber) {
      return _getUpperLimit((ExactNumber)specification);
    } else if (specification instanceof IntervallNumber) {
      return _getUpperLimit((IntervallNumber)specification);
    } else {
      throw new IllegalArgumentException("Unhandled parameter types: " +
        Arrays.<Object>asList(specification).toString());
    }
  }
}
