package hu.bme.mit.inf.dslreasoner.application.execution;

import com.google.inject.Guice;
import com.google.inject.Injector;
import hu.bme.mit.inf.dslreasoner.application.ApplicationConfigurationStandaloneSetup;
import hu.bme.mit.inf.dslreasoner.application.applicationConfiguration.ConfigurationScript;
import hu.bme.mit.inf.dslreasoner.application.execution.PatternLanguageWithRSModule;
import hu.bme.mit.inf.dslreasoner.application.execution.PatternLanguageWithRSSetup;
import hu.bme.mit.inf.dslreasoner.application.execution.ScriptConsole;
import hu.bme.mit.inf.dslreasoner.application.execution.ScriptExecutor;
import hu.bme.mit.inf.dslreasoner.application.execution.StandardOutputBasedScriptConsole;
import java.util.List;
import java.util.Map;
import org.eclipse.core.runtime.NullProgressMonitor;
import org.eclipse.emf.common.util.EList;
import org.eclipse.emf.common.util.URI;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.resource.Resource;
import org.eclipse.emf.ecore.util.EcoreUtil;
import org.eclipse.emf.ecore.xmi.impl.XMIResourceFactoryImpl;
import org.eclipse.viatra.query.patternlanguage.emf.EMFPatternLanguageStandaloneSetup;
import org.eclipse.viatra.query.runtime.api.ViatraQueryEngineOptions;
import org.eclipse.viatra.query.runtime.rete.matcher.ReteBackendFactory;
import org.eclipse.xtend2.lib.StringConcatenation;
import org.eclipse.xtext.resource.XtextResourceSet;
import org.eclipse.xtext.xbase.lib.Conversions;
import org.eclipse.xtext.xbase.lib.Exceptions;
import org.eclipse.xtext.xbase.lib.InputOutput;
import org.eclipse.xtext.xbase.lib.IterableExtensions;

@SuppressWarnings("all")
public class StandaloneScriptExecutor {
  public static void main(final String[] args) {
    int _size = ((List<String>)Conversions.doWrapArray(args)).size();
    boolean _equals = (_size == 1);
    if (_equals) {
      final String message = StandaloneScriptExecutor.executeScript(IterableExtensions.<String>head(((Iterable<String>)Conversions.doWrapArray(args))));
      if ((message != null)) {
        InputOutput.<String>println(message);
      }
    } else {
      int _size_1 = ((List<String>)Conversions.doWrapArray(args)).size();
      boolean _equals_1 = (_size_1 == 0);
      if (_equals_1) {
        StringConcatenation _builder = new StringConcatenation();
        _builder.append("Run generator with script file path as parameter!");
        InputOutput.<String>println(_builder.toString());
      } else {
        StringConcatenation _builder_1 = new StringConcatenation();
        _builder_1.append("Multiple arguments are not supported! Run generator with script file path as parameter!");
        InputOutput.<String>println(_builder_1.toString());
      }
    }
  }
  
  protected static Injector internalCreateInjector() {
    Injector newInjector = new EMFPatternLanguageStandaloneSetup().createInjectorAndDoEMFRegistration();
    final PatternLanguageWithRSModule module = new PatternLanguageWithRSModule();
    newInjector = Guice.createInjector(module);
    return newInjector;
  }
  
  public static ConfigurationScript loadScript(final String path) {
    final Injector i = new PatternLanguageWithRSSetup().createInjectorAndDoEMFRegistration();
    ApplicationConfigurationStandaloneSetup.doSetup();
    Map<String, Object> _extensionToFactoryMap = Resource.Factory.Registry.INSTANCE.getExtensionToFactoryMap();
    XMIResourceFactoryImpl _xMIResourceFactoryImpl = new XMIResourceFactoryImpl();
    _extensionToFactoryMap.put("xmi", _xMIResourceFactoryImpl);
    Map<String, Object> _extensionToFactoryMap_1 = Resource.Factory.Registry.INSTANCE.getExtensionToFactoryMap();
    XMIResourceFactoryImpl _xMIResourceFactoryImpl_1 = new XMIResourceFactoryImpl();
    _extensionToFactoryMap_1.put("logicproblem", _xMIResourceFactoryImpl_1);
    Map<String, Object> _extensionToFactoryMap_2 = Resource.Factory.Registry.INSTANCE.getExtensionToFactoryMap();
    XMIResourceFactoryImpl _xMIResourceFactoryImpl_2 = new XMIResourceFactoryImpl();
    _extensionToFactoryMap_2.put("partialmodel", _xMIResourceFactoryImpl_2);
    ViatraQueryEngineOptions.setSystemDefaultBackends(ReteBackendFactory.INSTANCE, ReteBackendFactory.INSTANCE, 
      ReteBackendFactory.INSTANCE);
    final String ext = IterableExtensions.<String>last(((Iterable<String>)Conversions.doWrapArray(path.split("\\."))));
    boolean _equals = ext.equals("vsconfig");
    if (_equals) {
      final XtextResourceSet resourceSet = i.<XtextResourceSet>getInstance(XtextResourceSet.class);
      Resource resource = null;
      try {
        resource = resourceSet.getResource(URI.createURI(path), true);
      } catch (final Throwable _t) {
        if (_t instanceof Exception) {
          final Exception e = (Exception)_t;
          StringConcatenation _builder = new StringConcatenation();
          _builder.append("Unable to load Configuration Script! ");
          String _message = e.getMessage();
          _builder.append(_message);
          final String message = _builder.toString();
          throw new IllegalArgumentException(message);
        } else {
          throw Exceptions.sneakyThrow(_t);
        }
      }
      EcoreUtil.resolveAll(resource);
      final EList<Resource.Diagnostic> errors = resource.getErrors();
      boolean _isEmpty = errors.isEmpty();
      if (_isEmpty) {
        final EObject content = IterableExtensions.<EObject>head(resource.getContents());
        if ((content instanceof ConfigurationScript)) {
          return ((ConfigurationScript)content);
        } else {
          StringConcatenation _builder = new StringConcatenation();
          _builder.append("Content is not a Configuration Script! (Found : ");
          String _simpleName = content.getClass().getSimpleName();
          _builder.append(_simpleName);
          _builder.append(")");
          final String message = _builder.toString();
          throw new IllegalArgumentException(message);
        }
      } else {
        StringConcatenation _builder_1 = new StringConcatenation();
        _builder_1.append("The Configuration Script contains ");
        int _size = errors.size();
        _builder_1.append(_size);
        _builder_1.append(" error");
        {
          int _size_1 = errors.size();
          boolean _greaterThan = (_size_1 > 1);
          if (_greaterThan) {
            _builder_1.append("s");
          }
        }
        _builder_1.append(":");
        _builder_1.newLineIfNotEmpty();
        {
          for(final Resource.Diagnostic error : errors) {
            _builder_1.append("\t");
            _builder_1.append("\t", "\t");
            String _message = error.getMessage();
            _builder_1.append(_message, "\t");
            _builder_1.newLineIfNotEmpty();
          }
        }
        final String message_1 = _builder_1.toString();
        throw new IllegalArgumentException(message_1);
      }
    } else {
      StringConcatenation _builder_2 = new StringConcatenation();
      _builder_2.append("Unsupported file extension: ");
      _builder_2.append(ext);
      throw new IllegalArgumentException(_builder_2.toString());
    }
  }
  
  public static String executeScript(final String path) {
    return StandaloneScriptExecutor.executeScript(path, StandardOutputBasedScriptConsole.FACTORY);
  }
  
  public static String executeScript(final String path, final ScriptConsole.Factory scriptConsoleFactory) {
    final ScriptExecutor executor = new ScriptExecutor(scriptConsoleFactory);
    try {
      final ConfigurationScript content = StandaloneScriptExecutor.loadScript(path);
      NullProgressMonitor _nullProgressMonitor = new NullProgressMonitor();
      executor.executeScript(content, _nullProgressMonitor);
      return null;
    } catch (final Throwable _t) {
      if (_t instanceof Exception) {
        final Exception e = (Exception)_t;
        return e.getMessage();
      } else {
        throw Exceptions.sneakyThrow(_t);
      }
    }
  }
}
