package hu.bme.mit.inf.dlsreasoner.alloy.reasoner;

import hu.bme.mit.inf.dlsreasoner.alloy.reasoner.AlloyBackendSolver;
import hu.bme.mit.inf.dlsreasoner.alloy.reasoner.TypeMappingTechnique;
import hu.bme.mit.inf.dslreasoner.logic.model.builder.LogicSolverConfiguration;

@SuppressWarnings("all")
public class AlloySolverConfiguration extends LogicSolverConfiguration {
  public int symmetry = 20;
  
  public AlloyBackendSolver solver = AlloyBackendSolver.SAT4J;
  
  public TypeMappingTechnique typeMapping = TypeMappingTechnique.InheritanceAndHorizontal;
  
  public int randomise = 0;
}
