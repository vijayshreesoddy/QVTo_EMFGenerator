package hu.bme.mit.inf.dslreasoner.ecore2logic;

@SuppressWarnings("all")
public class Ecore2LogicScope {
  public static final int Unlimited = (-1);
  
  public int numberOfObjects = Ecore2LogicScope.Unlimited;
}
