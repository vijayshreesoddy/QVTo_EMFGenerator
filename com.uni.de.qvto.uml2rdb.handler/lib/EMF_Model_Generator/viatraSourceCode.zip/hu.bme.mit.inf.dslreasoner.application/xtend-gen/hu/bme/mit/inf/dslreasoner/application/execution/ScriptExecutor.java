package hu.bme.mit.inf.dslreasoner.application.execution;

import com.google.common.base.Objects;
import com.google.common.collect.Iterables;
import hu.bme.mit.inf.dslreasoner.application.applicationConfiguration.Config;
import hu.bme.mit.inf.dslreasoner.application.applicationConfiguration.ConfigReference;
import hu.bme.mit.inf.dslreasoner.application.applicationConfiguration.ConfigSpecification;
import hu.bme.mit.inf.dslreasoner.application.applicationConfiguration.ConfigurationScript;
import hu.bme.mit.inf.dslreasoner.application.applicationConfiguration.CustomEntry;
import hu.bme.mit.inf.dslreasoner.application.applicationConfiguration.DocumentLevelSpecification;
import hu.bme.mit.inf.dslreasoner.application.applicationConfiguration.DocumentationEntry;
import hu.bme.mit.inf.dslreasoner.application.applicationConfiguration.EPackageImport;
import hu.bme.mit.inf.dslreasoner.application.applicationConfiguration.File;
import hu.bme.mit.inf.dslreasoner.application.applicationConfiguration.FileReference;
import hu.bme.mit.inf.dslreasoner.application.applicationConfiguration.FileSpecification;
import hu.bme.mit.inf.dslreasoner.application.applicationConfiguration.GenerationTask;
import hu.bme.mit.inf.dslreasoner.application.applicationConfiguration.GraphPattern;
import hu.bme.mit.inf.dslreasoner.application.applicationConfiguration.GraphPatternReference;
import hu.bme.mit.inf.dslreasoner.application.applicationConfiguration.MemoryEntry;
import hu.bme.mit.inf.dslreasoner.application.applicationConfiguration.Metamodel;
import hu.bme.mit.inf.dslreasoner.application.applicationConfiguration.MetamodelReference;
import hu.bme.mit.inf.dslreasoner.application.applicationConfiguration.MetamodelSpecification;
import hu.bme.mit.inf.dslreasoner.application.applicationConfiguration.Objective;
import hu.bme.mit.inf.dslreasoner.application.applicationConfiguration.ObjectiveReference;
import hu.bme.mit.inf.dslreasoner.application.applicationConfiguration.ObjectiveSpecification;
import hu.bme.mit.inf.dslreasoner.application.applicationConfiguration.PartialModel;
import hu.bme.mit.inf.dslreasoner.application.applicationConfiguration.PartialModelReference;
import hu.bme.mit.inf.dslreasoner.application.applicationConfiguration.PartialModelSpecification;
import hu.bme.mit.inf.dslreasoner.application.applicationConfiguration.PatternSpecification;
import hu.bme.mit.inf.dslreasoner.application.applicationConfiguration.RuntimeEntry;
import hu.bme.mit.inf.dslreasoner.application.applicationConfiguration.Scope;
import hu.bme.mit.inf.dslreasoner.application.applicationConfiguration.ScopeReference;
import hu.bme.mit.inf.dslreasoner.application.applicationConfiguration.ScopeSpecification;
import hu.bme.mit.inf.dslreasoner.application.applicationConfiguration.Task;
import hu.bme.mit.inf.dslreasoner.application.execution.GenerationTaskExecutor;
import hu.bme.mit.inf.dslreasoner.application.execution.ScriptConsole;
import hu.bme.mit.inf.dslreasoner.application.execution.util.ApplicationConfigurationParser;
import hu.bme.mit.inf.dslreasoner.logic.model.builder.DocumentationLevel;
import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.core.runtime.IStatus;
import org.eclipse.core.runtime.Status;
import org.eclipse.core.runtime.jobs.Job;
import org.eclipse.emf.common.util.URI;
import org.eclipse.emf.ecore.EPackage;
import org.eclipse.xtend.lib.annotations.FinalFieldsConstructor;
import org.eclipse.xtend2.lib.StringConcatenation;
import org.eclipse.xtext.xbase.lib.Conversions;
import org.eclipse.xtext.xbase.lib.Exceptions;
import org.eclipse.xtext.xbase.lib.ExclusiveRange;
import org.eclipse.xtext.xbase.lib.Functions.Function1;
import org.eclipse.xtext.xbase.lib.IterableExtensions;

@FinalFieldsConstructor
@SuppressWarnings("all")
public class ScriptExecutor {
  private final ApplicationConfigurationParser parser = new ApplicationConfigurationParser();
  
  private final ScriptConsole.Factory scriptConsoleFactory;
  
  /**
   * Executes a script
   */
  public void executeScript(final URI uri) {
    StringConcatenation _builder = new StringConcatenation();
    _builder.append("Model Generation: ");
    String _lastSegment = uri.lastSegment();
    _builder.append(_lastSegment);
    final Job job = new Job(_builder.toString()) {
      @Override
      protected IStatus run(final IProgressMonitor monitor) {
        try {
          StringConcatenation _builder = new StringConcatenation();
          _builder.append("Loading script");
          monitor.subTask(_builder.toString());
          final ConfigurationScript script = ScriptExecutor.this.parser.parse(uri);
          ScriptExecutor.this.executeScript(script, monitor);
          return Status.OK_STATUS;
        } catch (final Throwable _t) {
          if (_t instanceof Exception) {
            return Status.OK_STATUS;
          } else {
            throw Exceptions.sneakyThrow(_t);
          }
        }
      }
    };
    job.setUser(true);
    job.schedule();
  }
  
  public void executeScript(final ConfigurationScript script, final IProgressMonitor monitor) {
    this.activateAllEPackageReferences(script);
    final Iterable<Task> tasks = Iterables.<Task>filter(script.getCommands(), Task.class);
    final ScriptConsole intermediateScriptConsole = this.scriptConsoleFactory.createScriptConsole(false, null, null, null);
    int _size = IterableExtensions.size(tasks);
    ExclusiveRange _doubleDotLessThan = new ExclusiveRange(0, _size, true);
    for (final Integer taskIndex : _doubleDotLessThan) {
      {
        if (((taskIndex).intValue() > 0)) {
          ScriptExecutor.restForMeasurements(intermediateScriptConsole);
        }
        final Task task = ((Task[])Conversions.unwrapArray(tasks, Task.class))[(taskIndex).intValue()];
        StringConcatenation _builder = new StringConcatenation();
        _builder.append("Executing task");
        {
          int _size_1 = IterableExtensions.size(tasks);
          boolean _greaterThan = (_size_1 > 1);
          if (_greaterThan) {
            _builder.append(" ");
            _builder.append(((taskIndex).intValue() + 1));
          }
        }
        _builder.append(": ");
        CharSequence _name = this.getName(task);
        _builder.append(_name);
        monitor.beginTask(_builder.toString(), this.getTotalWork(task));
        this.execute(task, monitor);
      }
    }
  }
  
  private void activateAllEPackageReferences(final ConfigurationScript script) {
    final Function1<EPackageImport, String> _function = (EPackageImport it) -> {
      return it.getImportedPackage().getNsURI();
    };
    final Map<String, EPackageImport> ecoreImports = IterableExtensions.<String, EPackageImport>toMap(Iterables.<EPackageImport>filter(script.getImports(), EPackageImport.class), _function);
    final EPackage.Registry packageRegistry = script.eResource().getResourceSet().getPackageRegistry();
    Set<Map.Entry<String, EPackageImport>> _entrySet = ecoreImports.entrySet();
    for (final Map.Entry<String, EPackageImport> entry : _entrySet) {
      packageRegistry.put(entry.getKey(), entry.getValue().getImportedPackage());
    }
  }
  
  protected void _execute(final GenerationTask task, final IProgressMonitor monitor) {
    final GenerationTaskExecutor generationTaskExecutor = new GenerationTaskExecutor();
    generationTaskExecutor.executeGenerationTask(task, this, this.scriptConsoleFactory, monitor);
  }
  
  protected void _execute(final Task task, final IProgressMonitor monitor) {
    StringConcatenation _builder = new StringConcatenation();
    _builder.append("Unsupported task type: ");
    String _simpleName = task.getClass().getSimpleName();
    _builder.append(_simpleName);
    _builder.append("!");
    throw new IllegalArgumentException(_builder.toString());
  }
  
  /**
   * Mapping time = 100
   * Solving = 1000 * runs
   * Visualisation = 1000 * runs
   */
  protected int _getTotalWork(final GenerationTask task) {
    int _xifexpression = (int) 0;
    boolean _isRunSpecified = task.isRunSpecified();
    if (_isRunSpecified) {
      _xifexpression = task.getRuns();
    } else {
      _xifexpression = 1;
    }
    final int runs = _xifexpression;
    int _xifexpression_1 = (int) 0;
    boolean _isNumberSpecified = task.isNumberSpecified();
    if (_isNumberSpecified) {
      _xifexpression_1 = task.getNumber();
    } else {
      _xifexpression_1 = 1;
    }
    final int number = _xifexpression_1;
    return ((100 + (runs * 1000)) + (runs * 1000));
  }
  
  protected int _getTotalWork(final Task task) {
    StringConcatenation _builder = new StringConcatenation();
    _builder.append("Unsupported task type: ");
    String _simpleName = task.getClass().getSimpleName();
    _builder.append(_simpleName);
    _builder.append("!");
    throw new IllegalArgumentException(_builder.toString());
  }
  
  protected CharSequence _getName(final GenerationTask task) {
    StringConcatenation _builder = new StringConcatenation();
    _builder.append("Model Generation");
    return _builder;
  }
  
  protected CharSequence _getName(final Task task) {
    StringConcatenation _builder = new StringConcatenation();
    _builder.append("Unsupported task type: ");
    String _simpleName = task.getClass().getSimpleName();
    _builder.append(_simpleName);
    _builder.append("!");
    throw new IllegalArgumentException(_builder.toString());
  }
  
  protected MetamodelSpecification _getMetamodelSpecification(final MetamodelSpecification config) {
    return config;
  }
  
  protected MetamodelSpecification _getMetamodelSpecification(final MetamodelReference config) {
    return config.getReferred().getSpecification();
  }
  
  protected MetamodelSpecification _getMetamodelSpecification(final Void config) {
    return null;
  }
  
  protected PatternSpecification _getPatternSpecification(final PatternSpecification config) {
    return config;
  }
  
  protected PatternSpecification _getPatternSpecification(final GraphPatternReference config) {
    return config.getReferred().getSpecification();
  }
  
  protected PatternSpecification _getPatternSpecification(final Void config) {
    return null;
  }
  
  protected PartialModelSpecification _getPartialModelSpecification(final PartialModelSpecification config) {
    return config;
  }
  
  protected PartialModelSpecification _getPartialModelSpecification(final PartialModelReference config) {
    return config.getReferred().getSpecification();
  }
  
  protected PartialModelSpecification _getPartialModelSpecification(final Void config) {
    return null;
  }
  
  protected FileSpecification _getFileSpecification(final FileSpecification config) {
    return config;
  }
  
  protected FileSpecification _getFileSpecification(final FileReference config) {
    return config.getReferred().getSpecification();
  }
  
  protected FileSpecification _getFileSpecification(final Void config) {
    return null;
  }
  
  protected ScopeSpecification _getScopeSpecification(final ScopeSpecification config) {
    return config;
  }
  
  protected ScopeSpecification _getScopeSpecification(final ScopeReference config) {
    return config.getReferred().getSpecification();
  }
  
  protected ScopeSpecification _getScopeSpecification(final Void config) {
    return null;
  }
  
  protected ObjectiveSpecification _getObjectiveSpecification(final ObjectiveSpecification config) {
    return config;
  }
  
  protected ObjectiveSpecification _getObjectiveSpecification(final ObjectiveReference config) {
    return config.getReferred().getSpecification();
  }
  
  protected ObjectiveSpecification _getObjectiveSpecification(final Void config) {
    return null;
  }
  
  protected ConfigSpecification _getConfiguration(final ConfigSpecification config) {
    return config;
  }
  
  protected ConfigSpecification _getConfiguration(final ConfigReference config) {
    return config.getConfig().getSpecification();
  }
  
  protected ConfigSpecification _getConfiguration(final Void config) {
    return null;
  }
  
  public LinkedHashMap<String, String> transformToMap(final ConfigSpecification config) {
    final LinkedHashMap<String, String> map = new LinkedHashMap<String, String>();
    boolean _notEquals = (!Objects.equal(config, null));
    if (_notEquals) {
      Iterable<CustomEntry> _filter = Iterables.<CustomEntry>filter(config.getEntries(), CustomEntry.class);
      for (final CustomEntry entry : _filter) {
        map.put(entry.getKey(), entry.getValue());
      }
    }
    return map;
  }
  
  public Optional<Integer> getRuntimeLimit(final ConfigSpecification config) {
    if ((config == null)) {
      return Optional.<Integer>empty();
    } else {
      final RuntimeEntry runtimeEntry = IterableExtensions.<RuntimeEntry>head(Iterables.<RuntimeEntry>filter(config.getEntries(), RuntimeEntry.class));
      if ((runtimeEntry != null)) {
        return Optional.<Integer>of(Integer.valueOf(runtimeEntry.getMillisecLimit()));
      } else {
        return Optional.<Integer>empty();
      }
    }
  }
  
  public Optional<Integer> getMemoryLimit(final ConfigSpecification config) {
    if ((config == null)) {
      return Optional.<Integer>empty();
    } else {
      final MemoryEntry memoryEntry = IterableExtensions.<MemoryEntry>head(Iterables.<MemoryEntry>filter(config.getEntries(), MemoryEntry.class));
      if ((memoryEntry != null)) {
        return Optional.<Integer>of(Integer.valueOf(memoryEntry.getMegabyteLimit()));
      } else {
        return Optional.<Integer>empty();
      }
    }
  }
  
  public Optional<DocumentationLevel> getDocumentation(final ConfigSpecification config) {
    if ((config == null)) {
      return Optional.<DocumentationLevel>empty();
    } else {
      final DocumentationEntry documentationEntry = IterableExtensions.<DocumentationEntry>head(Iterables.<DocumentationEntry>filter(config.getEntries(), DocumentationEntry.class));
      if ((documentationEntry != null)) {
        final DocumentLevelSpecification value = documentationEntry.getLevel();
        DocumentationLevel _xifexpression = null;
        if ((value == DocumentLevelSpecification.FULL)) {
          _xifexpression = DocumentationLevel.FULL;
        } else {
          DocumentationLevel _xifexpression_1 = null;
          if ((value == DocumentLevelSpecification.NORMAL)) {
            _xifexpression_1 = DocumentationLevel.NORMAL;
          } else {
            DocumentationLevel _xifexpression_2 = null;
            if ((value == DocumentLevelSpecification.NONE)) {
              _xifexpression_2 = DocumentationLevel.NONE;
            } else {
              StringConcatenation _builder = new StringConcatenation();
              _builder.append("Unable to translate documentation level \"");
              _builder.append(value);
              _builder.append("\"!");
              throw new UnsupportedOperationException(_builder.toString());
            }
            _xifexpression_1 = _xifexpression_2;
          }
          _xifexpression = _xifexpression_1;
        }
        final DocumentationLevel translatedValue = _xifexpression;
        return Optional.<DocumentationLevel>of(translatedValue);
      }
    }
    return null;
  }
  
  private static final boolean measuring = true;
  
  public static void restForMeasurements(final ScriptConsole console) {
    try {
      if (ScriptExecutor.measuring) {
        if ((console != null)) {
          StringConcatenation _builder = new StringConcatenation();
          _builder.append("Cleaning memory.");
          console.writeMessage(_builder.toString());
        }
        System.gc();
        System.gc();
        System.gc();
        Thread.sleep(2500);
      }
    } catch (Throwable _e) {
      throw Exceptions.sneakyThrow(_e);
    }
  }
  
  public void execute(final Task task, final IProgressMonitor monitor) {
    if (task instanceof GenerationTask) {
      _execute((GenerationTask)task, monitor);
      return;
    } else if (task != null) {
      _execute(task, monitor);
      return;
    } else {
      throw new IllegalArgumentException("Unhandled parameter types: " +
        Arrays.<Object>asList(task, monitor).toString());
    }
  }
  
  protected int getTotalWork(final Task task) {
    if (task instanceof GenerationTask) {
      return _getTotalWork((GenerationTask)task);
    } else if (task != null) {
      return _getTotalWork(task);
    } else {
      throw new IllegalArgumentException("Unhandled parameter types: " +
        Arrays.<Object>asList(task).toString());
    }
  }
  
  protected CharSequence getName(final Task task) {
    if (task instanceof GenerationTask) {
      return _getName((GenerationTask)task);
    } else if (task != null) {
      return _getName(task);
    } else {
      throw new IllegalArgumentException("Unhandled parameter types: " +
        Arrays.<Object>asList(task).toString());
    }
  }
  
  public MetamodelSpecification getMetamodelSpecification(final Metamodel config) {
    if (config instanceof MetamodelReference) {
      return _getMetamodelSpecification((MetamodelReference)config);
    } else if (config instanceof MetamodelSpecification) {
      return _getMetamodelSpecification((MetamodelSpecification)config);
    } else if (config == null) {
      return _getMetamodelSpecification((Void)null);
    } else {
      throw new IllegalArgumentException("Unhandled parameter types: " +
        Arrays.<Object>asList(config).toString());
    }
  }
  
  public PatternSpecification getPatternSpecification(final GraphPattern config) {
    if (config instanceof GraphPatternReference) {
      return _getPatternSpecification((GraphPatternReference)config);
    } else if (config instanceof PatternSpecification) {
      return _getPatternSpecification((PatternSpecification)config);
    } else if (config == null) {
      return _getPatternSpecification((Void)null);
    } else {
      throw new IllegalArgumentException("Unhandled parameter types: " +
        Arrays.<Object>asList(config).toString());
    }
  }
  
  public PartialModelSpecification getPartialModelSpecification(final PartialModel config) {
    if (config instanceof PartialModelReference) {
      return _getPartialModelSpecification((PartialModelReference)config);
    } else if (config instanceof PartialModelSpecification) {
      return _getPartialModelSpecification((PartialModelSpecification)config);
    } else if (config == null) {
      return _getPartialModelSpecification((Void)null);
    } else {
      throw new IllegalArgumentException("Unhandled parameter types: " +
        Arrays.<Object>asList(config).toString());
    }
  }
  
  public FileSpecification getFileSpecification(final File config) {
    if (config instanceof FileReference) {
      return _getFileSpecification((FileReference)config);
    } else if (config instanceof FileSpecification) {
      return _getFileSpecification((FileSpecification)config);
    } else if (config == null) {
      return _getFileSpecification((Void)null);
    } else {
      throw new IllegalArgumentException("Unhandled parameter types: " +
        Arrays.<Object>asList(config).toString());
    }
  }
  
  public ScopeSpecification getScopeSpecification(final Scope config) {
    if (config instanceof ScopeReference) {
      return _getScopeSpecification((ScopeReference)config);
    } else if (config instanceof ScopeSpecification) {
      return _getScopeSpecification((ScopeSpecification)config);
    } else if (config == null) {
      return _getScopeSpecification((Void)null);
    } else {
      throw new IllegalArgumentException("Unhandled parameter types: " +
        Arrays.<Object>asList(config).toString());
    }
  }
  
  public ObjectiveSpecification getObjectiveSpecification(final Objective config) {
    if (config instanceof ObjectiveReference) {
      return _getObjectiveSpecification((ObjectiveReference)config);
    } else if (config instanceof ObjectiveSpecification) {
      return _getObjectiveSpecification((ObjectiveSpecification)config);
    } else if (config == null) {
      return _getObjectiveSpecification((Void)null);
    } else {
      throw new IllegalArgumentException("Unhandled parameter types: " +
        Arrays.<Object>asList(config).toString());
    }
  }
  
  public ConfigSpecification getConfiguration(final Config config) {
    if (config instanceof ConfigReference) {
      return _getConfiguration((ConfigReference)config);
    } else if (config instanceof ConfigSpecification) {
      return _getConfiguration((ConfigSpecification)config);
    } else if (config == null) {
      return _getConfiguration((Void)null);
    } else {
      throw new IllegalArgumentException("Unhandled parameter types: " +
        Arrays.<Object>asList(config).toString());
    }
  }
  
  public ScriptExecutor(final ScriptConsole.Factory scriptConsoleFactory) {
    super();
    this.scriptConsoleFactory = scriptConsoleFactory;
  }
}
