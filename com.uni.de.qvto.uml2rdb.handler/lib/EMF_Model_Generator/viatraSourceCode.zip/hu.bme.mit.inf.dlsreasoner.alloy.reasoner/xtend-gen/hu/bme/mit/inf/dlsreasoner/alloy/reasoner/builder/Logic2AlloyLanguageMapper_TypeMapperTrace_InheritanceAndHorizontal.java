package hu.bme.mit.inf.dlsreasoner.alloy.reasoner.builder;

import hu.bme.mit.inf.dlsreasoner.alloy.reasoner.builder.Logic2AlloyLanguageMapper_TypeMapperTrace;
import hu.bme.mit.inf.dslreasoner.alloyLanguage.ALSSignatureDeclaration;
import hu.bme.mit.inf.dslreasoner.logic.model.logiclanguage.DefinedElement;
import hu.bme.mit.inf.dslreasoner.logic.model.logiclanguage.Type;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@SuppressWarnings("all")
public class Logic2AlloyLanguageMapper_TypeMapperTrace_InheritanceAndHorizontal implements Logic2AlloyLanguageMapper_TypeMapperTrace {
  public ALSSignatureDeclaration objectSupperClass;
  
  public final Map<Type, ALSSignatureDeclaration> type2ALSType = new HashMap<Type, ALSSignatureDeclaration>();
  
  public final Map<DefinedElement, ALSSignatureDeclaration> definedElement2Declaration = new HashMap<DefinedElement, ALSSignatureDeclaration>();
  
  public final Map<Type, List<ALSSignatureDeclaration>> typeSelection = new HashMap<Type, List<ALSSignatureDeclaration>>();
}
