package hu.bme.mit.inf.dslreasoner.application.execution;

import hu.bme.mit.inf.dslreasoner.application.applicationConfiguration.ConfigSpecification;
import hu.bme.mit.inf.dslreasoner.application.applicationConfiguration.ConfigurationScript;
import hu.bme.mit.inf.dslreasoner.application.applicationConfiguration.FileSpecification;
import hu.bme.mit.inf.dslreasoner.application.applicationConfiguration.GenerationTask;
import hu.bme.mit.inf.dslreasoner.application.applicationConfiguration.MetamodelSpecification;
import hu.bme.mit.inf.dslreasoner.application.applicationConfiguration.ObjectiveEntry;
import hu.bme.mit.inf.dslreasoner.application.applicationConfiguration.ObjectiveSpecification;
import hu.bme.mit.inf.dslreasoner.application.applicationConfiguration.PartialModelSpecification;
import hu.bme.mit.inf.dslreasoner.application.applicationConfiguration.PatternSpecification;
import hu.bme.mit.inf.dslreasoner.application.applicationConfiguration.ScopeSpecification;
import hu.bme.mit.inf.dslreasoner.application.execution.EclipseBasedProgressMonitor;
import hu.bme.mit.inf.dslreasoner.application.execution.MetamodelLoader;
import hu.bme.mit.inf.dslreasoner.application.execution.ModelLoader;
import hu.bme.mit.inf.dslreasoner.application.execution.NullWorkspace;
import hu.bme.mit.inf.dslreasoner.application.execution.QueryLoader;
import hu.bme.mit.inf.dslreasoner.application.execution.ScopeLoader;
import hu.bme.mit.inf.dslreasoner.application.execution.ScriptConsole;
import hu.bme.mit.inf.dslreasoner.application.execution.ScriptConsoleDecorator;
import hu.bme.mit.inf.dslreasoner.application.execution.ScriptExecutor;
import hu.bme.mit.inf.dslreasoner.application.execution.SolverLoader;
import hu.bme.mit.inf.dslreasoner.ecore2logic.Ecore2Logic;
import hu.bme.mit.inf.dslreasoner.ecore2logic.Ecore2LogicConfiguration;
import hu.bme.mit.inf.dslreasoner.ecore2logic.Ecore2Logic_Trace;
import hu.bme.mit.inf.dslreasoner.ecore2logic.EcoreMetamodelDescriptor;
import hu.bme.mit.inf.dslreasoner.logic.model.builder.DocumentationLevel;
import hu.bme.mit.inf.dslreasoner.logic.model.builder.LogicModelInterpretation;
import hu.bme.mit.inf.dslreasoner.logic.model.builder.LogicReasoner;
import hu.bme.mit.inf.dslreasoner.logic.model.builder.LogicSolverConfiguration;
import hu.bme.mit.inf.dslreasoner.logic.model.builder.SolutionScope;
import hu.bme.mit.inf.dslreasoner.logic.model.builder.TracedOutput;
import hu.bme.mit.inf.dslreasoner.logic.model.builder.TypeScopes;
import hu.bme.mit.inf.dslreasoner.logic.model.logicproblem.LogicProblem;
import hu.bme.mit.inf.dslreasoner.logic.model.logicresult.InconsistencyResult;
import hu.bme.mit.inf.dslreasoner.logic.model.logicresult.LogicResult;
import hu.bme.mit.inf.dslreasoner.logic.model.logicresult.ModelResult;
import hu.bme.mit.inf.dslreasoner.logic.model.logicresult.StatisticEntry;
import hu.bme.mit.inf.dslreasoner.logic.model.logicresult.UnknownResult;
import hu.bme.mit.inf.dslreasoner.logic.model.statistics.StatisticSections2CSV;
import hu.bme.mit.inf.dslreasoner.logic2ecore.Logic2Ecore;
import hu.bme.mit.inf.dslreasoner.viatra2logic.Viatra2Logic;
import hu.bme.mit.inf.dslreasoner.viatra2logic.Viatra2LogicConfiguration;
import hu.bme.mit.inf.dslreasoner.viatra2logic.ViatraQuerySetDescriptor;
import hu.bme.mit.inf.dslreasoner.viatrasolver.partialinterpretation2logic.InstanceModel2Logic;
import hu.bme.mit.inf.dslreasoner.viatrasolver.partialinterpretationlanguage.partialinterpretation.PartialInterpretation;
import hu.bme.mit.inf.dslreasoner.viatrasolver.partialinterpretationlanguage.visualisation.PartialInterpretation2Gml;
import hu.bme.mit.inf.dslreasoner.viatrasolver.partialinterpretationlanguage.visualisation.PartialInterpretationVisualisation;
import hu.bme.mit.inf.dslreasoner.visualisation.pi2graphviz.GraphvizVisualiser;
import hu.bme.mit.inf.dslreasoner.workspace.ReasonerWorkspace;
import hu.bme.mit.inf.dslreasoner.workspace.URIBasedWorkspace;
import java.io.File;
import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.function.Consumer;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.emf.common.util.EList;
import org.eclipse.emf.common.util.URI;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.viatra.query.patternlanguage.emf.vql.Pattern;
import org.eclipse.xtend2.lib.StringConcatenation;
import org.eclipse.xtext.xbase.lib.CollectionLiterals;
import org.eclipse.xtext.xbase.lib.Conversions;
import org.eclipse.xtext.xbase.lib.Exceptions;
import org.eclipse.xtext.xbase.lib.ExclusiveRange;
import org.eclipse.xtext.xbase.lib.Functions.Function1;
import org.eclipse.xtext.xbase.lib.IntegerRange;
import org.eclipse.xtext.xbase.lib.IterableExtensions;
import org.eclipse.xtext.xbase.lib.ObjectExtensions;
import org.eclipse.xtext.xbase.lib.Pair;
import org.eclipse.xtext.xbase.lib.Procedures.Procedure1;

@SuppressWarnings("all")
public class GenerationTaskExecutor {
  private final MetamodelLoader metamodelLoader = new MetamodelLoader();
  
  private final ModelLoader modelLoader = new ModelLoader();
  
  private final QueryLoader queryLoader = new QueryLoader();
  
  private final SolverLoader solverLoader = new SolverLoader();
  
  private final ScopeLoader scopeLoader = new ScopeLoader();
  
  private final StatisticSections2CSV statisticsUtil = new StatisticSections2CSV();
  
  public void executeGenerationTask(final GenerationTask task, final ScriptExecutor scriptExecutor, final ScriptConsole.Factory scriptConsoleFactory, final IProgressMonitor monitor) {
    StringConcatenation _builder = new StringConcatenation();
    _builder.append("Collecting all resources");
    monitor.subTask(_builder.toString());
    final MetamodelSpecification metamodelSpecification = scriptExecutor.getMetamodelSpecification(task.getMetamodel());
    final PatternSpecification patternSpecification = scriptExecutor.getPatternSpecification(task.getPatterns());
    final PartialModelSpecification partialmodelSpecification = scriptExecutor.getPartialModelSpecification(task.getPartialModel());
    final ScopeSpecification scopeSpecification = scriptExecutor.getScopeSpecification(task.getScope());
    final FileSpecification messageFile = scriptExecutor.getFileSpecification(task.getTargetLogFile());
    final FileSpecification debugFolder = scriptExecutor.getFileSpecification(task.getDebugFolder());
    final FileSpecification outputFolder = scriptExecutor.getFileSpecification(task.getTagetFolder());
    final FileSpecification statisticsFile = scriptExecutor.getFileSpecification(task.getTargetStatisticsFile());
    final ConfigSpecification configSpecification = scriptExecutor.getConfiguration(task.getConfig());
    final LinkedHashMap<String, String> configurationMap = scriptExecutor.transformToMap(configSpecification);
    final Optional<DocumentationLevel> documentationLevel = scriptExecutor.getDocumentation(configSpecification);
    final Optional<Integer> runtieLimit = scriptExecutor.getRuntimeLimit(configSpecification);
    final Optional<Integer> memoryLimit = scriptExecutor.getMemoryLimit(configSpecification);
    URI _xifexpression = null;
    if ((messageFile != null)) {
      _xifexpression = URI.createURI(messageFile.getPath());
    } else {
      _xifexpression = null;
    }
    URI _xifexpression_1 = null;
    if ((debugFolder != null)) {
      StringConcatenation _builder_1 = new StringConcatenation();
      String _path = debugFolder.getPath();
      _builder_1.append(_path);
      _builder_1.append("/errors.txt");
      _xifexpression_1 = URI.createURI(_builder_1.toString());
    } else {
      _xifexpression_1 = null;
    }
    URI _xifexpression_2 = null;
    if ((statisticsFile != null)) {
      _xifexpression_2 = URI.createURI(statisticsFile.getPath());
    } else {
      _xifexpression_2 = null;
    }
    final ScriptConsole console = scriptConsoleFactory.createScriptConsole(false, _xifexpression, _xifexpression_1, _xifexpression_2);
    try {
      ReasonerWorkspace _xifexpression_3 = null;
      if ((debugFolder != null)) {
        String _path_1 = debugFolder.getPath();
        _xifexpression_3 = new URIBasedWorkspace(_path_1, "");
      } else {
        _xifexpression_3 = new NullWorkspace();
      }
      final ReasonerWorkspace reasonerWorkspace = _xifexpression_3;
      reasonerWorkspace.init();
      ReasonerWorkspace _xifexpression_4 = null;
      if ((outputFolder != null)) {
        String _path_2 = outputFolder.getPath();
        _xifexpression_4 = new URIBasedWorkspace(_path_2, "");
      } else {
        _xifexpression_4 = new NullWorkspace();
      }
      final ReasonerWorkspace outputWorkspace = _xifexpression_4;
      outputWorkspace.init();
      EcoreMetamodelDescriptor _xifexpression_5 = null;
      if ((metamodelSpecification != null)) {
        _xifexpression_5 = this.metamodelLoader.loadMetamodel(metamodelSpecification);
      } else {
        StringConcatenation _builder_2 = new StringConcatenation();
        _builder_2.append("Error during the loading of the metamodel: No metamodel specified!");
        console.writeError(_builder_2.toString());
        StringConcatenation _builder_3 = new StringConcatenation();
        _builder_3.append("No metamodel is specified!");
        throw new IllegalArgumentException(_builder_3.toString());
      }
      final EcoreMetamodelDescriptor metamodelDescriptor = _xifexpression_5;
      Pair<ViatraQuerySetDescriptor, Set<Pattern>> _xifexpression_6 = null;
      if ((patternSpecification != null)) {
        _xifexpression_6 = this.queryLoader.loadQueries(patternSpecification);
      } else {
        _xifexpression_6 = null;
      }
      final Pair<ViatraQuerySetDescriptor, Set<Pattern>> queryDescriptor = _xifexpression_6;
      List<EObject> _xifexpression_7 = null;
      if ((partialmodelSpecification != null)) {
        _xifexpression_7 = this.modelLoader.loadModel(partialmodelSpecification, scriptExecutor);
      } else {
        _xifexpression_7 = null;
      }
      final List<EObject> partialModelDescriptor = _xifexpression_7;
      monitor.worked(50);
      StringConcatenation _builder_4 = new StringConcatenation();
      _builder_4.append("Translating all resources to logic");
      monitor.subTask(_builder_4.toString());
      long domain2LogicTransformationTime = System.nanoTime();
      final Ecore2Logic ecore2Logic = new Ecore2Logic();
      final Logic2Ecore logic2Ecore = new Logic2Ecore(ecore2Logic);
      final Viatra2Logic viatra2Logic = new Viatra2Logic(ecore2Logic);
      final InstanceModel2Logic instanceModel2Logic = new InstanceModel2Logic();
      Ecore2LogicConfiguration _ecore2LogicConfiguration = new Ecore2LogicConfiguration();
      TracedOutput<LogicProblem, Ecore2Logic_Trace> modelGeneration = ecore2Logic.transformMetamodel(metamodelDescriptor, _ecore2LogicConfiguration);
      LogicProblem problem = modelGeneration.getOutput();
      if ((partialModelDescriptor != null)) {
        problem = instanceModel2Logic.transform(modelGeneration, partialModelDescriptor).getOutput();
      }
      if ((queryDescriptor != null)) {
        Viatra2LogicConfiguration _viatra2LogicConfiguration = new Viatra2LogicConfiguration();
        problem = viatra2Logic.transformQueries(
          queryDescriptor.getKey(), modelGeneration, _viatra2LogicConfiguration).getOutput();
      }
      long _nanoTime = System.nanoTime();
      long _minus = (_nanoTime - domain2LogicTransformationTime);
      domain2LogicTransformationTime = _minus;
      boolean _atLeastNormal = this.atLeastNormal(documentationLevel);
      if (_atLeastNormal) {
        reasonerWorkspace.writeModel(problem, "generation.logicproblem");
      }
      final LogicReasoner solver = this.solverLoader.loadSolver(task.getSolver(), configurationMap);
      final ObjectiveSpecification objectiveSpecification = scriptExecutor.getObjectiveSpecification(task.getObjectives());
      List<ObjectiveEntry> _elvis = null;
      EList<ObjectiveEntry> _entries = null;
      if (objectiveSpecification!=null) {
        _entries=objectiveSpecification.getEntries();
      }
      if (_entries != null) {
        _elvis = _entries;
      } else {
        List<ObjectiveEntry> _emptyList = CollectionLiterals.<ObjectiveEntry>emptyList();
        _elvis = _emptyList;
      }
      final List<ObjectiveEntry> objectiveEntries = _elvis;
      final LogicSolverConfiguration solverConfig = this.solverLoader.loadSolverConfig(task.getSolver(), configurationMap, objectiveEntries, console);
      SolutionScope _solutionScope = new SolutionScope();
      final Procedure1<SolutionScope> _function = (SolutionScope it) -> {
        int _xifexpression_8 = (int) 0;
        boolean _isNumberSpecified = task.isNumberSpecified();
        if (_isNumberSpecified) {
          _xifexpression_8 = task.getNumber();
        } else {
          _xifexpression_8 = 1;
        }
        it.numberOfRequiredSolutions = _xifexpression_8;
      };
      SolutionScope _doubleArrow = ObjectExtensions.<SolutionScope>operator_doubleArrow(_solutionScope, _function);
      solverConfig.solutionScope = _doubleArrow;
      final Pair<TypeScopes, LinkedList<String>> typeScopes = this.scopeLoader.loadScope(scopeSpecification, problem, ecore2Logic, 
        modelGeneration.getTrace());
      boolean _isEmpty = typeScopes.getValue().isEmpty();
      boolean _not = (!_isEmpty);
      if (_not) {
        monitor.worked(50);
        console.writeMessage("Model generation started");
        final Consumer<String> _function_1 = (String it) -> {
          console.writeMessage(it);
        };
        typeScopes.getValue().forEach(_function_1);
        int _xifexpression_8 = (int) 0;
        boolean _isRunSpecified = task.isRunSpecified();
        if (_isRunSpecified) {
          _xifexpression_8 = task.getRuns();
        } else {
          _xifexpression_8 = 1;
        }
        final int runs = _xifexpression_8;
        IntegerRange _upTo = new IntegerRange(1, runs);
        for (final Integer run : _upTo) {
          {
            StringConcatenation _builder_5 = new StringConcatenation();
            _builder_5.append("Problem is inconsistent, no model is created!");
            console.writeMessage(_builder_5.toString());
            final LinkedHashMap<String, Object> statistics = new LinkedHashMap<String, Object>();
            EObject _eContainer = task.eContainer();
            int _indexOf = ((ConfigurationScript) _eContainer).getCommands().indexOf(task);
            int _plus = (_indexOf + 1);
            statistics.put("Task", Integer.valueOf(_plus));
            statistics.put("Run", run);
            statistics.put("Result", "InconsistencyResult");
            statistics.put("Domain to logic transformation time", Long.valueOf((domain2LogicTransformationTime / 1000000)));
            statistics.put("Logic to solver transformation time", Integer.valueOf(0));
            statistics.put("Solver time", Integer.valueOf(0));
            statistics.put("Postprocessing time", Integer.valueOf(0));
            console.addStatistics(statistics);
          }
        }
      } else {
        solverConfig.typeScopes = typeScopes.getKey();
        final Consumer<DocumentationLevel> _function_2 = (DocumentationLevel it) -> {
          solverConfig.documentationLevel = it;
        };
        documentationLevel.ifPresent(_function_2);
        final Consumer<Integer> _function_3 = (Integer it) -> {
          solverConfig.runtimeLimit = (it).intValue();
        };
        runtieLimit.ifPresent(_function_3);
        final Consumer<Integer> _function_4 = (Integer it) -> {
          solverConfig.memoryLimit = (it).intValue();
        };
        memoryLimit.ifPresent(_function_4);
        int _xifexpression_9 = (int) 0;
        boolean _isRunSpecified_1 = task.isRunSpecified();
        if (_isRunSpecified_1) {
          _xifexpression_9 = task.getRuns();
        } else {
          _xifexpression_9 = 1;
        }
        final int runs_1 = _xifexpression_9;
        monitor.worked(50);
        console.writeMessage("Model generation started");
        IntegerRange _upTo_1 = new IntegerRange(1, runs_1);
        for (final Integer run_1 : _upTo_1) {
          {
            if (((run_1).intValue() > 1)) {
              ScriptExecutor.restForMeasurements(console);
            }
            StringConcatenation _builder_5 = new StringConcatenation();
            _builder_5.append("Solving problem");
            {
              if ((runs_1 > 0)) {
                _builder_5.append(" ");
                _builder_5.append(run_1);
                _builder_5.append("/");
                _builder_5.append(runs_1);
              }
            }
            monitor.subTask(_builder_5.toString());
            final EclipseBasedProgressMonitor visualisationProgressMonitor = new EclipseBasedProgressMonitor(monitor);
            this.solverLoader.setRunIndex(solverConfig, configurationMap, (run_1).intValue(), console);
            EclipseBasedProgressMonitor _eclipseBasedProgressMonitor = new EclipseBasedProgressMonitor(monitor);
            solverConfig.progressMonitor = _eclipseBasedProgressMonitor;
            ReasonerWorkspace _xifexpression_10 = null;
            if ((runs_1 > 1)) {
              StringConcatenation _builder_6 = new StringConcatenation();
              _builder_6.append("run");
              _builder_6.append(run_1);
              ReasonerWorkspace _subWorkspace = reasonerWorkspace.subWorkspace(_builder_6.toString(), "");
              final Procedure1<ReasonerWorkspace> _function_5 = (ReasonerWorkspace it) -> {
                it.initAndClear();
              };
              _xifexpression_10 = ObjectExtensions.<ReasonerWorkspace>operator_doubleArrow(_subWorkspace, _function_5);
            } else {
              _xifexpression_10 = reasonerWorkspace;
            }
            final ReasonerWorkspace reasonerWorkspaceForRun = _xifexpression_10;
            final LogicResult solution = solver.solve(problem, solverConfig, reasonerWorkspaceForRun);
            console.writeMessage(this.soutionDescription(solution).toString());
            long solutionVisualisationTime = System.nanoTime();
            if ((solution instanceof ModelResult)) {
              final List<? extends LogicModelInterpretation> interpretations = solver.getInterpretations(((ModelResult)solution));
              ReasonerWorkspace _xifexpression_11 = null;
              if ((runs_1 > 1)) {
                StringConcatenation _builder_7 = new StringConcatenation();
                _builder_7.append("run");
                _builder_7.append(run_1);
                ReasonerWorkspace _subWorkspace_1 = outputWorkspace.subWorkspace(_builder_7.toString(), "");
                final Procedure1<ReasonerWorkspace> _function_6 = (ReasonerWorkspace it) -> {
                  it.initAndClear();
                };
                _xifexpression_11 = ObjectExtensions.<ReasonerWorkspace>operator_doubleArrow(_subWorkspace_1, _function_6);
              } else {
                _xifexpression_11 = outputWorkspace;
              }
              final ReasonerWorkspace outputWorkspaceForRun = _xifexpression_11;
              final LinkedList<File> emfRepresentations = new LinkedList<File>();
              final LinkedList<File> gmlRepresentations = new LinkedList<File>();
              final LinkedList<File> dotRepresentations = new LinkedList<File>();
              int _size = interpretations.size();
              ExclusiveRange _doubleDotLessThan = new ExclusiveRange(0, _size, true);
              for (final Integer interpretationIndex : _doubleDotLessThan) {
                {
                  StringConcatenation _builder_8 = new StringConcatenation();
                  _builder_8.append("Solving problem");
                  {
                    if ((runs_1 > 0)) {
                      _builder_8.append(" ");
                      _builder_8.append(run_1);
                      _builder_8.append("/");
                      _builder_8.append(runs_1);
                    }
                  }
                  _builder_8.append(": Visualising solution ");
                  _builder_8.append(((interpretationIndex).intValue() + 1));
                  _builder_8.append("/");
                  int _size_1 = interpretations.size();
                  _builder_8.append(_size_1);
                  monitor.subTask(_builder_8.toString());
                  final LogicModelInterpretation interpretation = interpretations.get((interpretationIndex).intValue());
                  final EObject model = logic2Ecore.transformInterpretation(interpretation, modelGeneration.getTrace());
                  StringConcatenation _builder_9 = new StringConcatenation();
                  {
                    if ((runs_1 > 1)) {
                      _builder_9.append(run_1);
                      _builder_9.append("_");
                    }
                  }
                  _builder_9.append(((interpretationIndex).intValue() + 1));
                  _builder_9.append(".xmi");
                  final String emfFileName = _builder_9.toString();
                  outputWorkspaceForRun.writeModel(model, emfFileName);
                  File _file = outputWorkspaceForRun.getFile(emfFileName);
                  emfRepresentations.add(_file);
                  final Object representation = ((ModelResult)solution).getRepresentation().get((interpretationIndex).intValue());
                  boolean _atLeastNormal_1 = this.atLeastNormal(documentationLevel);
                  if (_atLeastNormal_1) {
                    if ((representation instanceof PartialInterpretation)) {
                      final PartialInterpretation2Gml vis1 = new PartialInterpretation2Gml();
                      final String gml = vis1.transform(((PartialInterpretation)representation));
                      StringConcatenation _builder_10 = new StringConcatenation();
                      {
                        if ((runs_1 > 1)) {
                          _builder_10.append(run_1);
                          _builder_10.append("_");
                        }
                      }
                      _builder_10.append(((interpretationIndex).intValue() + 1));
                      _builder_10.append(".gml");
                      final String glmFilename = _builder_10.toString();
                      outputWorkspaceForRun.writeText(glmFilename, gml);
                      File _file_1 = outputWorkspaceForRun.getFile(glmFilename);
                      gmlRepresentations.add(_file_1);
                      int _size_2 = ((PartialInterpretation)representation).getNewElements().size();
                      int _size_3 = ((PartialInterpretation)representation).getProblem().getElements().size();
                      int _plus = (_size_2 + _size_3);
                      boolean _lessThan = (_plus < 150);
                      if (_lessThan) {
                        final GraphvizVisualiser vis2 = new GraphvizVisualiser();
                        final PartialInterpretationVisualisation dot = vis2.visualiseConcretization(((PartialInterpretation)representation));
                        StringConcatenation _builder_11 = new StringConcatenation();
                        {
                          if ((runs_1 > 1)) {
                            _builder_11.append(run_1);
                            _builder_11.append("_");
                          }
                        }
                        _builder_11.append(((interpretationIndex).intValue() + 1));
                        _builder_11.append(".png");
                        final String dotFileName = _builder_11.toString();
                        dot.writeToFile(outputWorkspaceForRun, dotFileName);
                        File _file_2 = outputWorkspaceForRun.getFile(dotFileName);
                        dotRepresentations.add(_file_2);
                      } else {
                        dotRepresentations.add(null);
                      }
                    } else {
                      gmlRepresentations.add(null);
                      dotRepresentations.add(null);
                    }
                  }
                  int _size_4 = interpretations.size();
                  double _divide = (1.0 / _size_4);
                  visualisationProgressMonitor.worked(_divide);
                }
              }
              boolean _isEmpty_1 = emfRepresentations.isEmpty();
              boolean _not_1 = (!_isEmpty_1);
              if (_not_1) {
                StringConcatenation _builder_8 = new StringConcatenation();
                _builder_8.append("Models:         ");
                {
                  Iterable<File> _filterNull = IterableExtensions.<File>filterNull(emfRepresentations);
                  for(final File f : _filterNull) {
                    _builder_8.append("#");
                  }
                }
                final Function1<File, ScriptConsoleDecorator> _function_7 = (File it) -> {
                  StringConcatenation _builder_9 = new StringConcatenation();
                  String _fileRepresentationInConsole = this.fileRepresentationInConsole(it);
                  _builder_9.append(_fileRepresentationInConsole);
                  return new ScriptConsoleDecorator(_builder_9.toString(), it);
                };
                console.writeMessage(_builder_8, 
                  "#", 
                  ((ScriptConsoleDecorator[])Conversions.unwrapArray(IterableExtensions.<File, ScriptConsoleDecorator>map(IterableExtensions.<File>filterNull(emfRepresentations), _function_7), ScriptConsoleDecorator.class)));
              }
              boolean _isEmpty_2 = gmlRepresentations.isEmpty();
              boolean _not_2 = (!_isEmpty_2);
              if (_not_2) {
                StringConcatenation _builder_9 = new StringConcatenation();
                _builder_9.append("Visualisations: ");
                {
                  Iterable<File> _filterNull_1 = IterableExtensions.<File>filterNull(gmlRepresentations);
                  for(final File f_1 : _filterNull_1) {
                    _builder_9.append("#");
                  }
                }
                final Function1<File, ScriptConsoleDecorator> _function_8 = (File it) -> {
                  StringConcatenation _builder_10 = new StringConcatenation();
                  String _fileRepresentationInConsole = this.fileRepresentationInConsole(it);
                  _builder_10.append(_fileRepresentationInConsole);
                  return new ScriptConsoleDecorator(_builder_10.toString(), it);
                };
                console.writeMessage(_builder_9, 
                  "#", 
                  ((ScriptConsoleDecorator[])Conversions.unwrapArray(IterableExtensions.<File, ScriptConsoleDecorator>map(IterableExtensions.<File>filterNull(gmlRepresentations), _function_8), ScriptConsoleDecorator.class)));
              }
              boolean _isEmpty_3 = dotRepresentations.isEmpty();
              boolean _not_3 = (!_isEmpty_3);
              if (_not_3) {
                StringConcatenation _builder_10 = new StringConcatenation();
                _builder_10.append("Visualisations: ");
                {
                  Iterable<File> _filterNull_2 = IterableExtensions.<File>filterNull(dotRepresentations);
                  for(final File f_2 : _filterNull_2) {
                    _builder_10.append("#");
                  }
                }
                final Function1<File, ScriptConsoleDecorator> _function_9 = (File it) -> {
                  StringConcatenation _builder_11 = new StringConcatenation();
                  String _fileRepresentationInConsole = this.fileRepresentationInConsole(it);
                  _builder_11.append(_fileRepresentationInConsole);
                  return new ScriptConsoleDecorator(_builder_11.toString(), it);
                };
                console.writeMessage(_builder_10, 
                  "#", 
                  ((ScriptConsoleDecorator[])Conversions.unwrapArray(IterableExtensions.<File, ScriptConsoleDecorator>map(IterableExtensions.<File>filterNull(dotRepresentations), _function_9), ScriptConsoleDecorator.class)));
              }
            } else {
              visualisationProgressMonitor.worked(1.0);
            }
            long _nanoTime_1 = System.nanoTime();
            long _minus_1 = (_nanoTime_1 - solutionVisualisationTime);
            solutionVisualisationTime = _minus_1;
            final LinkedHashMap<String, Object> statistics = new LinkedHashMap<String, Object>();
            EObject _eContainer = task.eContainer();
            int _indexOf = ((ConfigurationScript) _eContainer).getCommands().indexOf(task);
            int _plus = (_indexOf + 1);
            statistics.put("Task", Integer.valueOf(_plus));
            statistics.put("Run", run_1);
            statistics.put("Result", solution.getClass().getSimpleName());
            statistics.put("Domain to logic transformation time", Long.valueOf((domain2LogicTransformationTime / 1000000)));
            statistics.put("Logic to solver transformation time", Integer.valueOf(solution.getStatistics().getTransformationTime()));
            statistics.put("Solver time", Integer.valueOf(solution.getStatistics().getSolverTime()));
            statistics.put("Postprocessing time", Long.valueOf((solutionVisualisationTime / 1000000)));
            EList<StatisticEntry> _entries_1 = solution.getStatistics().getEntries();
            for (final StatisticEntry entry : _entries_1) {
              statistics.put(entry.getName(), this.statisticsUtil.readValue(entry));
            }
            console.addStatistics(statistics);
          }
        }
      }
      console.flushStatistics();
      console.writeMessage("Model generation finished");
    } catch (final Throwable _t) {
      if (_t instanceof Exception) {
        final Exception e = (Exception)_t;
        StringConcatenation _builder_5 = new StringConcatenation();
        _builder_5.append("Error occured (");
        String _simpleName = e.getClass().getSimpleName();
        _builder_5.append(_simpleName);
        _builder_5.append("): ");
        String _message = e.getMessage();
        _builder_5.append(_message);
        _builder_5.newLineIfNotEmpty();
        {
          StackTraceElement[] _stackTrace = e.getStackTrace();
          boolean _hasElements = false;
          for(final StackTraceElement s : _stackTrace) {
            if (!_hasElements) {
              _hasElements = true;
            } else {
              _builder_5.appendImmediate("\n", "");
            }
            _builder_5.append("    ");
            _builder_5.append(s);
          }
        }
        console.writeError(_builder_5.toString());
      } else {
        throw Exceptions.sneakyThrow(_t);
      }
    }
  }
  
  private String fileRepresentationInConsole(final File file) {
    return file.getName();
  }
  
  private CharSequence _soutionDescription(final InconsistencyResult s) {
    CharSequence _xifexpression = null;
    int _size = s.getRepresentation().size();
    boolean _equals = (_size == 0);
    if (_equals) {
      StringConcatenation _builder = new StringConcatenation();
      _builder.append("Problem is inconsistent, no model is created!");
      _xifexpression = _builder;
    } else {
      StringConcatenation _builder_1 = new StringConcatenation();
      _builder_1.append("Problem is inconsistent, only ");
      int _size_1 = s.getRepresentation().size();
      _builder_1.append(_size_1);
      _builder_1.append(" model");
      {
        int _size_2 = s.getRepresentation().size();
        boolean _greaterThan = (_size_2 > 1);
        if (_greaterThan) {
          _builder_1.append("s");
        }
      }
      _builder_1.append(" can be created!");
      _xifexpression = _builder_1;
    }
    return _xifexpression;
  }
  
  private CharSequence _soutionDescription(final ModelResult s) {
    CharSequence _xifexpression = null;
    int _size = s.getRepresentation().size();
    boolean _equals = (_size == 1);
    if (_equals) {
      StringConcatenation _builder = new StringConcatenation();
      _builder.append("Problem is consistent, a model is generated");
      _xifexpression = _builder;
    } else {
      StringConcatenation _builder_1 = new StringConcatenation();
      _builder_1.append("Problem is consistent, ");
      int _size_1 = s.getRepresentation().size();
      _builder_1.append(_size_1);
      _builder_1.append(" models are generated!");
      _xifexpression = _builder_1;
    }
    return _xifexpression;
  }
  
  private CharSequence _soutionDescription(final UnknownResult s) {
    CharSequence _xifexpression = null;
    int _size = s.getRepresentation().size();
    boolean _equals = (_size == 1);
    if (_equals) {
      StringConcatenation _builder = new StringConcatenation();
      _builder.append("Unable to solve problem!");
      _xifexpression = _builder;
    } else {
      StringConcatenation _builder_1 = new StringConcatenation();
      _builder_1.append("Unable to solve problem, but ");
      int _size_1 = s.getRepresentation().size();
      _builder_1.append(_size_1);
      _builder_1.append(" model generated!");
      _xifexpression = _builder_1;
    }
    return _xifexpression;
  }
  
  private boolean atLeastNormal(final Optional<DocumentationLevel> level) {
    boolean _isPresent = level.isPresent();
    if (_isPresent) {
      DocumentationLevel _get = level.get();
      return (_get != DocumentationLevel.NONE);
    } else {
      return false;
    }
  }
  
  private CharSequence soutionDescription(final LogicResult s) {
    if (s instanceof InconsistencyResult) {
      return _soutionDescription((InconsistencyResult)s);
    } else if (s instanceof ModelResult) {
      return _soutionDescription((ModelResult)s);
    } else if (s instanceof UnknownResult) {
      return _soutionDescription((UnknownResult)s);
    } else {
      throw new IllegalArgumentException("Unhandled parameter types: " +
        Arrays.<Object>asList(s).toString());
    }
  }
}
