package hu.bme.mit.inf.dslreasoner.application.execution;

import hu.bme.mit.inf.dslreasoner.logic.model.builder.SolverProgressMonitor;
import org.eclipse.core.runtime.IProgressMonitor;

@SuppressWarnings("all")
public class EclipseBasedProgressMonitor extends SolverProgressMonitor {
  private final IProgressMonitor internalMonitor;
  
  public EclipseBasedProgressMonitor(final IProgressMonitor internalMonitor) {
    this.internalMonitor = internalMonitor;
  }
  
  private double currentDouble = 0.0;
  
  private int currentInt = 0;
  
  @Override
  protected void processWorked(final double amount) {
    final double newDouble = (this.currentDouble + amount);
    final int newInt = Double.valueOf((newDouble * 1000)).intValue();
    this.internalMonitor.worked((newInt - this.currentInt));
    this.currentDouble = newDouble;
    this.currentInt = newInt;
  }
  
  @Override
  public boolean isCancelled() {
    return (super.isCancelled() || this.internalMonitor.isCanceled());
  }
}
