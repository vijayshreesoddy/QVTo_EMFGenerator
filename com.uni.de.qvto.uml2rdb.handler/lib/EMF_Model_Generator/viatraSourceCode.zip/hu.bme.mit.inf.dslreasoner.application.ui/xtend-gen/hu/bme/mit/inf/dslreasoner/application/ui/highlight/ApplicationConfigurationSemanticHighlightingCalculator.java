package hu.bme.mit.inf.dslreasoner.application.ui.highlight;

import com.google.common.base.Objects;
import com.google.common.collect.Iterators;
import hu.bme.mit.inf.dslreasoner.application.applicationConfiguration.MetamodelElement;
import hu.bme.mit.inf.dslreasoner.application.ui.highlight.ColorCalculator;
import java.util.Iterator;
import java.util.List;
import java.util.WeakHashMap;
import org.eclipse.emf.ecore.EClassifier;
import org.eclipse.xtend2.lib.StringConcatenation;
import org.eclipse.xtext.ide.editor.syntaxcoloring.DefaultSemanticHighlightingCalculator;
import org.eclipse.xtext.ide.editor.syntaxcoloring.IHighlightedPositionAcceptor;
import org.eclipse.xtext.nodemodel.ICompositeNode;
import org.eclipse.xtext.nodemodel.util.NodeModelUtils;
import org.eclipse.xtext.resource.XtextResource;
import org.eclipse.xtext.util.CancelIndicator;

@SuppressWarnings("all")
public class ApplicationConfigurationSemanticHighlightingCalculator extends DefaultSemanticHighlightingCalculator {
  public static final String MetamodelElementIDPrefix = "MetamodelElementColor";
  
  private final WeakHashMap<EClassifier, String> metamodelElement2ID = new WeakHashMap<EClassifier, String>();
  
  private final ColorCalculator colorCalculator = new ColorCalculator();
  
  @Override
  public void provideHighlightingFor(final XtextResource resource, final IHighlightedPositionAcceptor acceptor, final CancelIndicator cancelIndicator) {
    if ((Objects.equal(resource, null) || Objects.equal(resource.getParseResult(), null))) {
      return;
    } else {
      final Iterator<MetamodelElement> metamodelElements = Iterators.<MetamodelElement>filter(resource.getAllContents(), MetamodelElement.class);
      while (metamodelElements.hasNext()) {
        {
          final MetamodelElement mentamodelElement = metamodelElements.next();
          final ICompositeNode node = NodeModelUtils.getNode(mentamodelElement);
          acceptor.addPosition(
            node.getOffset(), 
            node.getLength(), 
            this.getMetamodelElementColorID(mentamodelElement));
        }
      }
    }
  }
  
  public String getMetamodelElementColorID(final MetamodelElement element) {
    final EClassifier classifier = element.getClassifier();
    if ((classifier == null)) {
      return "default";
    } else {
      boolean _eIsProxy = classifier.eIsProxy();
      if (_eIsProxy) {
        return "default";
      } else {
        boolean _containsKey = this.metamodelElement2ID.containsKey(classifier);
        if (_containsKey) {
          return this.metamodelElement2ID.get(classifier);
        } else {
          final String id = this.calculateMetamodelElementID(classifier);
          this.metamodelElement2ID.put(classifier, id);
          return id;
        }
      }
    }
  }
  
  private String calculateMetamodelElementID(final EClassifier c) {
    String _xblockexpression = null;
    {
      final List<Integer> randomColor = this.colorCalculator.getColor(c);
      StringConcatenation _builder = new StringConcatenation();
      _builder.append(ApplicationConfigurationSemanticHighlightingCalculator.MetamodelElementIDPrefix);
      _builder.append(" ");
      Integer _get = randomColor.get(0);
      _builder.append(_get);
      _builder.append(" ");
      Integer _get_1 = randomColor.get(1);
      _builder.append(_get_1);
      _builder.append(" ");
      Integer _get_2 = randomColor.get(2);
      _builder.append(_get_2);
      _xblockexpression = _builder.toString();
    }
    return _xblockexpression;
  }
}
