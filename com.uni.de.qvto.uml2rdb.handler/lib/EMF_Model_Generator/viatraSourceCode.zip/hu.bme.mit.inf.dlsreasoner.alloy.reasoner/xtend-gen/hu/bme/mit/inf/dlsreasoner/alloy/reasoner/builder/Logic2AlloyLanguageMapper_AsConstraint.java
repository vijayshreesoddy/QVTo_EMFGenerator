package hu.bme.mit.inf.dlsreasoner.alloy.reasoner.builder;

import hu.bme.mit.inf.dlsreasoner.alloy.reasoner.builder.Logic2AlloyLanguageMapper;
import hu.bme.mit.inf.dlsreasoner.alloy.reasoner.builder.Logic2AlloyLanguageMapperTrace;
import hu.bme.mit.inf.dlsreasoner.alloy.reasoner.builder.Logic2AlloyLanguageMapper_Support;
import hu.bme.mit.inf.dlsreasoner.alloy.reasoner.builder.Logic2AlloyLanguageMapper_TypeMapper;
import hu.bme.mit.inf.dlsreasoner.alloy.reasoner.builder.Logic2AlloyLanguageMapper_TypeScopeMapping;
import hu.bme.mit.inf.dslreasoner.alloyLanguage.ALSCardinality;
import hu.bme.mit.inf.dslreasoner.alloyLanguage.ALSDocument;
import hu.bme.mit.inf.dslreasoner.alloyLanguage.ALSFactDeclaration;
import hu.bme.mit.inf.dslreasoner.alloyLanguage.ALSLeq;
import hu.bme.mit.inf.dslreasoner.alloyLanguage.ALSMeq;
import hu.bme.mit.inf.dslreasoner.alloyLanguage.ALSNumberLiteral;
import hu.bme.mit.inf.dslreasoner.alloyLanguage.ALSReference;
import hu.bme.mit.inf.dslreasoner.alloyLanguage.ALSSignatureDeclaration;
import hu.bme.mit.inf.dslreasoner.alloyLanguage.AlloyLanguageFactory;
import hu.bme.mit.inf.dslreasoner.logic.model.logiclanguage.Type;
import java.util.Collections;
import org.eclipse.emf.common.util.EList;
import org.eclipse.xtext.xbase.lib.CollectionLiterals;
import org.eclipse.xtext.xbase.lib.Extension;
import org.eclipse.xtext.xbase.lib.Functions.Function1;
import org.eclipse.xtext.xbase.lib.IterableExtensions;
import org.eclipse.xtext.xbase.lib.ListExtensions;
import org.eclipse.xtext.xbase.lib.ObjectExtensions;
import org.eclipse.xtext.xbase.lib.Procedures.Procedure1;

@SuppressWarnings("all")
public class Logic2AlloyLanguageMapper_AsConstraint implements Logic2AlloyLanguageMapper_TypeScopeMapping {
  @Extension
  private final AlloyLanguageFactory factory = AlloyLanguageFactory.eINSTANCE;
  
  private final Logic2AlloyLanguageMapper_Support support = new Logic2AlloyLanguageMapper_Support();
  
  private final Logic2AlloyLanguageMapper_TypeMapper typeMapper;
  
  public Logic2AlloyLanguageMapper_AsConstraint(final Logic2AlloyLanguageMapper_TypeMapper mapper) {
    this.typeMapper = mapper;
  }
  
  @Override
  public void addLowerMultiplicity(final ALSDocument document, final Type type, final int lowerMultiplicty, final Logic2AlloyLanguageMapper mapper, final Logic2AlloyLanguageMapperTrace trace) {
    EList<ALSFactDeclaration> _factDeclarations = document.getFactDeclarations();
    ALSFactDeclaration _createALSFactDeclaration = this.factory.createALSFactDeclaration();
    final Procedure1<ALSFactDeclaration> _function = (ALSFactDeclaration it) -> {
      String _iD = this.support.toID(type.getName());
      String _string = Integer.valueOf(lowerMultiplicty).toString();
      it.setName(this.support.toID(Collections.<String>unmodifiableList(CollectionLiterals.<String>newArrayList("LowerMultiplicity", _iD, _string))));
      ALSLeq _createALSLeq = this.factory.createALSLeq();
      final Procedure1<ALSLeq> _function_1 = (ALSLeq it_1) -> {
        ALSCardinality _createALSCardinality = this.factory.createALSCardinality();
        final Procedure1<ALSCardinality> _function_2 = (ALSCardinality it_2) -> {
          final Function1<ALSSignatureDeclaration, ALSReference> _function_3 = (ALSSignatureDeclaration t) -> {
            ALSReference _createALSReference = this.factory.createALSReference();
            final Procedure1<ALSReference> _function_4 = (ALSReference it_3) -> {
              it_3.setReferred(t);
            };
            return ObjectExtensions.<ALSReference>operator_doubleArrow(_createALSReference, _function_4);
          };
          it_2.setOperand(this.support.unfoldPlus(IterableExtensions.<ALSReference>toList(ListExtensions.<ALSSignatureDeclaration, ALSReference>map(this.typeMapper.transformTypeReference(type, mapper, trace), _function_3))));
        };
        ALSCardinality _doubleArrow = ObjectExtensions.<ALSCardinality>operator_doubleArrow(_createALSCardinality, _function_2);
        it_1.setLeftOperand(_doubleArrow);
        ALSNumberLiteral _createALSNumberLiteral = this.factory.createALSNumberLiteral();
        final Procedure1<ALSNumberLiteral> _function_3 = (ALSNumberLiteral it_2) -> {
          it_2.setValue(lowerMultiplicty);
        };
        ALSNumberLiteral _doubleArrow_1 = ObjectExtensions.<ALSNumberLiteral>operator_doubleArrow(_createALSNumberLiteral, _function_3);
        it_1.setRightOperand(_doubleArrow_1);
      };
      ALSLeq _doubleArrow = ObjectExtensions.<ALSLeq>operator_doubleArrow(_createALSLeq, _function_1);
      it.setTerm(_doubleArrow);
    };
    ALSFactDeclaration _doubleArrow = ObjectExtensions.<ALSFactDeclaration>operator_doubleArrow(_createALSFactDeclaration, _function);
    _factDeclarations.add(_doubleArrow);
  }
  
  @Override
  public void addUpperMultiplicity(final ALSDocument document, final Type type, final int upperMultiplicty, final Logic2AlloyLanguageMapper mapper, final Logic2AlloyLanguageMapperTrace trace) {
    EList<ALSFactDeclaration> _factDeclarations = document.getFactDeclarations();
    ALSFactDeclaration _createALSFactDeclaration = this.factory.createALSFactDeclaration();
    final Procedure1<ALSFactDeclaration> _function = (ALSFactDeclaration it) -> {
      String _iD = this.support.toID(type.getName());
      String _string = Integer.valueOf(upperMultiplicty).toString();
      it.setName(this.support.toID(Collections.<String>unmodifiableList(CollectionLiterals.<String>newArrayList("UpperMultiplicity", _iD, _string))));
      ALSMeq _createALSMeq = this.factory.createALSMeq();
      final Procedure1<ALSMeq> _function_1 = (ALSMeq it_1) -> {
        ALSCardinality _createALSCardinality = this.factory.createALSCardinality();
        final Procedure1<ALSCardinality> _function_2 = (ALSCardinality it_2) -> {
          final Function1<ALSSignatureDeclaration, ALSReference> _function_3 = (ALSSignatureDeclaration t) -> {
            ALSReference _createALSReference = this.factory.createALSReference();
            final Procedure1<ALSReference> _function_4 = (ALSReference it_3) -> {
              it_3.setReferred(t);
            };
            return ObjectExtensions.<ALSReference>operator_doubleArrow(_createALSReference, _function_4);
          };
          it_2.setOperand(this.support.unfoldPlus(IterableExtensions.<ALSReference>toList(ListExtensions.<ALSSignatureDeclaration, ALSReference>map(this.typeMapper.transformTypeReference(type, mapper, trace), _function_3))));
        };
        ALSCardinality _doubleArrow = ObjectExtensions.<ALSCardinality>operator_doubleArrow(_createALSCardinality, _function_2);
        it_1.setLeftOperand(_doubleArrow);
        ALSNumberLiteral _createALSNumberLiteral = this.factory.createALSNumberLiteral();
        final Procedure1<ALSNumberLiteral> _function_3 = (ALSNumberLiteral it_2) -> {
          it_2.setValue(upperMultiplicty);
        };
        ALSNumberLiteral _doubleArrow_1 = ObjectExtensions.<ALSNumberLiteral>operator_doubleArrow(_createALSNumberLiteral, _function_3);
        it_1.setRightOperand(_doubleArrow_1);
      };
      ALSMeq _doubleArrow = ObjectExtensions.<ALSMeq>operator_doubleArrow(_createALSMeq, _function_1);
      it.setTerm(_doubleArrow);
    };
    ALSFactDeclaration _doubleArrow = ObjectExtensions.<ALSFactDeclaration>operator_doubleArrow(_createALSFactDeclaration, _function);
    _factDeclarations.add(_doubleArrow);
  }
}
