package hu.bme.mit.inf.dslreasoner.application.linking;

import com.google.common.base.Objects;
import com.google.inject.Inject;
import hu.bme.mit.inf.dslreasoner.application.applicationConfiguration.ApplicationConfigurationPackage;
import hu.bme.mit.inf.dslreasoner.application.applicationConfiguration.EPackageImport;
import hu.bme.mit.inf.dslreasoner.application.applicationConfiguration.ViatraImport;
import java.util.Collections;
import java.util.List;
import java.util.Optional;
import org.eclipse.emf.common.util.URI;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.EPackage;
import org.eclipse.emf.ecore.EReference;
import org.eclipse.emf.ecore.resource.Resource;
import org.eclipse.emf.ecore.resource.ResourceSet;
import org.eclipse.viatra.query.patternlanguage.emf.scoping.IMetamodelProvider;
import org.eclipse.xtext.conversion.IValueConverterService;
import org.eclipse.xtext.conversion.ValueConverterException;
import org.eclipse.xtext.linking.impl.DefaultLinkingService;
import org.eclipse.xtext.nodemodel.ILeafNode;
import org.eclipse.xtext.nodemodel.INode;
import org.eclipse.xtext.xbase.lib.CollectionLiterals;
import org.eclipse.xtext.xbase.lib.Exceptions;
import org.eclipse.xtext.xbase.lib.Extension;
import org.eclipse.xtext.xbase.lib.Functions.Function1;
import org.eclipse.xtext.xbase.lib.IterableExtensions;

@SuppressWarnings("all")
public class ApplicationConfigurationLinkingService extends DefaultLinkingService {
  @Inject
  private IValueConverterService valueConverterService;
  
  @Inject
  private IMetamodelProvider metamodelProvider;
  
  @Extension
  public static ApplicationConfigurationPackage pac = ApplicationConfigurationPackage.eINSTANCE;
  
  @Override
  public List<EObject> getLinkedObjects(final EObject context, final EReference ref, final INode node) {
    if ((context instanceof EPackageImport)) {
      if ((Objects.equal(ref, ApplicationConfigurationLinkingService.pac.getEPackageImport_ImportedPackage()) && (node instanceof ILeafNode))) {
        return this.getEPackage(((EPackageImport)context), ((ILeafNode) node));
      }
    } else {
      if ((context instanceof ViatraImport)) {
        EReference _viatraImport_ImportedViatra = ApplicationConfigurationLinkingService.pac.getViatraImport_ImportedViatra();
        boolean _equals = Objects.equal(ref, _viatraImport_ImportedViatra);
        if (_equals) {
          return this.getViatra(((ViatraImport)context), node);
        }
      }
    }
    return super.getLinkedObjects(context, ref, node);
  }
  
  private List<EObject> getEPackage(final EPackageImport packageImport, final ILeafNode node) {
    List<EObject> _xblockexpression = null;
    {
      final Optional<String> x = this.getNSUri(node);
      List<EObject> _xifexpression = null;
      boolean _isPresent = x.isPresent();
      if (_isPresent) {
        List<EObject> _xblockexpression_1 = null;
        {
          final String uriString = x.get();
          final EPackage epackageByMetamodelProvider = this.metamodelProvider.loadEPackage(uriString, 
            packageImport.eResource().getResourceSet());
          final EPackage epackageByMe = this.ePackageByMe(packageImport.eResource().getResourceSet(), uriString);
          List<EObject> _xifexpression_1 = null;
          if ((epackageByMetamodelProvider != null)) {
            return Collections.<EObject>singletonList(((EObject) epackageByMetamodelProvider));
          } else {
            List<EObject> _xifexpression_2 = null;
            if ((epackageByMe != null)) {
              return Collections.<EObject>singletonList(((EObject) epackageByMe));
            } else {
              _xifexpression_2 = CollectionLiterals.<EObject>emptyList();
            }
            _xifexpression_1 = _xifexpression_2;
          }
          _xblockexpression_1 = _xifexpression_1;
        }
        _xifexpression = _xblockexpression_1;
      } else {
        return CollectionLiterals.<EObject>emptyList();
      }
      _xblockexpression = _xifexpression;
    }
    return _xblockexpression;
  }
  
  private EPackage ePackageByMe(final ResourceSet rs, final String uri) {
    try {
      final Resource resource = rs.getResource(URI.createURI(uri), true);
      EObject _head = IterableExtensions.<EObject>head(resource.getContents());
      return ((EPackage) _head);
    } catch (final Throwable _t) {
      if (_t instanceof Exception) {
        return null;
      } else {
        throw Exceptions.sneakyThrow(_t);
      }
    }
  }
  
  private List<EObject> getViatra(final ViatraImport viatraImport, final INode node) {
    return this.getByUri(viatraImport, ApplicationConfigurationLinkingService.pac.getViatraImport_ImportedViatra(), node);
  }
  
  private List<EObject> getByUri(final EObject context, final EReference ref, final INode node) {
    final Optional<String> uri = this.getNSUri(node);
    boolean _isPresent = uri.isPresent();
    if (_isPresent) {
      URI createdURI = null;
      try {
        createdURI = URI.createURI(uri.get());
      } catch (final Throwable _t) {
        if (_t instanceof IllegalArgumentException) {
          return super.getLinkedObjects(context, ref, node);
        } else {
          throw Exceptions.sneakyThrow(_t);
        }
      }
      Resource res = null;
      try {
        res = context.eResource().getResourceSet().getResource(createdURI, true);
      } catch (final Throwable _t) {
        if (_t instanceof RuntimeException) {
          return super.getLinkedObjects(context, ref, node);
        } else {
          throw Exceptions.sneakyThrow(_t);
        }
      }
      if (((res != null) && (res.getContents() != null))) {
        final Function1<EObject, Boolean> _function = (EObject it) -> {
          return Boolean.valueOf(ref.getEType().isInstance(it));
        };
        return IterableExtensions.<EObject>toList(IterableExtensions.<EObject>filter(res.getContents(), _function));
      } else {
        return super.getLinkedObjects(context, ref, node);
      }
    } else {
      return super.getLinkedObjects(context, ref, node);
    }
  }
  
  private Optional<String> getNSUri(final INode node) {
    Optional<String> _xtrycatchfinallyexpression = null;
    try {
      Optional<String> _xblockexpression = null;
      {
        final Object convertedValue = this.valueConverterService.toValue(node.getText(), 
          this.getLinkingHelper().getRuleNameFrom(node.getGrammarElement()), node);
        _xblockexpression = Optional.<String>of(((String) convertedValue));
      }
      _xtrycatchfinallyexpression = _xblockexpression;
    } catch (final Throwable _t) {
      if (_t instanceof ValueConverterException) {
        _xtrycatchfinallyexpression = Optional.<String>empty();
      } else {
        throw Exceptions.sneakyThrow(_t);
      }
    }
    return _xtrycatchfinallyexpression;
  }
}
