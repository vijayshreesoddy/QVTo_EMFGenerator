package hu.bme.mit.inf.dslreasoner.application.valueconverter;

import com.google.common.base.Objects;
import com.google.inject.Inject;
import java.util.List;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.xtext.RuleCall;
import org.eclipse.xtext.conversion.IValueConverterService;
import org.eclipse.xtext.conversion.ValueConverterException;
import org.eclipse.xtext.conversion.impl.AbstractValueConverter;
import org.eclipse.xtext.nodemodel.ILeafNode;
import org.eclipse.xtext.nodemodel.INode;
import org.eclipse.xtext.xbase.lib.Conversions;
import org.eclipse.xtext.xbase.lib.Functions.Function1;
import org.eclipse.xtext.xbase.lib.IterableExtensions;
import org.eclipse.xtext.xbase.lib.ListExtensions;

@SuppressWarnings("all")
public class QualifiedNameValueConverter extends AbstractValueConverter<String> {
  @Inject
  protected IValueConverterService valueConverterService;
  
  @Override
  public String toString(final String value) throws ValueConverterException {
    return value;
  }
  
  @Override
  public String toValue(final String string, final INode node) throws ValueConverterException {
    boolean _notEquals = (!Objects.equal(node, null));
    if (_notEquals) {
      final Function1<ILeafNode, Boolean> _function = (ILeafNode it) -> {
        return Boolean.valueOf(this.isDelegateRuleCall(it.getGrammarElement()));
      };
      final Function1<ILeafNode, String> _function_1 = (ILeafNode it) -> {
        return it.getText();
      };
      final Iterable<String> segments = IterableExtensions.<ILeafNode, String>map(IterableExtensions.<ILeafNode>filter(node.getLeafNodes(), _function), _function_1);
      final String res = IterableExtensions.join(segments, ".");
      return res;
    } else {
      final String[] segments_1 = string.split("\\.");
      final Function1<String, Object> _function_2 = (String it) -> {
        return this.valueConverterService.toValue(it, "ID", null);
      };
      final List<Object> translatedSegments = ListExtensions.<String, Object>map(((List<String>)Conversions.doWrapArray(segments_1)), _function_2);
      final String res_1 = IterableExtensions.join(translatedSegments, ".");
      return res_1;
    }
  }
  
  protected boolean isDelegateRuleCall(final EObject grammarElement) {
    boolean _xifexpression = false;
    if ((grammarElement instanceof RuleCall)) {
      String _name = ((RuleCall)grammarElement).getRule().getName();
      _xifexpression = Objects.equal(_name, "ID");
    } else {
      return false;
    }
    return _xifexpression;
  }
}
