package hu.bme.mit.inf.dlsreasoner.alloy.reasoner.builder;

import com.google.common.collect.Iterables;
import com.google.common.collect.Iterators;
import hu.bme.mit.inf.dlsreasoner.alloy.reasoner.AlloySolverConfiguration;
import hu.bme.mit.inf.dlsreasoner.alloy.reasoner.builder.Logic2AlloyLanguageMapper;
import hu.bme.mit.inf.dlsreasoner.alloy.reasoner.builder.Logic2AlloyLanguageMapperTrace;
import hu.bme.mit.inf.dlsreasoner.alloy.reasoner.builder.Logic2AlloyLanguageMapper_AsConstraint;
import hu.bme.mit.inf.dlsreasoner.alloy.reasoner.builder.Logic2AlloyLanguageMapper_Support;
import hu.bme.mit.inf.dlsreasoner.alloy.reasoner.builder.Logic2AlloyLanguageMapper_TypeMapper;
import hu.bme.mit.inf.dlsreasoner.alloy.reasoner.builder.Logic2AlloyLanguageMapper_TypeScopeMapping;
import hu.bme.mit.inf.dslreasoner.alloyLanguage.ALSDocument;
import hu.bme.mit.inf.dslreasoner.alloyLanguage.ALSEquals;
import hu.bme.mit.inf.dslreasoner.alloyLanguage.ALSFactDeclaration;
import hu.bme.mit.inf.dslreasoner.alloyLanguage.ALSInt;
import hu.bme.mit.inf.dslreasoner.alloyLanguage.ALSIntScope;
import hu.bme.mit.inf.dslreasoner.alloyLanguage.ALSNumberLiteral;
import hu.bme.mit.inf.dslreasoner.alloyLanguage.ALSRunCommand;
import hu.bme.mit.inf.dslreasoner.alloyLanguage.ALSSigScope;
import hu.bme.mit.inf.dslreasoner.alloyLanguage.ALSString;
import hu.bme.mit.inf.dslreasoner.alloyLanguage.ALSStringLiteral;
import hu.bme.mit.inf.dslreasoner.alloyLanguage.ALSStringScope;
import hu.bme.mit.inf.dslreasoner.alloyLanguage.ALSTerm;
import hu.bme.mit.inf.dslreasoner.alloyLanguage.ALSTypeScope;
import hu.bme.mit.inf.dslreasoner.alloyLanguage.AlloyLanguageFactory;
import hu.bme.mit.inf.dslreasoner.logic.model.builder.LogicSolverConfiguration;
import hu.bme.mit.inf.dslreasoner.logic.model.logiclanguage.DefinedElement;
import hu.bme.mit.inf.dslreasoner.logic.model.logiclanguage.Type;
import hu.bme.mit.inf.dslreasoner.logic.model.logiclanguage.TypeDefinition;
import hu.bme.mit.inf.dslreasoner.util.CollectionsUtil;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.SortedSet;
import org.eclipse.emf.common.util.EList;
import org.eclipse.xtend2.lib.StringConcatenation;
import org.eclipse.xtext.xbase.lib.CollectionLiterals;
import org.eclipse.xtext.xbase.lib.Extension;
import org.eclipse.xtext.xbase.lib.Functions.Function1;
import org.eclipse.xtext.xbase.lib.IterableExtensions;
import org.eclipse.xtext.xbase.lib.IteratorExtensions;
import org.eclipse.xtext.xbase.lib.ObjectExtensions;
import org.eclipse.xtext.xbase.lib.Procedures.Procedure1;

@SuppressWarnings("all")
public class RunCommandMapper {
  @Extension
  private final AlloyLanguageFactory factory = AlloyLanguageFactory.eINSTANCE;
  
  private final Logic2AlloyLanguageMapper_Support support = new Logic2AlloyLanguageMapper_Support();
  
  private final Logic2AlloyLanguageMapper_TypeMapper typeMapper;
  
  private final Logic2AlloyLanguageMapper_TypeScopeMapping typeScopeMapping;
  
  public RunCommandMapper(final Logic2AlloyLanguageMapper_TypeMapper typeMapper) {
    this.typeMapper = typeMapper;
    Logic2AlloyLanguageMapper_AsConstraint _logic2AlloyLanguageMapper_AsConstraint = new Logic2AlloyLanguageMapper_AsConstraint(typeMapper);
    this.typeScopeMapping = _logic2AlloyLanguageMapper_AsConstraint;
  }
  
  public Boolean transformRunCommand(final Logic2AlloyLanguageMapper mapper, final ALSDocument specification, final Logic2AlloyLanguageMapperTrace trace, final AlloySolverConfiguration config) {
    Boolean _xblockexpression = null;
    {
      boolean _isEmpty = config.typeScopes.knownStrings.isEmpty();
      boolean _not = (!_isEmpty);
      if (_not) {
        EList<ALSFactDeclaration> _factDeclarations = specification.getFactDeclarations();
        ALSFactDeclaration _createALSFactDeclaration = this.factory.createALSFactDeclaration();
        final Procedure1<ALSFactDeclaration> _function = (ALSFactDeclaration it) -> {
          it.setName("EnsureAllStrings");
          final Function1<String, ALSEquals> _function_1 = (String x) -> {
            ALSEquals _createALSEquals = this.factory.createALSEquals();
            final Procedure1<ALSEquals> _function_2 = (ALSEquals it_1) -> {
              ALSStringLiteral _createALSStringLiteral = this.factory.createALSStringLiteral();
              final Procedure1<ALSStringLiteral> _function_3 = (ALSStringLiteral it_2) -> {
                it_2.setValue(x);
              };
              ALSStringLiteral _doubleArrow = ObjectExtensions.<ALSStringLiteral>operator_doubleArrow(_createALSStringLiteral, _function_3);
              it_1.setLeftOperand(_doubleArrow);
              ALSStringLiteral _createALSStringLiteral_1 = this.factory.createALSStringLiteral();
              final Procedure1<ALSStringLiteral> _function_4 = (ALSStringLiteral it_2) -> {
                it_2.setValue(x);
              };
              ALSStringLiteral _doubleArrow_1 = ObjectExtensions.<ALSStringLiteral>operator_doubleArrow(_createALSStringLiteral_1, _function_4);
              it_1.setRightOperand(_doubleArrow_1);
            };
            return ObjectExtensions.<ALSEquals>operator_doubleArrow(_createALSEquals, _function_2);
          };
          final List<? extends ALSTerm> equals = IterableExtensions.<ALSEquals>toList(IterableExtensions.<String, ALSEquals>map(config.typeScopes.knownStrings, _function_1));
          it.setTerm(this.support.unfoldAnd(equals));
        };
        ALSFactDeclaration _doubleArrow = ObjectExtensions.<ALSFactDeclaration>operator_doubleArrow(_createALSFactDeclaration, _function);
        _factDeclarations.add(_doubleArrow);
      }
      ALSRunCommand _createALSRunCommand = this.factory.createALSRunCommand();
      final Procedure1<ALSRunCommand> _function_1 = (ALSRunCommand it) -> {
        EList<ALSTypeScope> _typeScopes = it.getTypeScopes();
        ALSSigScope _createALSSigScope = this.factory.createALSSigScope();
        final Procedure1<ALSSigScope> _function_2 = (ALSSigScope it_1) -> {
          it_1.setType(this.typeMapper.getUndefinedSupertype(trace));
          it_1.setNumber(this.typeMapper.getUndefinedSupertypeScope(config.typeScopes.maxNewElements, trace));
          it_1.setExactly((config.typeScopes.maxNewElements == config.typeScopes.minNewElements));
        };
        ALSSigScope _doubleArrow_1 = ObjectExtensions.<ALSSigScope>operator_doubleArrow(_createALSSigScope, _function_2);
        _typeScopes.add(_doubleArrow_1);
      };
      ALSRunCommand _doubleArrow_1 = ObjectExtensions.<ALSRunCommand>operator_doubleArrow(_createALSRunCommand, _function_1);
      specification.setRunCommand(_doubleArrow_1);
      Set<Map.Entry<Type, Integer>> _entrySet = config.typeScopes.maxNewElementsByType.entrySet();
      for (final Map.Entry<Type, Integer> upperLimit : _entrySet) {
        {
          final Type type = upperLimit.getKey();
          Integer _value = upperLimit.getValue();
          int _existingCount = this.getExistingCount(type);
          final int limit = ((_value).intValue() + _existingCount);
          if ((limit != LogicSolverConfiguration.Unlimited)) {
            this.typeScopeMapping.addUpperMultiplicity(specification, type, limit, mapper, trace);
          }
        }
      }
      Set<Map.Entry<Type, Integer>> _entrySet_1 = config.typeScopes.minNewElementsByType.entrySet();
      for (final Map.Entry<Type, Integer> lowerLimit : _entrySet_1) {
        {
          final Type type = lowerLimit.getKey();
          Integer _value = lowerLimit.getValue();
          int _existingCount = this.getExistingCount(type);
          final int limit = ((_value).intValue() + _existingCount);
          if ((limit != 0)) {
            this.typeScopeMapping.addLowerMultiplicity(specification, type, limit, mapper, trace);
          }
        }
      }
      this.setIntegerScope(specification, config, specification.getRunCommand());
      _xblockexpression = this.setStringScope(specification, config, specification.getRunCommand());
    }
    return _xblockexpression;
  }
  
  private int getExistingCount(final Type type) {
    int _xblockexpression = (int) 0;
    {
      final Function1<Type, Iterable<Type>> _function = (Type it) -> {
        return it.getSubtypes();
      };
      final Function1<TypeDefinition, EList<DefinedElement>> _function_1 = (TypeDefinition it) -> {
        return it.getElements();
      };
      final Set<DefinedElement> existing = IterableExtensions.<DefinedElement>toSet(Iterables.<DefinedElement>concat(IterableExtensions.<TypeDefinition, EList<DefinedElement>>map(Iterables.<TypeDefinition>filter(CollectionsUtil.<Type>transitiveClosureStar(type, _function), TypeDefinition.class), _function_1)));
      _xblockexpression = existing.size();
    }
    return _xblockexpression;
  }
  
  protected Boolean setStringScope(final ALSDocument specification, final AlloySolverConfiguration config, final ALSRunCommand it) {
    boolean _xifexpression = false;
    if ((config.typeScopes.maxNewStrings == LogicSolverConfiguration.Unlimited)) {
      StringConcatenation _builder = new StringConcatenation();
      _builder.append("A string scope have to be specified for Alloy!");
      throw new UnsupportedOperationException(_builder.toString());
    } else {
      boolean _xifexpression_1 = false;
      if ((config.typeScopes.maxNewStrings == 0)) {
        EList<ALSTypeScope> _typeScopes = it.getTypeScopes();
        ALSStringScope _createALSStringScope = this.factory.createALSStringScope();
        final Procedure1<ALSStringScope> _function = (ALSStringScope it_1) -> {
          it_1.setNumber(0);
        };
        ALSStringScope _doubleArrow = ObjectExtensions.<ALSStringScope>operator_doubleArrow(_createALSStringScope, _function);
        _xifexpression_1 = _typeScopes.add(_doubleArrow);
      } else {
        boolean _xifexpression_2 = false;
        boolean _isEmpty = IteratorExtensions.isEmpty(Iterators.<ALSString>filter(specification.eAllContents(), ALSString.class));
        if (_isEmpty) {
          EList<ALSTypeScope> _typeScopes_1 = it.getTypeScopes();
          ALSStringScope _createALSStringScope_1 = this.factory.createALSStringScope();
          final Procedure1<ALSStringScope> _function_1 = (ALSStringScope it_1) -> {
            it_1.setNumber(0);
          };
          ALSStringScope _doubleArrow_1 = ObjectExtensions.<ALSStringScope>operator_doubleArrow(_createALSStringScope_1, _function_1);
          _xifexpression_2 = _typeScopes_1.add(_doubleArrow_1);
        } else {
          StringConcatenation _builder_1 = new StringConcatenation();
          _builder_1.append("A string scope have to be specified for Alloy!");
          throw new UnsupportedOperationException(_builder_1.toString());
        }
        _xifexpression_1 = _xifexpression_2;
      }
      _xifexpression = _xifexpression_1;
    }
    return Boolean.valueOf(_xifexpression);
  }
  
  protected boolean setIntegerScope(final ALSDocument specification, final AlloySolverConfiguration config, final ALSRunCommand command) {
    boolean _xifexpression = false;
    if ((config.typeScopes.maxNewIntegers == LogicSolverConfiguration.Unlimited)) {
      boolean _xblockexpression = false;
      {
        final Iterator<ALSInt> integersUsed = Iterators.<ALSInt>filter(specification.eAllContents(), ALSInt.class);
        boolean _xifexpression_1 = false;
        boolean _isEmpty = IteratorExtensions.isEmpty(integersUsed);
        if (_isEmpty) {
          EList<ALSTypeScope> _typeScopes = command.getTypeScopes();
          ALSIntScope _createALSIntScope = this.factory.createALSIntScope();
          final Procedure1<ALSIntScope> _function = (ALSIntScope it) -> {
            it.setNumber(0);
          };
          ALSIntScope _doubleArrow = ObjectExtensions.<ALSIntScope>operator_doubleArrow(_createALSIntScope, _function);
          _xifexpression_1 = _typeScopes.add(_doubleArrow);
        } else {
          StringConcatenation _builder = new StringConcatenation();
          _builder.append("An integer scope have to be specified for Alloy!");
          throw new UnsupportedOperationException(_builder.toString());
        }
        _xblockexpression = _xifexpression_1;
      }
      _xifexpression = _xblockexpression;
    } else {
      boolean _xblockexpression_1 = false;
      {
        final SortedSet<Integer> knownIntegers = config.typeScopes.knownIntegers;
        Integer _xifexpression_1 = null;
        boolean _isEmpty = knownIntegers.isEmpty();
        if (_isEmpty) {
          _xifexpression_1 = Integer.valueOf(Integer.MAX_VALUE);
        } else {
          _xifexpression_1 = IterableExtensions.<Integer>min(knownIntegers);
        }
        final Integer minKnownInteger = _xifexpression_1;
        Integer _xifexpression_2 = null;
        boolean _isEmpty_1 = knownIntegers.isEmpty();
        if (_isEmpty_1) {
          _xifexpression_2 = Integer.valueOf(Integer.MIN_VALUE);
        } else {
          _xifexpression_2 = IterableExtensions.<Integer>max(knownIntegers);
        }
        final Integer maxKnownInteger = _xifexpression_2;
        final Function1<ALSNumberLiteral, Integer> _function = (ALSNumberLiteral it) -> {
          return Integer.valueOf(it.getValue());
        };
        final List<Integer> integersInProblem = IteratorExtensions.<Integer>toList(IteratorExtensions.<ALSNumberLiteral, Integer>map(Iterators.<ALSNumberLiteral>filter(specification.eAllContents(), ALSNumberLiteral.class), _function));
        Integer _xifexpression_3 = null;
        boolean _isEmpty_2 = integersInProblem.isEmpty();
        if (_isEmpty_2) {
          _xifexpression_3 = Integer.valueOf(Integer.MAX_VALUE);
        } else {
          _xifexpression_3 = IterableExtensions.<Integer>min(integersInProblem);
        }
        final Integer minIntegerInProblem = _xifexpression_3;
        Integer _xifexpression_4 = null;
        boolean _isEmpty_3 = integersInProblem.isEmpty();
        if (_isEmpty_3) {
          _xifexpression_4 = Integer.valueOf(Integer.MIN_VALUE);
        } else {
          _xifexpression_4 = IterableExtensions.<Integer>max(integersInProblem);
        }
        final Integer maxIntegerInProblem = _xifexpression_4;
        final Integer min = IterableExtensions.<Integer>min(Collections.<Integer>unmodifiableList(CollectionLiterals.<Integer>newArrayList(minKnownInteger, minIntegerInProblem)));
        final Integer max = IterableExtensions.<Integer>max(Collections.<Integer>unmodifiableList(CollectionLiterals.<Integer>newArrayList(maxKnownInteger, maxIntegerInProblem)));
        EList<ALSTypeScope> _typeScopes = command.getTypeScopes();
        ALSIntScope _createALSIntScope = this.factory.createALSIntScope();
        final Procedure1<ALSIntScope> _function_1 = (ALSIntScope it) -> {
          it.setNumber(RunCommandMapper.toBits((min).intValue(), (max).intValue()));
        };
        ALSIntScope _doubleArrow = ObjectExtensions.<ALSIntScope>operator_doubleArrow(_createALSIntScope, _function_1);
        _xblockexpression_1 = _typeScopes.add(_doubleArrow);
      }
      _xifexpression = _xblockexpression_1;
    }
    return _xifexpression;
  }
  
  private static int toBits(final int min, final int max) {
    int bits = 1;
    int range = 1;
    while (((!((-range) <= min)) || (!(max <= (range - 1))))) {
      {
        bits++;
        int _range = range;
        range = (_range * 2);
      }
    }
    return bits;
  }
}
