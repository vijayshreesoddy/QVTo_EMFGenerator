package hu.bme.mit.inf.dslreasoner.application.execution;

import hu.bme.mit.inf.dslreasoner.logic.model.logiclanguage.DefinedElement;
import hu.bme.mit.inf.dslreasoner.logic.model.logiclanguage.Type;
import java.math.BigDecimal;
import java.util.Map;
import java.util.Set;
import org.eclipse.xtend.lib.annotations.Data;
import org.eclipse.xtext.xbase.lib.Pure;
import org.eclipse.xtext.xbase.lib.util.ToStringBuilder;

@Data
@SuppressWarnings("all")
public class KnownElements {
  private final Map<Type, Set<DefinedElement>> knownElementsByType;
  
  private final Set<Integer> knownIntegers;
  
  private final Set<BigDecimal> knownReals;
  
  private final Set<String> knownStrings;
  
  public KnownElements(final Map<Type, Set<DefinedElement>> knownElementsByType, final Set<Integer> knownIntegers, final Set<BigDecimal> knownReals, final Set<String> knownStrings) {
    super();
    this.knownElementsByType = knownElementsByType;
    this.knownIntegers = knownIntegers;
    this.knownReals = knownReals;
    this.knownStrings = knownStrings;
  }
  
  @Override
  @Pure
  public int hashCode() {
    final int prime = 31;
    int result = 1;
    result = prime * result + ((this.knownElementsByType== null) ? 0 : this.knownElementsByType.hashCode());
    result = prime * result + ((this.knownIntegers== null) ? 0 : this.knownIntegers.hashCode());
    result = prime * result + ((this.knownReals== null) ? 0 : this.knownReals.hashCode());
    return prime * result + ((this.knownStrings== null) ? 0 : this.knownStrings.hashCode());
  }
  
  @Override
  @Pure
  public boolean equals(final Object obj) {
    if (this == obj)
      return true;
    if (obj == null)
      return false;
    if (getClass() != obj.getClass())
      return false;
    KnownElements other = (KnownElements) obj;
    if (this.knownElementsByType == null) {
      if (other.knownElementsByType != null)
        return false;
    } else if (!this.knownElementsByType.equals(other.knownElementsByType))
      return false;
    if (this.knownIntegers == null) {
      if (other.knownIntegers != null)
        return false;
    } else if (!this.knownIntegers.equals(other.knownIntegers))
      return false;
    if (this.knownReals == null) {
      if (other.knownReals != null)
        return false;
    } else if (!this.knownReals.equals(other.knownReals))
      return false;
    if (this.knownStrings == null) {
      if (other.knownStrings != null)
        return false;
    } else if (!this.knownStrings.equals(other.knownStrings))
      return false;
    return true;
  }
  
  @Override
  @Pure
  public String toString() {
    ToStringBuilder b = new ToStringBuilder(this);
    b.add("knownElementsByType", this.knownElementsByType);
    b.add("knownIntegers", this.knownIntegers);
    b.add("knownReals", this.knownReals);
    b.add("knownStrings", this.knownStrings);
    return b.toString();
  }
  
  @Pure
  public Map<Type, Set<DefinedElement>> getKnownElementsByType() {
    return this.knownElementsByType;
  }
  
  @Pure
  public Set<Integer> getKnownIntegers() {
    return this.knownIntegers;
  }
  
  @Pure
  public Set<BigDecimal> getKnownReals() {
    return this.knownReals;
  }
  
  @Pure
  public Set<String> getKnownStrings() {
    return this.knownStrings;
  }
}
