package hu.bme.mit.inf.dlsreasoner.alloy.reasoner.builder;

import com.google.common.base.Objects;
import com.google.common.collect.Iterables;
import hu.bme.mit.inf.dlsreasoner.alloy.reasoner.builder.Logic2AlloyLanguageMapper;
import hu.bme.mit.inf.dlsreasoner.alloy.reasoner.builder.Logic2AlloyLanguageMapperTrace;
import hu.bme.mit.inf.dslreasoner.alloyLanguage.ALSAnd;
import hu.bme.mit.inf.dslreasoner.alloyLanguage.ALSDirectProduct;
import hu.bme.mit.inf.dslreasoner.alloyLanguage.ALSEnumDeclaration;
import hu.bme.mit.inf.dslreasoner.alloyLanguage.ALSEnumLiteral;
import hu.bme.mit.inf.dslreasoner.alloyLanguage.ALSEquals;
import hu.bme.mit.inf.dslreasoner.alloyLanguage.ALSIntersection;
import hu.bme.mit.inf.dslreasoner.alloyLanguage.ALSJoin;
import hu.bme.mit.inf.dslreasoner.alloyLanguage.ALSMultiplicity;
import hu.bme.mit.inf.dslreasoner.alloyLanguage.ALSNotEquals;
import hu.bme.mit.inf.dslreasoner.alloyLanguage.ALSOr;
import hu.bme.mit.inf.dslreasoner.alloyLanguage.ALSPlus;
import hu.bme.mit.inf.dslreasoner.alloyLanguage.ALSQuantifiedEx;
import hu.bme.mit.inf.dslreasoner.alloyLanguage.ALSReference;
import hu.bme.mit.inf.dslreasoner.alloyLanguage.ALSRelationDeclaration;
import hu.bme.mit.inf.dslreasoner.alloyLanguage.ALSTerm;
import hu.bme.mit.inf.dslreasoner.alloyLanguage.ALSVariableDeclaration;
import hu.bme.mit.inf.dslreasoner.alloyLanguage.AlloyLanguageFactory;
import hu.bme.mit.inf.dslreasoner.logic.model.logiclanguage.BoolTypeReference;
import hu.bme.mit.inf.dslreasoner.logic.model.logiclanguage.QuantifiedExpression;
import hu.bme.mit.inf.dslreasoner.logic.model.logiclanguage.Term;
import hu.bme.mit.inf.dslreasoner.logic.model.logiclanguage.TypeReference;
import hu.bme.mit.inf.dslreasoner.logic.model.logiclanguage.Variable;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.eclipse.emf.common.util.EList;
import org.eclipse.emf.ecore.util.EcoreUtil;
import org.eclipse.xtend2.lib.StringConcatenation;
import org.eclipse.xtext.xbase.lib.CollectionLiterals;
import org.eclipse.xtext.xbase.lib.Conversions;
import org.eclipse.xtext.xbase.lib.ExclusiveRange;
import org.eclipse.xtext.xbase.lib.Extension;
import org.eclipse.xtext.xbase.lib.Functions.Function1;
import org.eclipse.xtext.xbase.lib.IterableExtensions;
import org.eclipse.xtext.xbase.lib.ListExtensions;
import org.eclipse.xtext.xbase.lib.ObjectExtensions;
import org.eclipse.xtext.xbase.lib.Procedures.Procedure1;

@SuppressWarnings("all")
public class Logic2AlloyLanguageMapper_Support {
  @Extension
  private final AlloyLanguageFactory factory = AlloyLanguageFactory.eINSTANCE;
  
  protected String toIDMultiple(final String... ids) {
    final Function1<String, String> _function = (String it) -> {
      return IterableExtensions.join(((Iterable<?>)Conversions.doWrapArray(it.split("\\s+"))), "\'");
    };
    return IterableExtensions.join(ListExtensions.<String, String>map(((List<String>)Conversions.doWrapArray(ids)), _function), "\'");
  }
  
  protected String toID(final String ids) {
    return IterableExtensions.join(((Iterable<?>)Conversions.doWrapArray(ids.split("\\s+"))), "\'");
  }
  
  protected String toID(final List<String> ids) {
    final Function1<String, String> _function = (String it) -> {
      return IterableExtensions.join(((Iterable<?>)Conversions.doWrapArray(it.split("\\s+"))), "\'");
    };
    return IterableExtensions.join(ListExtensions.<String, String>map(ids, _function), "\'");
  }
  
  protected ALSEnumDeclaration getBooleanType(final Logic2AlloyLanguageMapperTrace trace) {
    boolean _notEquals = (!Objects.equal(trace.boolType, null));
    if (_notEquals) {
      return trace.boolType;
    } else {
      ALSEnumDeclaration _createALSEnumDeclaration = this.factory.createALSEnumDeclaration();
      final Procedure1<ALSEnumDeclaration> _function = (ALSEnumDeclaration it) -> {
        it.setName(this.toID(Collections.<String>unmodifiableList(CollectionLiterals.<String>newArrayList("util", "boolean"))));
        ALSEnumLiteral _createALSEnumLiteral = this.factory.createALSEnumLiteral();
        final Procedure1<ALSEnumLiteral> _function_1 = (ALSEnumLiteral it_1) -> {
          it_1.setName(this.toID(Collections.<String>unmodifiableList(CollectionLiterals.<String>newArrayList("util", "boolean", "true"))));
        };
        ALSEnumLiteral _doubleArrow = ObjectExtensions.<ALSEnumLiteral>operator_doubleArrow(_createALSEnumLiteral, _function_1);
        trace.boolTrue = _doubleArrow;
        EList<ALSEnumLiteral> _literal = it.getLiteral();
        _literal.add(trace.boolTrue);
        ALSEnumLiteral _createALSEnumLiteral_1 = this.factory.createALSEnumLiteral();
        final Procedure1<ALSEnumLiteral> _function_2 = (ALSEnumLiteral it_1) -> {
          it_1.setName(this.toID(Collections.<String>unmodifiableList(CollectionLiterals.<String>newArrayList("util", "boolean", "false"))));
        };
        ALSEnumLiteral _doubleArrow_1 = ObjectExtensions.<ALSEnumLiteral>operator_doubleArrow(_createALSEnumLiteral_1, _function_2);
        trace.boolFalse = _doubleArrow_1;
        EList<ALSEnumLiteral> _literal_1 = it.getLiteral();
        _literal_1.add(trace.boolFalse);
      };
      ALSEnumDeclaration _doubleArrow = ObjectExtensions.<ALSEnumDeclaration>operator_doubleArrow(_createALSEnumDeclaration, _function);
      trace.boolType = _doubleArrow;
      EList<ALSEnumDeclaration> _enumDeclarations = trace.specification.getEnumDeclarations();
      _enumDeclarations.add(trace.boolType);
      return trace.boolType;
    }
  }
  
  protected ALSEnumLiteral getBooleanTrue(final Logic2AlloyLanguageMapperTrace trace) {
    this.getBooleanType(trace);
    return trace.boolTrue;
  }
  
  protected ALSEnumLiteral getBooleanFalse(final Logic2AlloyLanguageMapperTrace trace) {
    this.getBooleanType(trace);
    return trace.boolFalse;
  }
  
  protected ALSEquals booleanToLogicValue(final ALSTerm boolReference, final Logic2AlloyLanguageMapperTrace trace) {
    ALSEquals _createALSEquals = this.factory.createALSEquals();
    final Procedure1<ALSEquals> _function = (ALSEquals it) -> {
      it.setLeftOperand(EcoreUtil.<ALSTerm>copy(boolReference));
      ALSReference _createALSReference = this.factory.createALSReference();
      final Procedure1<ALSReference> _function_1 = (ALSReference it_1) -> {
        it_1.setReferred(this.getBooleanTrue(trace));
      };
      ALSReference _doubleArrow = ObjectExtensions.<ALSReference>operator_doubleArrow(_createALSReference, _function_1);
      it.setRightOperand(_doubleArrow);
    };
    return ObjectExtensions.<ALSEquals>operator_doubleArrow(_createALSEquals, _function);
  }
  
  protected ALSTerm booleanToEnumValue(final ALSTerm value, final Logic2AlloyLanguageMapperTrace trace) {
    if ((value instanceof ALSEquals)) {
      final ALSTerm rightOperand = ((ALSEquals)value).getRightOperand();
      if ((rightOperand instanceof ALSReference)) {
        ALSRelationDeclaration _referred = ((ALSReference)rightOperand).getReferred();
        ALSEnumLiteral _booleanTrue = this.getBooleanTrue(trace);
        boolean _equals = Objects.equal(_referred, _booleanTrue);
        if (_equals) {
          return ((ALSEquals)value).getLeftOperand();
        }
      }
    }
    return value;
  }
  
  protected ALSTerm prepareParameterOfSymbolicReference(final TypeReference type, final ALSTerm term, final Logic2AlloyLanguageMapperTrace trace) {
    if ((type instanceof BoolTypeReference)) {
      return this.booleanToEnumValue(term, trace);
    } else {
      return term;
    }
  }
  
  protected ALSTerm postprocessResultOfSymbolicReference(final TypeReference type, final ALSTerm term, final Logic2AlloyLanguageMapperTrace trace) {
    if ((type instanceof BoolTypeReference)) {
      return this.booleanToLogicValue(term, trace);
    } else {
      return term;
    }
  }
  
  protected ALSTerm unfoldAnd(final List<? extends ALSTerm> operands) {
    int _size = operands.size();
    boolean _equals = (_size == 1);
    if (_equals) {
      return IterableExtensions.head(operands);
    } else {
      int _size_1 = operands.size();
      boolean _greaterThan = (_size_1 > 1);
      if (_greaterThan) {
        ALSAnd _createALSAnd = this.factory.createALSAnd();
        final Procedure1<ALSAnd> _function = (ALSAnd it) -> {
          it.setLeftOperand(IterableExtensions.head(operands));
          it.setRightOperand(this.unfoldAnd(operands.subList(1, operands.size())));
        };
        return ObjectExtensions.<ALSAnd>operator_doubleArrow(_createALSAnd, _function);
      } else {
        StringConcatenation _builder = new StringConcatenation();
        _builder.append("Logic operator with 0 operands!");
        throw new UnsupportedOperationException(_builder.toString());
      }
    }
  }
  
  protected ALSTerm unfoldOr(final List<? extends ALSTerm> operands, final Logic2AlloyLanguageMapperTrace trace) {
    int _size = operands.size();
    boolean _equals = (_size == 0);
    if (_equals) {
      return this.unfoldTrueStatement(trace);
    } else {
      int _size_1 = operands.size();
      boolean _equals_1 = (_size_1 == 1);
      if (_equals_1) {
        return IterableExtensions.head(operands);
      } else {
        int _size_2 = operands.size();
        boolean _greaterThan = (_size_2 > 1);
        if (_greaterThan) {
          ALSOr _createALSOr = this.factory.createALSOr();
          final Procedure1<ALSOr> _function = (ALSOr it) -> {
            it.setLeftOperand(IterableExtensions.head(operands));
            it.setRightOperand(this.unfoldOr(operands.subList(1, operands.size()), trace));
          };
          return ObjectExtensions.<ALSOr>operator_doubleArrow(_createALSOr, _function);
        }
      }
    }
    return null;
  }
  
  protected ALSEquals unfoldTrueStatement(final Logic2AlloyLanguageMapperTrace trace) {
    ALSEquals _createALSEquals = this.factory.createALSEquals();
    final Procedure1<ALSEquals> _function = (ALSEquals it) -> {
      ALSReference _createALSReference = this.factory.createALSReference();
      final Procedure1<ALSReference> _function_1 = (ALSReference it_1) -> {
        it_1.setReferred(this.getBooleanTrue(trace));
      };
      ALSReference _doubleArrow = ObjectExtensions.<ALSReference>operator_doubleArrow(_createALSReference, _function_1);
      it.setLeftOperand(_doubleArrow);
      ALSReference _createALSReference_1 = this.factory.createALSReference();
      final Procedure1<ALSReference> _function_2 = (ALSReference it_1) -> {
        it_1.setReferred(this.getBooleanTrue(trace));
      };
      ALSReference _doubleArrow_1 = ObjectExtensions.<ALSReference>operator_doubleArrow(_createALSReference_1, _function_2);
      it.setRightOperand(_doubleArrow_1);
    };
    return ObjectExtensions.<ALSEquals>operator_doubleArrow(_createALSEquals, _function);
  }
  
  protected ALSEquals unfoldTFalseStatement(final Logic2AlloyLanguageMapper m, final Logic2AlloyLanguageMapperTrace trace) {
    ALSEquals _createALSEquals = this.factory.createALSEquals();
    final Procedure1<ALSEquals> _function = (ALSEquals it) -> {
      ALSReference _createALSReference = this.factory.createALSReference();
      final Procedure1<ALSReference> _function_1 = (ALSReference it_1) -> {
        it_1.setReferred(this.getBooleanTrue(trace));
      };
      ALSReference _doubleArrow = ObjectExtensions.<ALSReference>operator_doubleArrow(_createALSReference, _function_1);
      it.setLeftOperand(_doubleArrow);
      ALSReference _createALSReference_1 = this.factory.createALSReference();
      final Procedure1<ALSReference> _function_2 = (ALSReference it_1) -> {
        it_1.setReferred(this.getBooleanTrue(trace));
      };
      ALSReference _doubleArrow_1 = ObjectExtensions.<ALSReference>operator_doubleArrow(_createALSReference_1, _function_2);
      it.setRightOperand(_doubleArrow_1);
    };
    return ObjectExtensions.<ALSEquals>operator_doubleArrow(_createALSEquals, _function);
  }
  
  protected ALSTerm unfoldPlus(final List<? extends ALSTerm> operands) {
    int _size = operands.size();
    boolean _equals = (_size == 1);
    if (_equals) {
      return IterableExtensions.head(operands);
    } else {
      int _size_1 = operands.size();
      boolean _greaterThan = (_size_1 > 1);
      if (_greaterThan) {
        ALSPlus _createALSPlus = this.factory.createALSPlus();
        final Procedure1<ALSPlus> _function = (ALSPlus it) -> {
          it.setLeftOperand(IterableExtensions.head(operands));
          it.setRightOperand(this.unfoldPlus(operands.subList(1, operands.size())));
        };
        return ObjectExtensions.<ALSPlus>operator_doubleArrow(_createALSPlus, _function);
      } else {
        return this.factory.createALSNone();
      }
    }
  }
  
  protected ALSTerm unfoldIntersection(final List<? extends ALSTerm> operands) {
    int _size = operands.size();
    boolean _equals = (_size == 1);
    if (_equals) {
      return IterableExtensions.head(operands);
    } else {
      int _size_1 = operands.size();
      boolean _greaterThan = (_size_1 > 1);
      if (_greaterThan) {
        ALSIntersection _createALSIntersection = this.factory.createALSIntersection();
        final Procedure1<ALSIntersection> _function = (ALSIntersection it) -> {
          it.setLeftOperand(IterableExtensions.head(operands));
          it.setRightOperand(this.unfoldIntersection(operands.subList(1, operands.size())));
        };
        return ObjectExtensions.<ALSIntersection>operator_doubleArrow(_createALSIntersection, _function);
      } else {
        StringConcatenation _builder = new StringConcatenation();
        _builder.append("Logic operator with 0 operands!");
        throw new UnsupportedOperationException(_builder.toString());
      }
    }
  }
  
  protected ALSTerm unfoldDistinctTerms(final Logic2AlloyLanguageMapper m, final List<Term> operands, final Logic2AlloyLanguageMapperTrace trace, final Map<Variable, ALSVariableDeclaration> variables) {
    int _size = operands.size();
    boolean _equals = (_size == 1);
    if (_equals) {
      return m.transformTerm(IterableExtensions.<Term>head(operands), trace, variables);
    } else {
      int _size_1 = operands.size();
      boolean _greaterThan = (_size_1 > 1);
      if (_greaterThan) {
        int _size_2 = operands.size();
        int _size_3 = operands.size();
        int _multiply = (_size_2 * _size_3);
        int _divide = (_multiply / 2);
        final ArrayList<ALSTerm> notEquals = new ArrayList<ALSTerm>(_divide);
        int _size_4 = operands.size();
        ExclusiveRange _doubleDotLessThan = new ExclusiveRange(0, _size_4, true);
        for (final Integer i : _doubleDotLessThan) {
          int _size_5 = operands.size();
          ExclusiveRange _doubleDotLessThan_1 = new ExclusiveRange(((i).intValue() + 1), _size_5, true);
          for (final Integer j : _doubleDotLessThan_1) {
            ALSNotEquals _createALSNotEquals = this.factory.createALSNotEquals();
            final Procedure1<ALSNotEquals> _function = (ALSNotEquals it) -> {
              it.setLeftOperand(m.transformTerm(operands.get((i).intValue()), trace, variables));
              it.setRightOperand(m.transformTerm(operands.get((j).intValue()), trace, variables));
            };
            ALSNotEquals _doubleArrow = ObjectExtensions.<ALSNotEquals>operator_doubleArrow(_createALSNotEquals, _function);
            notEquals.add(_doubleArrow);
          }
        }
        return this.unfoldAnd(notEquals);
      } else {
        StringConcatenation _builder = new StringConcatenation();
        _builder.append("Logic operator with 0 operands!");
        throw new UnsupportedOperationException(_builder.toString());
      }
    }
  }
  
  protected ALSTerm unfoldReferenceDirectProduct(final Logic2AlloyLanguageMapper m, final List<TypeReference> references, final Logic2AlloyLanguageMapperTrace trace) {
    int _size = references.size();
    boolean _equals = (_size == 1);
    if (_equals) {
      return m.transformTypeReference(IterableExtensions.<TypeReference>head(references), trace);
    } else {
      int _size_1 = references.size();
      boolean _greaterThan = (_size_1 > 1);
      if (_greaterThan) {
        ALSDirectProduct _createALSDirectProduct = this.factory.createALSDirectProduct();
        final Procedure1<ALSDirectProduct> _function = (ALSDirectProduct it) -> {
          it.setLeftOperand(m.transformTypeReference(IterableExtensions.<TypeReference>head(references), trace));
          it.setRightOperand(this.unfoldReferenceDirectProduct(m, references.subList(1, references.size()), trace));
        };
        return ObjectExtensions.<ALSDirectProduct>operator_doubleArrow(_createALSDirectProduct, _function);
      } else {
        throw new UnsupportedOperationException();
      }
    }
  }
  
  protected ALSTerm unfoldDotJoin(final Logic2AlloyLanguageMapper m, final List<Term> elements, final ALSTerm target, final Logic2AlloyLanguageMapperTrace trace, final Map<Variable, ALSVariableDeclaration> variables) {
    int _size = elements.size();
    boolean _equals = (_size == 1);
    if (_equals) {
      ALSJoin _createALSJoin = this.factory.createALSJoin();
      final Procedure1<ALSJoin> _function = (ALSJoin it) -> {
        it.setLeftOperand(m.transformTerm(IterableExtensions.<Term>head(elements), trace, variables));
        it.setRightOperand(target);
      };
      return ObjectExtensions.<ALSJoin>operator_doubleArrow(_createALSJoin, _function);
    } else {
      int _size_1 = elements.size();
      boolean _greaterThan = (_size_1 > 1);
      if (_greaterThan) {
        ALSJoin _createALSJoin_1 = this.factory.createALSJoin();
        final Procedure1<ALSJoin> _function_1 = (ALSJoin it) -> {
          it.setLeftOperand(m.transformTerm(IterableExtensions.<Term>last(elements), trace, variables));
          int _size_2 = elements.size();
          int _minus = (_size_2 - 1);
          it.setRightOperand(this.unfoldDotJoin(m, elements.subList(0, _minus), target, trace, variables));
        };
        return ObjectExtensions.<ALSJoin>operator_doubleArrow(_createALSJoin_1, _function_1);
      } else {
        throw new UnsupportedOperationException();
      }
    }
  }
  
  protected ALSTerm unfoldTermDirectProduct(final Logic2AlloyLanguageMapper m, final List<Term> references, final Logic2AlloyLanguageMapperTrace trace, final Map<Variable, ALSVariableDeclaration> variables) {
    int _size = references.size();
    boolean _equals = (_size == 1);
    if (_equals) {
      return m.transformTerm(IterableExtensions.<Term>head(references), trace, variables);
    } else {
      int _size_1 = references.size();
      boolean _greaterThan = (_size_1 > 1);
      if (_greaterThan) {
        ALSDirectProduct _createALSDirectProduct = this.factory.createALSDirectProduct();
        final Procedure1<ALSDirectProduct> _function = (ALSDirectProduct it) -> {
          it.setLeftOperand(m.transformTerm(IterableExtensions.<Term>head(references), trace, variables));
          it.setRightOperand(this.unfoldTermDirectProduct(m, references.subList(1, references.size()), trace, variables));
        };
        return ObjectExtensions.<ALSDirectProduct>operator_doubleArrow(_createALSDirectProduct, _function);
      } else {
        throw new UnsupportedOperationException();
      }
    }
  }
  
  protected ALSQuantifiedEx createQuantifiedExpression(final Logic2AlloyLanguageMapper m, final QuantifiedExpression q, final ALSMultiplicity multiplicity, final Logic2AlloyLanguageMapperTrace trace, final Map<Variable, ALSVariableDeclaration> variables) {
    ALSQuantifiedEx _xblockexpression = null;
    {
      final Function1<Variable, ALSVariableDeclaration> _function = (Variable v) -> {
        ALSVariableDeclaration _createALSVariableDeclaration = this.factory.createALSVariableDeclaration();
        final Procedure1<ALSVariableDeclaration> _function_1 = (ALSVariableDeclaration it) -> {
          it.setName(this.toID(v.getName()));
          it.setRange(m.transformTypeReference(v.getRange(), trace));
        };
        return ObjectExtensions.<ALSVariableDeclaration>operator_doubleArrow(_createALSVariableDeclaration, _function_1);
      };
      final Map<Variable, ALSVariableDeclaration> variableMap = IterableExtensions.<Variable, ALSVariableDeclaration>toInvertedMap(q.getQuantifiedVariables(), _function);
      ALSQuantifiedEx _createALSQuantifiedEx = this.factory.createALSQuantifiedEx();
      final Procedure1<ALSQuantifiedEx> _function_1 = (ALSQuantifiedEx it) -> {
        it.setType(multiplicity);
        EList<ALSVariableDeclaration> _variables = it.getVariables();
        Collection<ALSVariableDeclaration> _values = variableMap.values();
        Iterables.<ALSVariableDeclaration>addAll(_variables, _values);
        it.setExpression(m.transformTerm(q.getExpression(), trace, this.withAddition(variables, variableMap)));
      };
      _xblockexpression = ObjectExtensions.<ALSQuantifiedEx>operator_doubleArrow(_createALSQuantifiedEx, _function_1);
    }
    return _xblockexpression;
  }
  
  protected HashMap<Variable, ALSVariableDeclaration> withAddition(final Map<Variable, ALSVariableDeclaration> v1, final Map<Variable, ALSVariableDeclaration> v2) {
    HashMap<Variable, ALSVariableDeclaration> _hashMap = new HashMap<Variable, ALSVariableDeclaration>(v1);
    final Procedure1<HashMap<Variable, ALSVariableDeclaration>> _function = (HashMap<Variable, ALSVariableDeclaration> it) -> {
      it.putAll(v2);
    };
    return ObjectExtensions.<HashMap<Variable, ALSVariableDeclaration>>operator_doubleArrow(_hashMap, _function);
  }
}
