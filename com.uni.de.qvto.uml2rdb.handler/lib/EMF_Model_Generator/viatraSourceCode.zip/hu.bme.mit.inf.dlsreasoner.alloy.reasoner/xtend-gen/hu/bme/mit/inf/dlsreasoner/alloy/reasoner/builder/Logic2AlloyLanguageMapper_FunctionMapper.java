package hu.bme.mit.inf.dlsreasoner.alloy.reasoner.builder;

import hu.bme.mit.inf.dlsreasoner.alloy.reasoner.builder.Logic2AlloyLanguageMapper;
import hu.bme.mit.inf.dlsreasoner.alloy.reasoner.builder.Logic2AlloyLanguageMapperTrace;
import hu.bme.mit.inf.dlsreasoner.alloy.reasoner.builder.Logic2AlloyLanguageMapper_Support;
import hu.bme.mit.inf.dslreasoner.alloyLanguage.ALSDirectProduct;
import hu.bme.mit.inf.dslreasoner.alloyLanguage.ALSFieldDeclaration;
import hu.bme.mit.inf.dslreasoner.alloyLanguage.ALSFunctionDefinition;
import hu.bme.mit.inf.dslreasoner.alloyLanguage.ALSMultiplicity;
import hu.bme.mit.inf.dslreasoner.alloyLanguage.ALSSignatureBody;
import hu.bme.mit.inf.dslreasoner.alloyLanguage.ALSSignatureDeclaration;
import hu.bme.mit.inf.dslreasoner.alloyLanguage.ALSVariableDeclaration;
import hu.bme.mit.inf.dslreasoner.alloyLanguage.AlloyLanguageFactory;
import hu.bme.mit.inf.dslreasoner.logic.model.logiclanguage.ComplexTypeReference;
import hu.bme.mit.inf.dslreasoner.logic.model.logiclanguage.Function;
import hu.bme.mit.inf.dslreasoner.logic.model.logiclanguage.FunctionDeclaration;
import hu.bme.mit.inf.dslreasoner.logic.model.logiclanguage.FunctionDefinition;
import hu.bme.mit.inf.dslreasoner.logic.model.logiclanguage.Type;
import hu.bme.mit.inf.dslreasoner.logic.model.logiclanguage.TypeReference;
import hu.bme.mit.inf.dslreasoner.logic.model.logiclanguage.Variable;
import hu.bme.mit.inf.dslreasoner.util.CollectionsUtil;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import org.eclipse.emf.common.util.EList;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.xtext.xbase.lib.Extension;
import org.eclipse.xtext.xbase.lib.IterableExtensions;
import org.eclipse.xtext.xbase.lib.ObjectExtensions;
import org.eclipse.xtext.xbase.lib.Procedures.Procedure1;

@SuppressWarnings("all")
public class Logic2AlloyLanguageMapper_FunctionMapper {
  @Extension
  private final AlloyLanguageFactory factory = AlloyLanguageFactory.eINSTANCE;
  
  private final Logic2AlloyLanguageMapper_Support support = new Logic2AlloyLanguageMapper_Support();
  
  private final Logic2AlloyLanguageMapper base;
  
  public Logic2AlloyLanguageMapper_FunctionMapper(final Logic2AlloyLanguageMapper base) {
    this.base = base;
  }
  
  protected EObject _transformFunction(final FunctionDeclaration f, final Logic2AlloyLanguageMapperTrace trace) {
    ALSFieldDeclaration _xifexpression = null;
    boolean _containsKey = trace.constantDefinitions.containsKey(f);
    boolean _not = (!_containsKey);
    if (_not) {
      ALSFieldDeclaration _xifexpression_1 = null;
      boolean _transformedToHostedField = this.transformedToHostedField(f, trace);
      if (_transformedToHostedField) {
        _xifexpression_1 = this.transformFunctionToFieldOfSignature(f, trace);
      } else {
        _xifexpression_1 = this.transformFunctionToGlobalRelation(f, trace);
      }
      _xifexpression = _xifexpression_1;
    }
    return _xifexpression;
  }
  
  protected boolean transformedToHostedField(final FunctionDeclaration f, final Logic2AlloyLanguageMapperTrace trace) {
    if (((f.getParameters().size() == 1) && (IterableExtensions.<TypeReference>head(f.getParameters()) instanceof ComplexTypeReference))) {
      final TypeReference head = IterableExtensions.<TypeReference>head(f.getParameters());
      if ((head instanceof ComplexTypeReference)) {
        final List<ALSSignatureDeclaration> types = this.base.getTypeMapper().transformTypeReference(((ComplexTypeReference)head).getReferred(), this.base, trace);
        int _size = types.size();
        return (_size == 1);
      }
    }
    return ((f.getParameters().size() == 1) && (IterableExtensions.<TypeReference>head(f.getParameters()) instanceof ComplexTypeReference));
  }
  
  protected ALSFieldDeclaration transformFunctionToFieldOfSignature(final FunctionDeclaration f, final Logic2AlloyLanguageMapperTrace trace) {
    ALSFieldDeclaration _xblockexpression = null;
    {
      TypeReference _head = IterableExtensions.<TypeReference>head(f.getParameters());
      final ComplexTypeReference param = ((ComplexTypeReference) _head);
      final Type referred = param.getReferred();
      ALSFieldDeclaration _createALSFieldDeclaration = this.factory.createALSFieldDeclaration();
      final Procedure1<ALSFieldDeclaration> _function = (ALSFieldDeclaration it) -> {
        it.setName(this.support.toID(f.getName()));
        it.setMultiplicity(ALSMultiplicity.ONE);
        it.setType(this.base.transformTypeReference(f.getRange(), trace));
      };
      final ALSFieldDeclaration field = ObjectExtensions.<ALSFieldDeclaration>operator_doubleArrow(_createALSFieldDeclaration, _function);
      final ALSSignatureDeclaration host = this.base.getTypeMapper().transformTypeReference(referred, this.base, trace).get(0);
      EObject _eContainer = host.eContainer();
      EList<ALSFieldDeclaration> _fields = ((ALSSignatureBody) _eContainer).getFields();
      _fields.add(field);
      _xblockexpression = trace.functionDeclaration2HostedField.put(f, field);
    }
    return _xblockexpression;
  }
  
  protected ALSFieldDeclaration transformFunctionToGlobalRelation(final FunctionDeclaration f, final Logic2AlloyLanguageMapperTrace trace) {
    ALSFieldDeclaration _xblockexpression = null;
    {
      ALSFieldDeclaration _createALSFieldDeclaration = this.factory.createALSFieldDeclaration();
      final Procedure1<ALSFieldDeclaration> _function = (ALSFieldDeclaration it) -> {
        it.setName(this.support.toID(f.getName()));
        it.setMultiplicity(ALSMultiplicity.SET);
        ALSDirectProduct _createALSDirectProduct = this.factory.createALSDirectProduct();
        final Procedure1<ALSDirectProduct> _function_1 = (ALSDirectProduct it_1) -> {
          it_1.setLeftOperand(this.support.unfoldReferenceDirectProduct(this.base, f.getParameters(), trace));
          it_1.setRightMultiplicit(ALSMultiplicity.ONE);
          it_1.setRightOperand(this.base.transformTypeReference(f.getRange(), trace));
        };
        ALSDirectProduct _doubleArrow = ObjectExtensions.<ALSDirectProduct>operator_doubleArrow(_createALSDirectProduct, _function_1);
        it.setType(_doubleArrow);
      };
      final ALSFieldDeclaration field = ObjectExtensions.<ALSFieldDeclaration>operator_doubleArrow(_createALSFieldDeclaration, _function);
      EList<ALSFieldDeclaration> _fields = trace.logicLanguageBody.getFields();
      _fields.add(field);
      _xblockexpression = trace.functionDeclaration2LanguageField.put(f, field);
    }
    return _xblockexpression;
  }
  
  protected EObject _transformFunction(final FunctionDefinition f, final Logic2AlloyLanguageMapperTrace trace) {
    ALSFunctionDefinition _xblockexpression = null;
    {
      ALSFunctionDefinition _createALSFunctionDefinition = this.factory.createALSFunctionDefinition();
      final Procedure1<ALSFunctionDefinition> _function = (ALSFunctionDefinition it) -> {
        it.setName(this.support.toID(f.getName()));
      };
      final ALSFunctionDefinition res = ObjectExtensions.<ALSFunctionDefinition>operator_doubleArrow(_createALSFunctionDefinition, _function);
      EList<ALSFunctionDefinition> _functionDefinitions = trace.specification.getFunctionDefinitions();
      _functionDefinitions.add(res);
      _xblockexpression = trace.functionDefinition2Function.put(f, res);
    }
    return _xblockexpression;
  }
  
  protected void transformFunctionDefinitionSpecification(final FunctionDefinition f, final Logic2AlloyLanguageMapperTrace trace) {
    final ALSFunctionDefinition target = CollectionsUtil.<FunctionDefinition, ALSFunctionDefinition>lookup(f, trace.functionDefinition2Function);
    final HashMap<Variable, ALSVariableDeclaration> variableMap = new HashMap<Variable, ALSVariableDeclaration>();
    EList<Variable> _variable = f.getVariable();
    for (final Variable variable : _variable) {
      {
        ALSVariableDeclaration _createALSVariableDeclaration = this.factory.createALSVariableDeclaration();
        final Procedure1<ALSVariableDeclaration> _function = (ALSVariableDeclaration it) -> {
          it.setName(this.support.toID(variable.getName()));
          it.setRange(this.base.transformTypeReference(variable.getRange(), trace));
        };
        final ALSVariableDeclaration v = ObjectExtensions.<ALSVariableDeclaration>operator_doubleArrow(_createALSVariableDeclaration, _function);
        EList<ALSVariableDeclaration> _variables = target.getVariables();
        _variables.add(v);
        variableMap.put(variable, v);
      }
    }
    target.setValue(this.base.transformTerm(f.getValue(), trace, variableMap));
  }
  
  protected EObject transformFunction(final Function f, final Logic2AlloyLanguageMapperTrace trace) {
    if (f instanceof FunctionDeclaration) {
      return _transformFunction((FunctionDeclaration)f, trace);
    } else if (f instanceof FunctionDefinition) {
      return _transformFunction((FunctionDefinition)f, trace);
    } else {
      throw new IllegalArgumentException("Unhandled parameter types: " +
        Arrays.<Object>asList(f, trace).toString());
    }
  }
}
