package hu.bme.mit.inf.dlsreasoner.alloy.reasoner.builder;

import com.google.common.base.Objects;
import edu.mit.csail.sdg.alloy4.SafeList;
import edu.mit.csail.sdg.alloy4compiler.ast.ExprVar;
import edu.mit.csail.sdg.alloy4compiler.ast.Sig;
import edu.mit.csail.sdg.alloy4compiler.ast.Type;
import edu.mit.csail.sdg.alloy4compiler.translator.A4Solution;
import edu.mit.csail.sdg.alloy4compiler.translator.A4Tuple;
import edu.mit.csail.sdg.alloy4compiler.translator.A4TupleSet;
import hu.bme.mit.inf.dlsreasoner.alloy.reasoner.builder.AlloyModelInterpretation_TypeInterpretation;
import hu.bme.mit.inf.dlsreasoner.alloy.reasoner.builder.Logic2AlloyLanguageMapper;
import hu.bme.mit.inf.dlsreasoner.alloy.reasoner.builder.Logic2AlloyLanguageMapperTrace;
import hu.bme.mit.inf.dlsreasoner.alloy.reasoner.builder.ParameterSubstitution;
import hu.bme.mit.inf.dslreasoner.alloyLanguage.ALSFieldDeclaration;
import hu.bme.mit.inf.dslreasoner.logic.model.builder.LogicModelInterpretation;
import hu.bme.mit.inf.dslreasoner.logic.model.logiclanguage.ConstantDeclaration;
import hu.bme.mit.inf.dslreasoner.logic.model.logiclanguage.DefinedElement;
import hu.bme.mit.inf.dslreasoner.logic.model.logiclanguage.FunctionDeclaration;
import hu.bme.mit.inf.dslreasoner.logic.model.logiclanguage.LogiclanguageFactory;
import hu.bme.mit.inf.dslreasoner.logic.model.logiclanguage.RelationDeclaration;
import hu.bme.mit.inf.dslreasoner.logic.model.logiclanguage.TypeDeclaration;
import hu.bme.mit.inf.dslreasoner.logic.model.logiclanguage.TypeDefinition;
import hu.bme.mit.inf.dslreasoner.util.CollectionsUtil;
import java.math.BigDecimal;
import java.util.Arrays;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.SortedSet;
import java.util.TreeSet;
import java.util.function.BiConsumer;
import java.util.function.Consumer;
import org.eclipse.xtend2.lib.StringConcatenation;
import org.eclipse.xtext.xbase.lib.CollectionLiterals;
import org.eclipse.xtext.xbase.lib.Conversions;
import org.eclipse.xtext.xbase.lib.Exceptions;
import org.eclipse.xtext.xbase.lib.ExclusiveRange;
import org.eclipse.xtext.xbase.lib.Extension;
import org.eclipse.xtext.xbase.lib.Functions.Function1;
import org.eclipse.xtext.xbase.lib.InputOutput;
import org.eclipse.xtext.xbase.lib.IntegerRange;
import org.eclipse.xtext.xbase.lib.IterableExtensions;
import org.eclipse.xtext.xbase.lib.ListExtensions;
import org.eclipse.xtext.xbase.lib.MapExtensions;
import org.eclipse.xtext.xbase.lib.Pair;

@SuppressWarnings("all")
public class AlloyModelInterpretation implements LogicModelInterpretation {
  @Extension
  protected final LogiclanguageFactory factory = LogiclanguageFactory.eINSTANCE;
  
  protected final AlloyModelInterpretation_TypeInterpretation typeInterpretator;
  
  protected final Logic2AlloyLanguageMapper forwardMapper;
  
  protected final Logic2AlloyLanguageMapperTrace forwardTrace;
  
  private ExprVar logicLanguage;
  
  private String logicBooleanTrue;
  
  private String logicBooleanFalse;
  
  private SortedSet<Integer> integerAtoms = new TreeSet<Integer>();
  
  private SortedSet<String> stringAtoms = new TreeSet<String>();
  
  private final Map<String, DefinedElement> alloyAtom2LogicElement = new HashMap<String, DefinedElement>();
  
  private final Map<TypeDeclaration, List<DefinedElement>> interpretationOfUndefinedType = new HashMap<TypeDeclaration, List<DefinedElement>>();
  
  private final Map<ConstantDeclaration, Object> constant2Value;
  
  private final Map<FunctionDeclaration, ? extends Map<ParameterSubstitution, Object>> function2Value;
  
  private final Map<RelationDeclaration, ? extends Set<ParameterSubstitution>> relation2Value;
  
  public AlloyModelInterpretation(final AlloyModelInterpretation_TypeInterpretation typeInterpretator, final A4Solution solution, final Logic2AlloyLanguageMapper forwardMapper, final Logic2AlloyLanguageMapperTrace trace) {
    this.typeInterpretator = typeInterpretator;
    this.forwardMapper = forwardMapper;
    this.forwardTrace = trace;
    final Map<String, Sig> name2AlloySig = new HashMap<String, Sig>();
    final Map<String, Sig.Field> name2AlloyField = new HashMap<String, Sig.Field>();
    SafeList<Sig> _allReachableSigs = solution.getAllReachableSigs();
    for (final Sig sig : _allReachableSigs) {
      {
        name2AlloySig.put(sig.label, sig);
        SafeList<Sig.Field> _fields = sig.getFields();
        for (final Sig.Field field : _fields) {
          name2AlloyField.put(field.label, field);
        }
      }
    }
    final List<ExprVar> unknownAtoms = this.collectUnknownAndResolveKnownAtoms(solution);
    this.typeInterpretator.resolveUnknownAtoms(unknownAtoms, solution, 
      this.forwardTrace, name2AlloySig, name2AlloyField, 
      this.alloyAtom2LogicElement, 
      this.interpretationOfUndefinedType);
    final Function1<ALSFieldDeclaration, Object> _function = (ALSFieldDeclaration it) -> {
      return this.atomLabel2Term(IterableExtensions.<A4Tuple>head(solution.eval(CollectionsUtil.<String, Sig.Field>lookup(it.getName(), name2AlloyField))).atom(1));
    };
    this.constant2Value = MapExtensions.<ConstantDeclaration, ALSFieldDeclaration, Object>mapValues(this.forwardTrace.constantDeclaration2LanguageField, _function);
    final Function1<ALSFieldDeclaration, HashMap<ParameterSubstitution, Object>> _function_1 = (ALSFieldDeclaration function) -> {
      final Function1<A4Tuple, Pair<ParameterSubstitution, Object>> _function_2 = (A4Tuple t) -> {
        Object _atomLabel2Term = this.atomLabel2Term(t.atom(0));
        ParameterSubstitution _parameterSubstitution = new ParameterSubstitution(new Object[] { _atomLabel2Term });
        Object _atomLabel2Term_1 = this.atomLabel2Term(t.atom(1));
        return Pair.<ParameterSubstitution, Object>of(_parameterSubstitution, _atomLabel2Term_1);
      };
      return CollectionLiterals.<ParameterSubstitution, Object>newHashMap(
        ((Pair<? extends ParameterSubstitution, ?>[])Conversions.unwrapArray(IterableExtensions.<A4Tuple, Pair<ParameterSubstitution, Object>>map(solution.eval(CollectionsUtil.<String, Sig.Field>lookup(function.getName(), name2AlloyField)), _function_2), Pair.class)));
    };
    final Map<FunctionDeclaration, HashMap<ParameterSubstitution, Object>> hostedfunction2Value = MapExtensions.<FunctionDeclaration, ALSFieldDeclaration, HashMap<ParameterSubstitution, Object>>mapValues(this.forwardTrace.functionDeclaration2HostedField, _function_1);
    final Function1<FunctionDeclaration, HashMap<ParameterSubstitution, Object>> _function_2 = (FunctionDeclaration function) -> {
      final ALSFieldDeclaration alsFunction = CollectionsUtil.<FunctionDeclaration, ALSFieldDeclaration>lookup(function, this.forwardTrace.functionDeclaration2LanguageField);
      int _size = function.getParameters().size();
      final IntegerRange paramIndexes = new IntegerRange(1, _size);
      final Function1<A4Tuple, Pair<ParameterSubstitution, Object>> _function_3 = (A4Tuple t) -> {
        final Function1<Integer, Object> _function_4 = (Integer it) -> {
          return this.atomLabel2Term(t.atom((it).intValue()));
        };
        Iterable<Object> _map = IterableExtensions.<Integer, Object>map(paramIndexes, _function_4);
        ParameterSubstitution _parameterSubstitution = new ParameterSubstitution(((Object[])Conversions.unwrapArray(_map, Object.class)));
        int _size_1 = function.getParameters().size();
        int _plus = (_size_1 + 1);
        Object _atomLabel2Term = this.atomLabel2Term(t.atom(_plus));
        return Pair.<ParameterSubstitution, Object>of(_parameterSubstitution, _atomLabel2Term);
      };
      return CollectionLiterals.<ParameterSubstitution, Object>newHashMap(
        ((Pair<? extends ParameterSubstitution, ?>[])Conversions.unwrapArray(IterableExtensions.<A4Tuple, Pair<ParameterSubstitution, Object>>map(solution.eval(CollectionsUtil.<String, Sig.Field>lookup(alsFunction.getName(), name2AlloyField)), _function_3), Pair.class)));
    };
    final Map<FunctionDeclaration, HashMap<ParameterSubstitution, Object>> globalfunction2Value = IterableExtensions.<FunctionDeclaration, HashMap<ParameterSubstitution, Object>>toInvertedMap(this.forwardTrace.functionDeclaration2LanguageField.keySet(), _function_2);
    this.function2Value = CollectionsUtil.<FunctionDeclaration, HashMap<ParameterSubstitution, Object>>Union(hostedfunction2Value, globalfunction2Value);
    final Function1<ALSFieldDeclaration, Set<ParameterSubstitution>> _function_3 = (ALSFieldDeclaration relation) -> {
      final Function1<A4Tuple, ParameterSubstitution> _function_4 = (A4Tuple t) -> {
        Object _atomLabel2Term = this.atomLabel2Term(t.atom(0));
        Object _atomLabel2Term_1 = this.atomLabel2Term(t.atom(1));
        return new ParameterSubstitution(new Object[] { _atomLabel2Term, _atomLabel2Term_1 });
      };
      return IterableExtensions.<ParameterSubstitution>toSet(IterableExtensions.<A4Tuple, ParameterSubstitution>map(solution.eval(CollectionsUtil.<String, Sig.Field>lookup(relation.getName(), name2AlloyField)), _function_4));
    };
    final Map<RelationDeclaration, Set<ParameterSubstitution>> hostedRelation2Value = MapExtensions.<RelationDeclaration, ALSFieldDeclaration, Set<ParameterSubstitution>>mapValues(this.forwardTrace.relationDeclaration2Field, _function_3);
    final Function1<ALSFieldDeclaration, Set<ParameterSubstitution>> _function_4 = (ALSFieldDeclaration relation) -> {
      final Function1<A4Tuple, ParameterSubstitution> _function_5 = (A4Tuple t) -> {
        int _arity = t.arity();
        final Function1<Integer, Object> _function_6 = (Integer a) -> {
          return this.atomLabel2Term(t.atom(a));
        };
        Iterable<Object> _map = IterableExtensions.<Integer, Object>map(new ExclusiveRange(1, _arity, true), _function_6);
        return new ParameterSubstitution(((Object[])Conversions.unwrapArray(_map, Object.class)));
      };
      return IterableExtensions.<ParameterSubstitution>toSet(IterableExtensions.<A4Tuple, ParameterSubstitution>map(solution.eval(CollectionsUtil.<String, Sig.Field>lookup(relation.getName(), name2AlloyField)), _function_5));
    };
    final Map<RelationDeclaration, Set<ParameterSubstitution>> globalRelation2Value = MapExtensions.<RelationDeclaration, ALSFieldDeclaration, Set<ParameterSubstitution>>mapValues(this.forwardTrace.relationDeclaration2Global, _function_4);
    this.relation2Value = CollectionsUtil.<RelationDeclaration, Set<ParameterSubstitution>>Union(hostedRelation2Value, globalRelation2Value);
  }
  
  public List<ExprVar> collectUnknownAndResolveKnownAtoms(final A4Solution solution) {
    final Iterable<ExprVar> allAtoms = solution.getAllAtoms();
    final List<ExprVar> unknownAtoms = new LinkedList<ExprVar>();
    for (final ExprVar atom : allAtoms) {
      {
        final String typeName = this.getName(atom.type());
        final String[] atomName = this.getName(atom);
        String _name = this.forwardTrace.logicLanguage.getName();
        boolean _equals = Objects.equal(typeName, _name);
        if (_equals) {
          this.logicLanguage = atom;
        } else {
          if ((Objects.equal(typeName, "Int") || Objects.equal(typeName, "seq/Int"))) {
            final int value = Integer.parseInt(IterableExtensions.join(((Iterable<?>)Conversions.doWrapArray(atomName))));
            this.integerAtoms.add(Integer.valueOf(value));
          } else {
            if (((!Objects.equal(this.forwardTrace.boolType, null)) && Objects.equal(typeName, this.forwardTrace.boolType.getName()))) {
              String _head = IterableExtensions.<String>head(((Iterable<String>)Conversions.doWrapArray(atomName)));
              String _name_1 = this.forwardTrace.boolTrue.getName();
              boolean _equals_1 = Objects.equal(_head, _name_1);
              if (_equals_1) {
                this.logicBooleanTrue = atom.label;
              } else {
                String _head_1 = IterableExtensions.<String>head(((Iterable<String>)Conversions.doWrapArray(atomName)));
                String _name_2 = this.forwardTrace.boolFalse.getName();
                boolean _equals_2 = Objects.equal(_head_1, _name_2);
                if (_equals_2) {
                  this.logicBooleanFalse = atom.label;
                } else {
                  StringConcatenation _builder = new StringConcatenation();
                  _builder.append("Unknown boolean value: ");
                  _builder.append(atom);
                  throw new UnsupportedOperationException(_builder.toString());
                }
              }
            } else {
              boolean _equals_3 = Objects.equal(typeName, "String");
              if (_equals_3) {
                final String value_1 = this.parseString(IterableExtensions.join(((Iterable<?>)Conversions.doWrapArray(atomName))));
                this.stringAtoms.add(value_1);
              } else {
                unknownAtoms.add(atom);
              }
            }
          }
        }
      }
    }
    final Function1<Sig, Boolean> _function = (Sig it) -> {
      return Boolean.valueOf(Objects.equal(it.label, "Int"));
    };
    final Sig integerSignature = IterableExtensions.<Sig>head(IterableExtensions.<Sig>filter(solution.getAllReachableSigs(), _function));
    A4TupleSet _eval = solution.eval(integerSignature);
    for (final A4Tuple i : _eval) {
      {
        final int value = Integer.parseInt(i.atom(0));
        this.integerAtoms.add(Integer.valueOf(value));
      }
    }
    final Function1<Sig, Boolean> _function_1 = (Sig it) -> {
      return Boolean.valueOf(Objects.equal(it.label, "String"));
    };
    final Sig stringSignature = IterableExtensions.<Sig>head(IterableExtensions.<Sig>filter(solution.getAllReachableSigs(), _function_1));
    A4TupleSet _eval_1 = solution.eval(stringSignature);
    for (final A4Tuple i_1 : _eval_1) {
      {
        final String value = this.parseString(i_1.atom(0));
        this.stringAtoms.add(value);
      }
    }
    return unknownAtoms;
  }
  
  private String getName(final Type type) {
    final String name = type.toString();
    if ((name.startsWith("{this/") && name.endsWith("}"))) {
      return type.toString().replaceFirst("\\{this\\/", "").replace("}", "");
    } else {
      StringConcatenation _builder = new StringConcatenation();
      _builder.append("Unknown type format: \"");
      _builder.append(name);
      _builder.append("\"!");
      throw new IllegalArgumentException(_builder.toString());
    }
  }
  
  private String[] getName(final ExprVar atom) {
    return atom.toString().split("\\$");
  }
  
  public void print(final Logic2AlloyLanguageMapperTrace trace) {
    StringConcatenation _builder = new StringConcatenation();
    _builder.append("Undefined-----");
    InputOutput.<String>println(_builder.toString());
    final BiConsumer<TypeDeclaration, List<DefinedElement>> _function = (TypeDeclaration k, List<DefinedElement> v) -> {
      StringConcatenation _builder_1 = new StringConcatenation();
      String _name = k.getName();
      _builder_1.append(_name);
      _builder_1.append(" -> ");
      final Function1<DefinedElement, String> _function_1 = (DefinedElement it) -> {
        return it.getName();
      };
      List<String> _map = ListExtensions.<DefinedElement, String>map(v, _function_1);
      _builder_1.append(_map);
      InputOutput.<String>println(_builder_1.toString());
    };
    this.interpretationOfUndefinedType.forEach(_function);
    StringConcatenation _builder_1 = new StringConcatenation();
    _builder_1.append("Constants-----");
    InputOutput.<String>println(_builder_1.toString());
    final BiConsumer<ConstantDeclaration, Object> _function_1 = (ConstantDeclaration k, Object v) -> {
      StringConcatenation _builder_2 = new StringConcatenation();
      String _name = k.getName();
      _builder_2.append(_name);
      _builder_2.append(" : ");
      _builder_2.append(v);
      InputOutput.<String>println(_builder_2.toString());
    };
    this.constant2Value.forEach(_function_1);
    StringConcatenation _builder_2 = new StringConcatenation();
    _builder_2.append("Functions-----");
    InputOutput.<String>println(_builder_2.toString());
    final BiConsumer<FunctionDeclaration, Map<ParameterSubstitution, Object>> _function_2 = (FunctionDeclaration f, Map<ParameterSubstitution, Object> m) -> {
      final BiConsumer<ParameterSubstitution, Object> _function_3 = (ParameterSubstitution k, Object v) -> {
        StringConcatenation _builder_3 = new StringConcatenation();
        String _name = f.getName();
        _builder_3.append(_name);
        _builder_3.append(" : ");
        _builder_3.append(k);
        _builder_3.append(" |-> ");
        _builder_3.append(v);
        InputOutput.<String>println(_builder_3.toString());
      };
      m.forEach(_function_3);
    };
    this.function2Value.forEach(_function_2);
    StringConcatenation _builder_3 = new StringConcatenation();
    _builder_3.append("Relations-----");
    InputOutput.<String>println(_builder_3.toString());
    final BiConsumer<RelationDeclaration, Set<ParameterSubstitution>> _function_3 = (RelationDeclaration r, Set<ParameterSubstitution> s) -> {
      final Consumer<ParameterSubstitution> _function_4 = (ParameterSubstitution t) -> {
        StringConcatenation _builder_4 = new StringConcatenation();
        String _name = r.getName();
        _builder_4.append(_name);
        _builder_4.append(": (");
        _builder_4.append(t);
        _builder_4.append(")");
        InputOutput.<String>println(_builder_4.toString());
      };
      s.forEach(_function_4);
    };
    this.relation2Value.forEach(_function_3);
  }
  
  @Override
  public List<DefinedElement> getElements(final hu.bme.mit.inf.dslreasoner.logic.model.logiclanguage.Type type) {
    return this.getElementsDispatch(type);
  }
  
  private List<DefinedElement> _getElementsDispatch(final TypeDeclaration declaration) {
    return CollectionsUtil.<TypeDeclaration, List<DefinedElement>>lookup(declaration, this.interpretationOfUndefinedType);
  }
  
  private List<DefinedElement> _getElementsDispatch(final TypeDefinition declaration) {
    return declaration.getElements();
  }
  
  @Override
  public Object getInterpretation(final FunctionDeclaration function, final Object[] parameterSubstitution) {
    final ParameterSubstitution transformedParams = new ParameterSubstitution(parameterSubstitution);
    return CollectionsUtil.<ParameterSubstitution, Object>lookup(transformedParams, 
      CollectionsUtil.lookup(function, this.function2Value));
  }
  
  @Override
  public boolean getInterpretation(final RelationDeclaration relation, final Object[] parameterSubstitution) {
    Set<ParameterSubstitution> _lookup = CollectionsUtil.lookup(relation, this.relation2Value);
    ParameterSubstitution _parameterSubstitution = new ParameterSubstitution(parameterSubstitution);
    return _lookup.contains(_parameterSubstitution);
  }
  
  @Override
  public Object getInterpretation(final ConstantDeclaration constant) {
    return CollectionsUtil.<ConstantDeclaration, Object>lookup(constant, this.constant2Value);
  }
  
  private Object atomLabel2Term(final String label) {
    boolean _isNumber = this.isNumber(label);
    if (_isNumber) {
      return Integer.valueOf(Integer.parseInt(label));
    } else {
      boolean _equals = Objects.equal(label, this.logicBooleanTrue);
      if (_equals) {
        return Boolean.valueOf(true);
      } else {
        boolean _equals_1 = Objects.equal(label, this.logicBooleanFalse);
        if (_equals_1) {
          return Boolean.valueOf(false);
        } else {
          boolean _containsKey = this.alloyAtom2LogicElement.containsKey(label);
          if (_containsKey) {
            return CollectionsUtil.<String, DefinedElement>lookup(label, this.alloyAtom2LogicElement);
          } else {
            boolean _isString = this.isString(label);
            if (_isString) {
              return this.parseString(label);
            } else {
              StringConcatenation _builder = new StringConcatenation();
              _builder.append("Unknown atom label: \"");
              _builder.append(label);
              _builder.append("\"!");
              throw new IllegalArgumentException(_builder.toString());
            }
          }
        }
      }
    }
  }
  
  private boolean isNumber(final String s) {
    try {
      Integer.parseInt(s);
      return true;
    } catch (final Throwable _t) {
      if (_t instanceof NumberFormatException) {
        return false;
      } else {
        throw Exceptions.sneakyThrow(_t);
      }
    }
  }
  
  private boolean isString(final String label) {
    return (label.startsWith("\"") && label.endsWith("\""));
  }
  
  private String parseString(final String label) {
    int _length = label.length();
    int _minus = (_length - 1);
    return label.substring(1, _minus);
  }
  
  @Override
  public SortedSet<Integer> getAllIntegersInStructure() {
    return this.integerAtoms;
  }
  
  @Override
  public SortedSet<BigDecimal> getAllRealsInStructure() {
    return new TreeSet<BigDecimal>();
  }
  
  @Override
  public SortedSet<String> getAllStringsInStructure() {
    return this.stringAtoms;
  }
  
  private List<DefinedElement> getElementsDispatch(final hu.bme.mit.inf.dslreasoner.logic.model.logiclanguage.Type declaration) {
    if (declaration instanceof TypeDeclaration) {
      return _getElementsDispatch((TypeDeclaration)declaration);
    } else if (declaration instanceof TypeDefinition) {
      return _getElementsDispatch((TypeDefinition)declaration);
    } else {
      throw new IllegalArgumentException("Unhandled parameter types: " +
        Arrays.<Object>asList(declaration).toString());
    }
  }
}
