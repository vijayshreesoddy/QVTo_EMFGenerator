package hu.bme.mit.inf.dslreasoner.application.execution;

import hu.bme.mit.inf.dslreasoner.application.execution.ScriptConsole;
import org.eclipse.emf.common.util.URI;

@SuppressWarnings("all")
public class StandardOutputBasedScriptConsole extends ScriptConsole {
  public StandardOutputBasedScriptConsole(final boolean cleanFiles, final URI messageConsoleURI, final URI errorConsoleURI, final URI statisticsConsoleURI) {
    super(true, cleanFiles, messageConsoleURI, errorConsoleURI, statisticsConsoleURI);
    this.writeErrorMessagesDuringInitialisation();
  }
  
  public static final ScriptConsole.Factory FACTORY = new ScriptConsole.Factory() {
    @Override
    public ScriptConsole createScriptConsole(final boolean cleanFiles, final URI messageConsoleURI, final URI errorConsoleURI, final URI statisticsConsoleURI) {
      return new StandardOutputBasedScriptConsole(cleanFiles, messageConsoleURI, errorConsoleURI, statisticsConsoleURI);
    }
  };
}
