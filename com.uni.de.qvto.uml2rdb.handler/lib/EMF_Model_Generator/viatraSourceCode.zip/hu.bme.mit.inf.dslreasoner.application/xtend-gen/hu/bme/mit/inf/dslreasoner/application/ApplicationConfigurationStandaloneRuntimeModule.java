package hu.bme.mit.inf.dslreasoner.application;

import com.google.inject.Binder;
import com.google.inject.binder.ScopedBindingBuilder;
import com.google.inject.multibindings.Multibinder;
import hu.bme.mit.inf.dslreasoner.application.AbstractApplicationConfigurationRuntimeModule;
import hu.bme.mit.inf.dslreasoner.application.linking.ApplicationConfigurationLinkingService;
import hu.bme.mit.inf.dslreasoner.application.valueconverter.ApplicationConfigurationValueConverterService;
import org.apache.log4j.Logger;
import org.eclipse.viatra.query.patternlanguage.emf.GenmodelExtensionLoader;
import org.eclipse.viatra.query.patternlanguage.emf.IGenmodelMappingLoader;
import org.eclipse.viatra.query.patternlanguage.emf.scoping.CompoundMetamodelProviderService;
import org.eclipse.viatra.query.patternlanguage.emf.scoping.IMetamodelProvider;
import org.eclipse.viatra.query.patternlanguage.emf.scoping.IMetamodelProviderInstance;
import org.eclipse.viatra.query.patternlanguage.emf.scoping.MetamodelProviderService;
import org.eclipse.viatra.query.patternlanguage.emf.scoping.ResourceSetMetamodelProviderService;
import org.eclipse.xtext.conversion.IValueConverterService;
import org.eclipse.xtext.linking.ILinkingService;

/**
 * Use this class to register components to be used at runtime / without the Equinox extension registry.
 */
@SuppressWarnings("all")
public class ApplicationConfigurationStandaloneRuntimeModule extends AbstractApplicationConfigurationRuntimeModule {
  @Override
  public Class<? extends ILinkingService> bindILinkingService() {
    return ApplicationConfigurationLinkingService.class;
  }
  
  public void configureLoggerImplementation(final Binder binder) {
    binder.<Logger>bind(Logger.class).toInstance(Logger.getLogger(ApplicationConfigurationStandaloneRuntimeModule.class));
  }
  
  public Class<? extends IMetamodelProvider> bindIMetamodelProvider() {
    return CompoundMetamodelProviderService.class;
  }
  
  public ScopedBindingBuilder configureMetamodelProviderInstance(final Binder binder) {
    ScopedBindingBuilder _xblockexpression = null;
    {
      final Multibinder<IMetamodelProviderInstance> metamodelProviderBinder = Multibinder.<IMetamodelProviderInstance>newSetBinder(binder, IMetamodelProviderInstance.class);
      metamodelProviderBinder.addBinding().to(MetamodelProviderService.class);
      _xblockexpression = metamodelProviderBinder.addBinding().to(ResourceSetMetamodelProviderService.class);
    }
    return _xblockexpression;
  }
  
  @Override
  public Class<? extends IValueConverterService> bindIValueConverterService() {
    return ApplicationConfigurationValueConverterService.class;
  }
  
  public Class<? extends IGenmodelMappingLoader> bindIGenmodelMappingLoader() {
    return GenmodelExtensionLoader.class;
  }
}
