package hu.bme.mit.inf.dlsreasoner.alloy.reasoner.builder;

import edu.mit.csail.sdg.alloy4compiler.ast.ExprVar;
import edu.mit.csail.sdg.alloy4compiler.ast.Sig;
import edu.mit.csail.sdg.alloy4compiler.translator.A4Solution;
import hu.bme.mit.inf.dlsreasoner.alloy.reasoner.builder.Logic2AlloyLanguageMapperTrace;
import hu.bme.mit.inf.dslreasoner.logic.model.logiclanguage.DefinedElement;
import hu.bme.mit.inf.dslreasoner.logic.model.logiclanguage.TypeDeclaration;
import java.util.List;
import java.util.Map;

@SuppressWarnings("all")
public interface AlloyModelInterpretation_TypeInterpretation {
  void resolveUnknownAtoms(final Iterable<ExprVar> objectAtoms, final A4Solution solution, final Logic2AlloyLanguageMapperTrace forwardTrace, final Map<String, Sig> name2AlloySig, final Map<String, Sig.Field> name2AlloyField, final Map<String, DefinedElement> expression2DefinedElement, final Map<TypeDeclaration, List<DefinedElement>> interpretationOfUndefinedType);
}
