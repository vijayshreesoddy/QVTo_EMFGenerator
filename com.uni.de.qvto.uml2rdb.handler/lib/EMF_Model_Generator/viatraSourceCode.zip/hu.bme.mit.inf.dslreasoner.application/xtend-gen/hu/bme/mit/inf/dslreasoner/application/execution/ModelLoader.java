package hu.bme.mit.inf.dslreasoner.application.execution;

import hu.bme.mit.inf.dslreasoner.application.applicationConfiguration.PartialModelEntry;
import hu.bme.mit.inf.dslreasoner.application.applicationConfiguration.PartialModelSpecification;
import hu.bme.mit.inf.dslreasoner.application.execution.ScriptExecutor;
import java.util.List;
import org.eclipse.emf.common.util.EList;
import org.eclipse.emf.common.util.URI;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.resource.Resource;
import org.eclipse.emf.ecore.resource.ResourceSet;
import org.eclipse.xtend2.lib.StringConcatenation;
import org.eclipse.xtext.xbase.lib.Exceptions;
import org.eclipse.xtext.xbase.lib.IterableExtensions;
import org.eclipse.xtext.xbase.lib.IteratorExtensions;

@SuppressWarnings("all")
public class ModelLoader {
  public List<EObject> loadModel(final PartialModelSpecification specification, final ScriptExecutor scriptExecutor) {
    Object _xblockexpression = null;
    {
      final EList<PartialModelEntry> entries = specification.getEntry();
      Object _xifexpression = null;
      int _size = entries.size();
      boolean _equals = (_size == 1);
      if (_equals) {
        Object _xblockexpression_1 = null;
        {
          URI uri = null;
          try {
            uri = URI.createURI(
              scriptExecutor.getFileSpecification(IterableExtensions.<PartialModelEntry>head(specification.getEntry()).getPath()).getPath());
          } catch (final Throwable _t) {
            if (_t instanceof IllegalArgumentException) {
              return null;
            } else {
              throw Exceptions.sneakyThrow(_t);
            }
          }
          final ResourceSet resourceSet = specification.eResource().getResourceSet();
          final Resource resource = resourceSet.getResource(uri, true);
          Object _xifexpression_1 = null;
          if ((resource == null)) {
            _xifexpression_1 = null;
          } else {
            return IteratorExtensions.<EObject>toList(resource.getAllContents());
          }
          _xblockexpression_1 = _xifexpression_1;
        }
        _xifexpression = _xblockexpression_1;
      } else {
        StringConcatenation _builder = new StringConcatenation();
        _builder.append("Currently single partial models are supported");
        throw new UnsupportedOperationException(_builder.toString());
      }
      _xblockexpression = _xifexpression;
    }
    return ((List<EObject>)_xblockexpression);
  }
}
