package hu.bme.mit.inf.dlsreasoner.alloy.reasoner.builder;

import hu.bme.mit.inf.dlsreasoner.alloy.reasoner.AlloyBackendSolver;
import java.util.Arrays;
import org.eclipse.xtend.lib.annotations.Data;
import org.eclipse.xtext.xbase.lib.Pure;
import org.eclipse.xtext.xbase.lib.util.ToStringBuilder;

@Data
@SuppressWarnings("all")
public class SolverConfiguration {
  private final AlloyBackendSolver backedSolver;
  
  private final String path;
  
  private final String[] options;
  
  public SolverConfiguration(final AlloyBackendSolver backedSolver, final String path, final String[] options) {
    super();
    this.backedSolver = backedSolver;
    this.path = path;
    this.options = options;
  }
  
  @Override
  @Pure
  public int hashCode() {
    final int prime = 31;
    int result = 1;
    result = prime * result + ((this.backedSolver== null) ? 0 : this.backedSolver.hashCode());
    result = prime * result + ((this.path== null) ? 0 : this.path.hashCode());
    return prime * result + ((this.options== null) ? 0 : Arrays.deepHashCode(this.options));
  }
  
  @Override
  @Pure
  public boolean equals(final Object obj) {
    if (this == obj)
      return true;
    if (obj == null)
      return false;
    if (getClass() != obj.getClass())
      return false;
    SolverConfiguration other = (SolverConfiguration) obj;
    if (this.backedSolver == null) {
      if (other.backedSolver != null)
        return false;
    } else if (!this.backedSolver.equals(other.backedSolver))
      return false;
    if (this.path == null) {
      if (other.path != null)
        return false;
    } else if (!this.path.equals(other.path))
      return false;
    if (this.options == null) {
      if (other.options != null)
        return false;
    } else if (!Arrays.deepEquals(this.options, other.options))
      return false;
    return true;
  }
  
  @Override
  @Pure
  public String toString() {
    ToStringBuilder b = new ToStringBuilder(this);
    b.add("backedSolver", this.backedSolver);
    b.add("path", this.path);
    b.add("options", this.options);
    return b.toString();
  }
  
  @Pure
  public AlloyBackendSolver getBackedSolver() {
    return this.backedSolver;
  }
  
  @Pure
  public String getPath() {
    return this.path;
  }
  
  @Pure
  public String[] getOptions() {
    return this.options;
  }
}
