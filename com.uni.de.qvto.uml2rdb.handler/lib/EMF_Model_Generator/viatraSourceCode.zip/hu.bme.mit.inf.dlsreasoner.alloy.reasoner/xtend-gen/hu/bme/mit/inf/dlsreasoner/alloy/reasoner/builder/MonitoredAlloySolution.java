package hu.bme.mit.inf.dlsreasoner.alloy.reasoner.builder;

import edu.mit.csail.sdg.alloy4compiler.translator.A4Solution;
import java.util.List;
import org.eclipse.xtend.lib.annotations.Data;
import org.eclipse.xtext.xbase.lib.Pair;
import org.eclipse.xtext.xbase.lib.Pure;
import org.eclipse.xtext.xbase.lib.util.ToStringBuilder;

@Data
@SuppressWarnings("all")
public class MonitoredAlloySolution {
  private final List<String> warnings;
  
  private final List<String> debugs;
  
  private final long kodkodTime;
  
  private final List<Pair<A4Solution, Long>> aswers;
  
  private final boolean finishedBeforeTimeout;
  
  public MonitoredAlloySolution(final List<String> warnings, final List<String> debugs, final long kodkodTime, final List<Pair<A4Solution, Long>> aswers, final boolean finishedBeforeTimeout) {
    super();
    this.warnings = warnings;
    this.debugs = debugs;
    this.kodkodTime = kodkodTime;
    this.aswers = aswers;
    this.finishedBeforeTimeout = finishedBeforeTimeout;
  }
  
  @Override
  @Pure
  public int hashCode() {
    final int prime = 31;
    int result = 1;
    result = prime * result + ((this.warnings== null) ? 0 : this.warnings.hashCode());
    result = prime * result + ((this.debugs== null) ? 0 : this.debugs.hashCode());
    result = prime * result + (int) (this.kodkodTime ^ (this.kodkodTime >>> 32));
    result = prime * result + ((this.aswers== null) ? 0 : this.aswers.hashCode());
    return prime * result + (this.finishedBeforeTimeout ? 1231 : 1237);
  }
  
  @Override
  @Pure
  public boolean equals(final Object obj) {
    if (this == obj)
      return true;
    if (obj == null)
      return false;
    if (getClass() != obj.getClass())
      return false;
    MonitoredAlloySolution other = (MonitoredAlloySolution) obj;
    if (this.warnings == null) {
      if (other.warnings != null)
        return false;
    } else if (!this.warnings.equals(other.warnings))
      return false;
    if (this.debugs == null) {
      if (other.debugs != null)
        return false;
    } else if (!this.debugs.equals(other.debugs))
      return false;
    if (other.kodkodTime != this.kodkodTime)
      return false;
    if (this.aswers == null) {
      if (other.aswers != null)
        return false;
    } else if (!this.aswers.equals(other.aswers))
      return false;
    if (other.finishedBeforeTimeout != this.finishedBeforeTimeout)
      return false;
    return true;
  }
  
  @Override
  @Pure
  public String toString() {
    ToStringBuilder b = new ToStringBuilder(this);
    b.add("warnings", this.warnings);
    b.add("debugs", this.debugs);
    b.add("kodkodTime", this.kodkodTime);
    b.add("aswers", this.aswers);
    b.add("finishedBeforeTimeout", this.finishedBeforeTimeout);
    return b.toString();
  }
  
  @Pure
  public List<String> getWarnings() {
    return this.warnings;
  }
  
  @Pure
  public List<String> getDebugs() {
    return this.debugs;
  }
  
  @Pure
  public long getKodkodTime() {
    return this.kodkodTime;
  }
  
  @Pure
  public List<Pair<A4Solution, Long>> getAswers() {
    return this.aswers;
  }
  
  @Pure
  public boolean isFinishedBeforeTimeout() {
    return this.finishedBeforeTimeout;
  }
}
