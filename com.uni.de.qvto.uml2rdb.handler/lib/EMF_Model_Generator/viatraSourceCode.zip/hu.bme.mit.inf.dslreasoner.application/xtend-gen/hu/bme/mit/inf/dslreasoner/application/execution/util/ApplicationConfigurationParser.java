package hu.bme.mit.inf.dslreasoner.application.execution.util;

import hu.bme.mit.inf.dslreasoner.application.applicationConfiguration.ConfigurationScript;
import org.eclipse.emf.common.util.URI;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.resource.Resource;
import org.eclipse.emf.ecore.resource.impl.ResourceSetImpl;
import org.eclipse.xtend2.lib.StringConcatenation;
import org.eclipse.xtext.xbase.lib.IterableExtensions;

@SuppressWarnings("all")
public class ApplicationConfigurationParser {
  public ConfigurationScript parse(final URI uri) {
    final ResourceSetImpl rs = new ResourceSetImpl();
    final Resource res = rs.getResource(uri, true);
    final EObject content = IterableExtensions.<EObject>head(res.getContents());
    if ((content instanceof ConfigurationScript)) {
      return ((ConfigurationScript)content);
    } else {
      StringConcatenation _builder = new StringConcatenation();
      _builder.append("Content is not an ConfigurationScript! (got: ");
      String _simpleName = content.getClass().getSimpleName();
      _builder.append(_simpleName);
      _builder.append(")");
      throw new IllegalArgumentException(_builder.toString());
    }
  }
}
