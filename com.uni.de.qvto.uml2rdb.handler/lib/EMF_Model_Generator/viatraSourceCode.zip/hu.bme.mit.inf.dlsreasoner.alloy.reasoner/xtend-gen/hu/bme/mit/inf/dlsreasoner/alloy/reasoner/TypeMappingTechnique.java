package hu.bme.mit.inf.dlsreasoner.alloy.reasoner;

@SuppressWarnings("all")
public enum TypeMappingTechnique {
  FilteredTypes,
  
  InheritanceAndHorizontal;
}
