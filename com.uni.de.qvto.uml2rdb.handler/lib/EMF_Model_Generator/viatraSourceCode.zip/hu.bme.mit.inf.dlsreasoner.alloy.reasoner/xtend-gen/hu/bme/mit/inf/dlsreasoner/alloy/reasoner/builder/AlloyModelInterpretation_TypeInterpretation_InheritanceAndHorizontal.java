package hu.bme.mit.inf.dlsreasoner.alloy.reasoner.builder;

import edu.mit.csail.sdg.alloy4compiler.ast.ExprVar;
import edu.mit.csail.sdg.alloy4compiler.ast.Sig;
import edu.mit.csail.sdg.alloy4compiler.translator.A4Solution;
import edu.mit.csail.sdg.alloy4compiler.translator.A4Tuple;
import edu.mit.csail.sdg.alloy4compiler.translator.A4TupleSet;
import hu.bme.mit.inf.dlsreasoner.alloy.reasoner.builder.AlloyModelInterpretation_TypeInterpretation;
import hu.bme.mit.inf.dlsreasoner.alloy.reasoner.builder.Logic2AlloyLanguageMapperTrace;
import hu.bme.mit.inf.dlsreasoner.alloy.reasoner.builder.Logic2AlloyLanguageMapper_TypeMapperTrace_InheritanceAndHorizontal;
import hu.bme.mit.inf.dslreasoner.alloyLanguage.ALSSignatureDeclaration;
import hu.bme.mit.inf.dslreasoner.logic.model.logiclanguage.DefinedElement;
import hu.bme.mit.inf.dslreasoner.logic.model.logiclanguage.LogiclanguageFactory;
import hu.bme.mit.inf.dslreasoner.logic.model.logiclanguage.Type;
import hu.bme.mit.inf.dslreasoner.logic.model.logiclanguage.TypeDeclaration;
import hu.bme.mit.inf.dslreasoner.util.CollectionsUtil;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import org.eclipse.xtend2.lib.StringConcatenation;
import org.eclipse.xtext.xbase.lib.Extension;
import org.eclipse.xtext.xbase.lib.IterableExtensions;
import org.eclipse.xtext.xbase.lib.ObjectExtensions;
import org.eclipse.xtext.xbase.lib.Procedures.Procedure1;

@SuppressWarnings("all")
public class AlloyModelInterpretation_TypeInterpretation_InheritanceAndHorizontal implements AlloyModelInterpretation_TypeInterpretation {
  @Extension
  protected final LogiclanguageFactory factory = LogiclanguageFactory.eINSTANCE;
  
  @Override
  public void resolveUnknownAtoms(final Iterable<ExprVar> objectAtoms, final A4Solution solution, final Logic2AlloyLanguageMapperTrace forwardTrace, final Map<String, Sig> name2AlloySig, final Map<String, Sig.Field> name2AlloyField, final Map<String, DefinedElement> expression2DefinedElement, final Map<TypeDeclaration, List<DefinedElement>> interpretationOfUndefinedType) {
    final Logic2AlloyLanguageMapper_TypeMapperTrace_InheritanceAndHorizontal typeTrace = ((Logic2AlloyLanguageMapper_TypeMapperTrace_InheritanceAndHorizontal) forwardTrace.typeMapperTrace);
    Set<Map.Entry<DefinedElement, ALSSignatureDeclaration>> _entrySet = typeTrace.definedElement2Declaration.entrySet();
    for (final Map.Entry<DefinedElement, ALSSignatureDeclaration> definedElementMappingEntry : _entrySet) {
      {
        final String name = definedElementMappingEntry.getValue().getName();
        StringConcatenation _builder = new StringConcatenation();
        _builder.append("this/");
        _builder.append(name);
        final Sig matchingSig = CollectionsUtil.<String, Sig>lookup(_builder.toString(), name2AlloySig);
        final A4TupleSet elementsOfSingletonSignature = solution.eval(matchingSig);
        int _size = elementsOfSingletonSignature.size();
        boolean _notEquals = (_size != 1);
        if (_notEquals) {
          StringConcatenation _builder_1 = new StringConcatenation();
          _builder_1.append("Defined element is unambigous: \"");
          _builder_1.append(name);
          _builder_1.append("\", possible values: ");
          _builder_1.append(elementsOfSingletonSignature);
          _builder_1.append("!");
          throw new IllegalArgumentException(_builder_1.toString());
        } else {
          final String expressionOfDefinedElement = IterableExtensions.<A4Tuple>head(elementsOfSingletonSignature).atom(0);
          expression2DefinedElement.put(expressionOfDefinedElement, definedElementMappingEntry.getKey());
        }
      }
    }
    Set<Map.Entry<Type, ALSSignatureDeclaration>> _entrySet_1 = typeTrace.type2ALSType.entrySet();
    for (final Map.Entry<Type, ALSSignatureDeclaration> type2SingatureEntry : _entrySet_1) {
      {
        final Type type = type2SingatureEntry.getKey();
        if ((type instanceof TypeDeclaration)) {
          final String name = type2SingatureEntry.getValue().getName();
          StringConcatenation _builder = new StringConcatenation();
          _builder.append("this/");
          _builder.append(name);
          final Sig matchingSig = CollectionsUtil.<String, Sig>lookup(_builder.toString(), name2AlloySig);
          final A4TupleSet elementsOfSignature = solution.eval(matchingSig);
          int _size = elementsOfSignature.size();
          final ArrayList<DefinedElement> elementList = new ArrayList<DefinedElement>(_size);
          int newVariableIndex = 1;
          for (final A4Tuple elementOfSignature : elementsOfSignature) {
            {
              final String expressionOfDefinedElement = elementOfSignature.atom(0);
              boolean _containsKey = expression2DefinedElement.containsKey(expressionOfDefinedElement);
              if (_containsKey) {
                DefinedElement _lookup = CollectionsUtil.<String, DefinedElement>lookup(expressionOfDefinedElement, expression2DefinedElement);
                elementList.add(_lookup);
              } else {
                StringConcatenation _builder_1 = new StringConcatenation();
                _builder_1.append("newObject ");
                String _string = Integer.valueOf(newVariableIndex).toString();
                _builder_1.append(_string);
                final String newElementName = _builder_1.toString();
                DefinedElement _createDefinedElement = this.factory.createDefinedElement();
                final Procedure1<DefinedElement> _function = (DefinedElement it) -> {
                  it.setName(newElementName);
                };
                final DefinedElement newRepresentation = ObjectExtensions.<DefinedElement>operator_doubleArrow(_createDefinedElement, _function);
                elementList.add(newRepresentation);
                expression2DefinedElement.put(expressionOfDefinedElement, newRepresentation);
              }
            }
          }
          interpretationOfUndefinedType.put(((TypeDeclaration)type), elementList);
        }
      }
    }
  }
}
