package hu.bme.mit.inf.dlsreasoner.alloy.reasoner.builder;

import com.google.common.collect.Iterables;
import hu.bme.mit.inf.dlsreasoner.alloy.reasoner.builder.AlloyModelInterpretation_TypeInterpretation;
import hu.bme.mit.inf.dlsreasoner.alloy.reasoner.builder.AlloyModelInterpretation_TypeInterpretation_FilteredTypes;
import hu.bme.mit.inf.dlsreasoner.alloy.reasoner.builder.Logic2AlloyLanguageMapper;
import hu.bme.mit.inf.dlsreasoner.alloy.reasoner.builder.Logic2AlloyLanguageMapperTrace;
import hu.bme.mit.inf.dlsreasoner.alloy.reasoner.builder.Logic2AlloyLanguageMapper_Support;
import hu.bme.mit.inf.dlsreasoner.alloy.reasoner.builder.Logic2AlloyLanguageMapper_TypeMapper;
import hu.bme.mit.inf.dlsreasoner.alloy.reasoner.builder.Logic2AlloyLanguageMapper_TypeMapperTrace;
import hu.bme.mit.inf.dlsreasoner.alloy.reasoner.builder.Logic2AlloyLanguageMapper_TypeMapperTrace_FilteredTypes;
import hu.bme.mit.inf.dlsreasoner.alloy.reasoner.queries.LowestCommonSupertypeOfAllOccuranceOfElement;
import hu.bme.mit.inf.dlsreasoner.alloy.reasoner.queries.TopmostCommonSubtypes;
import hu.bme.mit.inf.dlsreasoner.alloy.reasoner.queries.TypeQueries;
import hu.bme.mit.inf.dslreasoner.alloyLanguage.ALSEquals;
import hu.bme.mit.inf.dslreasoner.alloyLanguage.ALSFactDeclaration;
import hu.bme.mit.inf.dslreasoner.alloyLanguage.ALSIntersection;
import hu.bme.mit.inf.dslreasoner.alloyLanguage.ALSMultiplicity;
import hu.bme.mit.inf.dslreasoner.alloyLanguage.ALSNotEquals;
import hu.bme.mit.inf.dslreasoner.alloyLanguage.ALSReference;
import hu.bme.mit.inf.dslreasoner.alloyLanguage.ALSSignatureBody;
import hu.bme.mit.inf.dslreasoner.alloyLanguage.ALSSignatureDeclaration;
import hu.bme.mit.inf.dslreasoner.alloyLanguage.ALSSubset;
import hu.bme.mit.inf.dslreasoner.alloyLanguage.ALSTerm;
import hu.bme.mit.inf.dslreasoner.alloyLanguage.AlloyLanguageFactory;
import hu.bme.mit.inf.dslreasoner.logic.model.logiclanguage.DefinedElement;
import hu.bme.mit.inf.dslreasoner.logic.model.logiclanguage.Type;
import hu.bme.mit.inf.dslreasoner.logic.model.logiclanguage.TypeDefinition;
import hu.bme.mit.inf.dslreasoner.logic.model.logicproblem.LogicproblemPackage;
import hu.bme.mit.inf.dslreasoner.util.CollectionsUtil;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import org.eclipse.emf.common.util.EList;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.xtend2.lib.StringConcatenation;
import org.eclipse.xtext.xbase.lib.CollectionLiterals;
import org.eclipse.xtext.xbase.lib.ExclusiveRange;
import org.eclipse.xtext.xbase.lib.Extension;
import org.eclipse.xtext.xbase.lib.Functions.Function1;
import org.eclipse.xtext.xbase.lib.IterableExtensions;
import org.eclipse.xtext.xbase.lib.ListExtensions;
import org.eclipse.xtext.xbase.lib.ObjectExtensions;
import org.eclipse.xtext.xbase.lib.Procedures.Procedure1;

/**
 * Each object is an element of an Object set, and types are subsets of the objects.
 */
@SuppressWarnings("all")
public class Logic2AlloyLanguageMapper_TypeMapper_FilteredTypes implements Logic2AlloyLanguageMapper_TypeMapper {
  private final Logic2AlloyLanguageMapper_Support support = new Logic2AlloyLanguageMapper_Support();
  
  @Extension
  private final AlloyLanguageFactory factory = AlloyLanguageFactory.eINSTANCE;
  
  public Logic2AlloyLanguageMapper_TypeMapper_FilteredTypes() {
    LogicproblemPackage.eINSTANCE.getClass();
  }
  
  @Override
  public void transformTypes(final Collection<Type> types, final Collection<DefinedElement> elements, final Logic2AlloyLanguageMapper mapper, final Logic2AlloyLanguageMapperTrace trace) {
    final Logic2AlloyLanguageMapper_TypeMapperTrace_FilteredTypes typeTrace = new Logic2AlloyLanguageMapper_TypeMapperTrace_FilteredTypes();
    trace.typeMapperTrace = typeTrace;
    ALSSignatureDeclaration _createALSSignatureDeclaration = this.factory.createALSSignatureDeclaration();
    final Procedure1<ALSSignatureDeclaration> _function = (ALSSignatureDeclaration it) -> {
      it.setName(this.support.toID(Collections.<String>unmodifiableList(CollectionLiterals.<String>newArrayList("util", "Object"))));
    };
    final ALSSignatureDeclaration objectSig = ObjectExtensions.<ALSSignatureDeclaration>operator_doubleArrow(_createALSSignatureDeclaration, _function);
    ALSSignatureBody _createALSSignatureBody = this.factory.createALSSignatureBody();
    final Procedure1<ALSSignatureBody> _function_1 = (ALSSignatureBody it) -> {
      EList<ALSSignatureDeclaration> _declarations = it.getDeclarations();
      _declarations.add(objectSig);
      it.setAbstract(true);
    };
    final ALSSignatureBody objectBody = ObjectExtensions.<ALSSignatureBody>operator_doubleArrow(_createALSSignatureBody, _function_1);
    typeTrace.objectSupperClass = objectSig;
    EList<ALSSignatureBody> _signatureBodies = trace.specification.getSignatureBodies();
    _signatureBodies.add(objectBody);
    for (final Type type : types) {
      {
        ALSSignatureDeclaration _createALSSignatureDeclaration_1 = this.factory.createALSSignatureDeclaration();
        final Procedure1<ALSSignatureDeclaration> _function_2 = (ALSSignatureDeclaration it) -> {
          it.setName(this.support.toIDMultiple("type", type.getName()));
        };
        final ALSSignatureDeclaration sig = ObjectExtensions.<ALSSignatureDeclaration>operator_doubleArrow(_createALSSignatureDeclaration_1, _function_2);
        ALSSignatureBody _createALSSignatureBody_1 = this.factory.createALSSignatureBody();
        final Procedure1<ALSSignatureBody> _function_3 = (ALSSignatureBody it) -> {
          EList<ALSSignatureDeclaration> _declarations = it.getDeclarations();
          _declarations.add(sig);
        };
        final ALSSignatureBody body = ObjectExtensions.<ALSSignatureBody>operator_doubleArrow(_createALSSignatureBody_1, _function_3);
        EList<ALSSignatureBody> _signatureBodies_1 = trace.specification.getSignatureBodies();
        _signatureBodies_1.add(body);
        typeTrace.type2ALSType.put(type, sig);
      }
    }
    final LowestCommonSupertypeOfAllOccuranceOfElement.Matcher elementMatcher = TypeQueries.instance().getLowestCommonSupertypeOfAllOccuranceOfElement(trace.incqueryEngine);
    final HashMap<ALSSignatureDeclaration, List<DefinedElement>> topmostType2Elements = new HashMap<ALSSignatureDeclaration, List<DefinedElement>>();
    for (final DefinedElement element : elements) {
      {
        final Set<Type> topmostTypes = elementMatcher.getAllValuesOftype(element);
        ALSSignatureDeclaration selectedTopmostType = null;
        boolean _isEmpty = topmostTypes.isEmpty();
        if (_isEmpty) {
          selectedTopmostType = objectSig;
        } else {
          selectedTopmostType = CollectionsUtil.<Type, ALSSignatureDeclaration>lookup(IterableExtensions.<Type>head(topmostTypes), typeTrace.type2ALSType);
        }
        CollectionsUtil.<ALSSignatureDeclaration, DefinedElement>putOrAddToList(topmostType2Elements, selectedTopmostType, element);
      }
    }
    Set<Map.Entry<ALSSignatureDeclaration, List<DefinedElement>>> _entrySet = topmostType2Elements.entrySet();
    for (final Map.Entry<ALSSignatureDeclaration, List<DefinedElement>> topmostEntry : _entrySet) {
      {
        List<DefinedElement> _value = topmostEntry.getValue();
        for (final DefinedElement element_1 : _value) {
          {
            ALSSignatureDeclaration _createALSSignatureDeclaration_1 = this.factory.createALSSignatureDeclaration();
            final Procedure1<ALSSignatureDeclaration> _function_2 = (ALSSignatureDeclaration it) -> {
              it.setName(this.support.toIDMultiple("element", element_1.getName()));
            };
            final ALSSignatureDeclaration signature = ObjectExtensions.<ALSSignatureDeclaration>operator_doubleArrow(_createALSSignatureDeclaration_1, _function_2);
            typeTrace.definedElement2Declaration.put(element_1, signature);
          }
        }
        ALSSignatureBody _createALSSignatureBody_1 = this.factory.createALSSignatureBody();
        final Procedure1<ALSSignatureBody> _function_2 = (ALSSignatureBody it) -> {
          it.setMultiplicity(ALSMultiplicity.ONE);
          EList<ALSSignatureDeclaration> _declarations = it.getDeclarations();
          final Function1<DefinedElement, ALSSignatureDeclaration> _function_3 = (DefinedElement it_1) -> {
            return CollectionsUtil.<DefinedElement, ALSSignatureDeclaration>lookup(it_1, typeTrace.definedElement2Declaration);
          };
          List<ALSSignatureDeclaration> _map = ListExtensions.<DefinedElement, ALSSignatureDeclaration>map(topmostEntry.getValue(), _function_3);
          Iterables.<ALSSignatureDeclaration>addAll(_declarations, _map);
        };
        final ALSSignatureBody body = ObjectExtensions.<ALSSignatureBody>operator_doubleArrow(_createALSSignatureBody_1, _function_2);
        final ALSSignatureDeclaration containerLogicType = topmostEntry.getKey();
        EList<ALSSignatureDeclaration> _superset = body.getSuperset();
        _superset.add(containerLogicType);
        EList<ALSSignatureBody> _signatureBodies_1 = trace.specification.getSignatureBodies();
        _signatureBodies_1.add(body);
      }
    }
    Iterable<TypeDefinition> _filter = Iterables.<TypeDefinition>filter(types, TypeDefinition.class);
    for (final TypeDefinition definedType : _filter) {
      EList<ALSFactDeclaration> _factDeclarations = trace.specification.getFactDeclarations();
      ALSFactDeclaration _createALSFactDeclaration = this.factory.createALSFactDeclaration();
      final Procedure1<ALSFactDeclaration> _function_2 = (ALSFactDeclaration it) -> {
        it.setName(this.support.toIDMultiple("typedefinition", definedType.getName()));
        ALSEquals _createALSEquals = this.factory.createALSEquals();
        final Procedure1<ALSEquals> _function_3 = (ALSEquals it_1) -> {
          ALSReference _createALSReference = this.factory.createALSReference();
          final Procedure1<ALSReference> _function_4 = (ALSReference it_2) -> {
            it_2.setReferred(CollectionsUtil.<TypeDefinition, ALSSignatureDeclaration>lookup(definedType, typeTrace.type2ALSType));
          };
          ALSReference _doubleArrow = ObjectExtensions.<ALSReference>operator_doubleArrow(_createALSReference, _function_4);
          it_1.setLeftOperand(_doubleArrow);
          final Function1<DefinedElement, ALSReference> _function_5 = (DefinedElement e) -> {
            ALSReference _createALSReference_1 = this.factory.createALSReference();
            final Procedure1<ALSReference> _function_6 = (ALSReference it_2) -> {
              it_2.setReferred(CollectionsUtil.<DefinedElement, ALSSignatureDeclaration>lookup(e, typeTrace.definedElement2Declaration));
            };
            return ObjectExtensions.<ALSReference>operator_doubleArrow(_createALSReference_1, _function_6);
          };
          it_1.setRightOperand(this.support.unfoldPlus(
            ListExtensions.<DefinedElement, ALSReference>map(definedType.getElements(), _function_5)));
        };
        ALSEquals _doubleArrow = ObjectExtensions.<ALSEquals>operator_doubleArrow(_createALSEquals, _function_3);
        it.setTerm(_doubleArrow);
      };
      ALSFactDeclaration _doubleArrow = ObjectExtensions.<ALSFactDeclaration>operator_doubleArrow(_createALSFactDeclaration, _function_2);
      _factDeclarations.add(_doubleArrow);
    }
    Iterable<TypeDefinition> _filter_1 = Iterables.<TypeDefinition>filter(types, TypeDefinition.class);
    for (final TypeDefinition definedType_1 : _filter_1) {
      {
        final Function1<Type, Iterable<Type>> _function_3 = (Type it) -> {
          return it.getSubtypes();
        };
        final Function1<TypeDefinition, Collection<DefinedElement>> _function_4 = (TypeDefinition it) -> {
          return elements;
        };
        final List<DefinedElement> allElementsIncludingSubtypes = IterableExtensions.<DefinedElement>toList(IterableExtensions.<DefinedElement>toSet(Iterables.<DefinedElement>concat(IterableExtensions.<TypeDefinition, Collection<DefinedElement>>map(Iterables.<TypeDefinition>filter(CollectionsUtil.<Type>transitiveClosureStar(definedType_1, _function_3), TypeDefinition.class), _function_4))));
        int _size = allElementsIncludingSubtypes.size();
        boolean _greaterEqualsThan = (_size >= 2);
        if (_greaterEqualsThan) {
          EList<ALSFactDeclaration> _factDeclarations_1 = trace.specification.getFactDeclarations();
          ALSFactDeclaration _createALSFactDeclaration_1 = this.factory.createALSFactDeclaration();
          final Procedure1<ALSFactDeclaration> _function_5 = (ALSFactDeclaration it) -> {
            it.setName(this.support.toIDMultiple("typeElementsUnique", definedType_1.getName()));
            it.setTerm(this.unfoldDistinctElements(allElementsIncludingSubtypes, trace));
          };
          ALSFactDeclaration _doubleArrow_1 = ObjectExtensions.<ALSFactDeclaration>operator_doubleArrow(_createALSFactDeclaration_1, _function_5);
          _factDeclarations_1.add(_doubleArrow_1);
        }
      }
    }
    for (final Type type_1 : types) {
      {
        EObject _eContainer = CollectionsUtil.<Type, ALSSignatureDeclaration>lookup(type_1, typeTrace.type2ALSType).eContainer();
        final ALSSignatureBody sigBody = ((ALSSignatureBody) _eContainer);
        boolean _isEmpty = type_1.getSupertypes().isEmpty();
        if (_isEmpty) {
          EList<ALSSignatureDeclaration> _superset = sigBody.getSuperset();
          _superset.add(typeTrace.objectSupperClass);
        } else {
          EList<ALSSignatureDeclaration> _superset_1 = sigBody.getSuperset();
          final Function1<Type, ALSSignatureDeclaration> _function_3 = (Type it) -> {
            return CollectionsUtil.<Type, ALSSignatureDeclaration>lookup(it, typeTrace.type2ALSType);
          };
          List<ALSSignatureDeclaration> _map = ListExtensions.<Type, ALSSignatureDeclaration>map(type_1.getSupertypes(), _function_3);
          Iterables.<ALSSignatureDeclaration>addAll(_superset_1, _map);
        }
      }
    }
    final Function1<Type, Boolean> _function_3 = (Type it) -> {
      int _size = it.getSupertypes().size();
      return Boolean.valueOf((_size >= 2));
    };
    Iterable<Type> _filter_2 = IterableExtensions.<Type>filter(types, _function_3);
    for (final Type type_2 : _filter_2) {
      EList<ALSFactDeclaration> _factDeclarations_1 = trace.specification.getFactDeclarations();
      ALSFactDeclaration _createALSFactDeclaration_1 = this.factory.createALSFactDeclaration();
      final Procedure1<ALSFactDeclaration> _function_4 = (ALSFactDeclaration it) -> {
        it.setName(this.support.toIDMultiple("supertypeIsInIntersection", type_2.getName()));
        ALSSubset _createALSSubset = this.factory.createALSSubset();
        final Procedure1<ALSSubset> _function_5 = (ALSSubset it_1) -> {
          ALSReference _createALSReference = this.factory.createALSReference();
          final Procedure1<ALSReference> _function_6 = (ALSReference it_2) -> {
            it_2.setReferred(CollectionsUtil.<Type, ALSSignatureDeclaration>lookup(type_2, typeTrace.type2ALSType));
          };
          ALSReference _doubleArrow_1 = ObjectExtensions.<ALSReference>operator_doubleArrow(_createALSReference, _function_6);
          it_1.setLeftOperand(_doubleArrow_1);
          final Function1<Type, ALSReference> _function_7 = (Type e) -> {
            ALSReference _createALSReference_1 = this.factory.createALSReference();
            final Procedure1<ALSReference> _function_8 = (ALSReference it_2) -> {
              it_2.setReferred(CollectionsUtil.<Type, ALSSignatureDeclaration>lookup(e, typeTrace.type2ALSType));
            };
            return ObjectExtensions.<ALSReference>operator_doubleArrow(_createALSReference_1, _function_8);
          };
          it_1.setRightOperand(this.support.unfoldIntersection(
            ListExtensions.<Type, ALSReference>map(type_2.getSupertypes(), _function_7)));
        };
        ALSSubset _doubleArrow_1 = ObjectExtensions.<ALSSubset>operator_doubleArrow(_createALSSubset, _function_5);
        it.setTerm(_doubleArrow_1);
      };
      ALSFactDeclaration _doubleArrow_1 = ObjectExtensions.<ALSFactDeclaration>operator_doubleArrow(_createALSFactDeclaration_1, _function_4);
      _factDeclarations_1.add(_doubleArrow_1);
    }
    final Function1<Type, Boolean> _function_5 = (Type it) -> {
      return Boolean.valueOf(it.isIsAbstract());
    };
    Iterable<Type> _filter_3 = IterableExtensions.<Type>filter(types, _function_5);
    for (final Type type_3 : _filter_3) {
      EList<ALSFactDeclaration> _factDeclarations_2 = trace.specification.getFactDeclarations();
      ALSFactDeclaration _createALSFactDeclaration_2 = this.factory.createALSFactDeclaration();
      final Procedure1<ALSFactDeclaration> _function_6 = (ALSFactDeclaration it) -> {
        it.setName(this.support.toIDMultiple("abstractIsUnion", type_3.getName()));
        ALSEquals _createALSEquals = this.factory.createALSEquals();
        final Procedure1<ALSEquals> _function_7 = (ALSEquals it_1) -> {
          ALSReference _createALSReference = this.factory.createALSReference();
          final Procedure1<ALSReference> _function_8 = (ALSReference it_2) -> {
            it_2.setReferred(CollectionsUtil.<Type, ALSSignatureDeclaration>lookup(type_3, typeTrace.type2ALSType));
          };
          ALSReference _doubleArrow_2 = ObjectExtensions.<ALSReference>operator_doubleArrow(_createALSReference, _function_8);
          it_1.setLeftOperand(_doubleArrow_2);
          final Function1<Type, ALSReference> _function_9 = (Type e) -> {
            ALSReference _createALSReference_1 = this.factory.createALSReference();
            final Procedure1<ALSReference> _function_10 = (ALSReference it_2) -> {
              it_2.setReferred(CollectionsUtil.<Type, ALSSignatureDeclaration>lookup(e, typeTrace.type2ALSType));
            };
            return ObjectExtensions.<ALSReference>operator_doubleArrow(_createALSReference_1, _function_10);
          };
          it_1.setRightOperand(this.support.unfoldPlus(
            ListExtensions.<Type, ALSReference>map(type_3.getSubtypes(), _function_9)));
        };
        ALSEquals _doubleArrow_2 = ObjectExtensions.<ALSEquals>operator_doubleArrow(_createALSEquals, _function_7);
        it.setTerm(_doubleArrow_2);
      };
      ALSFactDeclaration _doubleArrow_2 = ObjectExtensions.<ALSFactDeclaration>operator_doubleArrow(_createALSFactDeclaration_2, _function_6);
      _factDeclarations_2.add(_doubleArrow_2);
    }
    final Function1<Type, Boolean> _function_7 = (Type it) -> {
      return Boolean.valueOf(it.getSupertypes().isEmpty());
    };
    final List<Type> rootTypes = IterableExtensions.<Type>toList(IterableExtensions.<Type>filter(types, _function_7));
    EList<ALSFactDeclaration> _factDeclarations_3 = trace.specification.getFactDeclarations();
    ALSFactDeclaration _createALSFactDeclaration_3 = this.factory.createALSFactDeclaration();
    final Procedure1<ALSFactDeclaration> _function_8 = (ALSFactDeclaration it) -> {
      it.setName(this.support.toIDMultiple(new String[] { "ObjectTypeDefinition" }));
      ALSEquals _createALSEquals = this.factory.createALSEquals();
      final Procedure1<ALSEquals> _function_9 = (ALSEquals it_1) -> {
        ALSReference _createALSReference = this.factory.createALSReference();
        final Procedure1<ALSReference> _function_10 = (ALSReference it_2) -> {
          it_2.setReferred(typeTrace.objectSupperClass);
        };
        ALSReference _doubleArrow_3 = ObjectExtensions.<ALSReference>operator_doubleArrow(_createALSReference, _function_10);
        it_1.setLeftOperand(_doubleArrow_3);
        final Function1<Type, ALSReference> _function_11 = (Type e) -> {
          ALSReference _createALSReference_1 = this.factory.createALSReference();
          final Procedure1<ALSReference> _function_12 = (ALSReference it_2) -> {
            it_2.setReferred(CollectionsUtil.<Type, ALSSignatureDeclaration>lookup(e, typeTrace.type2ALSType));
          };
          return ObjectExtensions.<ALSReference>operator_doubleArrow(_createALSReference_1, _function_12);
        };
        it_1.setRightOperand(this.support.unfoldPlus(
          ListExtensions.<Type, ALSReference>map(rootTypes, _function_11)));
      };
      ALSEquals _doubleArrow_3 = ObjectExtensions.<ALSEquals>operator_doubleArrow(_createALSEquals, _function_9);
      it.setTerm(_doubleArrow_3);
    };
    ALSFactDeclaration _doubleArrow_3 = ObjectExtensions.<ALSFactDeclaration>operator_doubleArrow(_createALSFactDeclaration_3, _function_8);
    _factDeclarations_3.add(_doubleArrow_3);
    {
      final Function1<Type, Boolean> _function_9 = (Type it) -> {
        return Boolean.valueOf(it.getSupertypes().isEmpty());
      };
      final List<Type> rootTypeList = IterableExtensions.<Type>toList(IterableExtensions.<Type>filter(types, _function_9));
      int _size = rootTypeList.size();
      ExclusiveRange _doubleDotLessThan = new ExclusiveRange(0, _size, true);
      for (final Integer type1Index : _doubleDotLessThan) {
        ExclusiveRange _doubleDotLessThan_1 = new ExclusiveRange(0, (type1Index).intValue(), true);
        for (final Integer type2Index : _doubleDotLessThan_1) {
          EList<ALSFactDeclaration> _factDeclarations_4 = trace.specification.getFactDeclarations();
          ALSFactDeclaration _commonSubtypeOnlyInDiamonds = this.commonSubtypeOnlyInDiamonds(rootTypeList.get((type1Index).intValue()), rootTypeList.get((type2Index).intValue()), trace);
          _factDeclarations_4.add(_commonSubtypeOnlyInDiamonds);
        }
      }
    }
    for (final Type inScope : types) {
      {
        final EList<Type> subtypeList = inScope.getSubtypes();
        int _size = subtypeList.size();
        boolean _greaterEqualsThan = (_size >= 2);
        if (_greaterEqualsThan) {
          int _size_1 = subtypeList.size();
          ExclusiveRange _doubleDotLessThan = new ExclusiveRange(0, _size_1, true);
          for (final Integer type1Index : _doubleDotLessThan) {
            ExclusiveRange _doubleDotLessThan_1 = new ExclusiveRange(0, (type1Index).intValue(), true);
            for (final Integer type2Index : _doubleDotLessThan_1) {
              EList<ALSFactDeclaration> _factDeclarations_4 = trace.specification.getFactDeclarations();
              ALSFactDeclaration _commonSubtypeOnlyInDiamonds = this.commonSubtypeOnlyInDiamonds(subtypeList.get((type1Index).intValue()), subtypeList.get((type2Index).intValue()), trace);
              _factDeclarations_4.add(_commonSubtypeOnlyInDiamonds);
            }
          }
        }
      }
    }
  }
  
  private boolean isEnumlikeType(final Type type) {
    if ((type instanceof TypeDefinition)) {
      final EList<DefinedElement> elements = ((TypeDefinition)type).getElements();
      final Function1<DefinedElement, Boolean> _function = (DefinedElement it) -> {
        return Boolean.valueOf(((it.getDefinedInType().size() == 1) && (IterableExtensions.<TypeDefinition>head(it.getDefinedInType()) == type)));
      };
      return IterableExtensions.<DefinedElement>forall(elements, _function);
    }
    return false;
  }
  
  private boolean isEnumlikeElement(final DefinedElement d) {
    return ((d.getDefinedInType().size() == 1) && this.isEnumlikeType(IterableExtensions.<TypeDefinition>head(d.getDefinedInType())));
  }
  
  public Logic2AlloyLanguageMapper_TypeMapperTrace_FilteredTypes getTypeTrace(final Logic2AlloyLanguageMapperTrace trace) {
    final Logic2AlloyLanguageMapper_TypeMapperTrace res = trace.typeMapperTrace;
    if ((res instanceof Logic2AlloyLanguageMapper_TypeMapperTrace_FilteredTypes)) {
      return ((Logic2AlloyLanguageMapper_TypeMapperTrace_FilteredTypes)res);
    } else {
      StringConcatenation _builder = new StringConcatenation();
      _builder.append("Expected type mapping trace: ");
      String _name = Logic2AlloyLanguageMapper_TypeMapperTrace_FilteredTypes.class.getName();
      _builder.append(_name);
      _builder.append(",");
      _builder.newLineIfNotEmpty();
      _builder.append("but found ");
      String _name_1 = res.getClass().getName();
      _builder.append(_name_1);
      throw new IllegalArgumentException(_builder.toString());
    }
  }
  
  private ALSFactDeclaration commonSubtypeOnlyInDiamonds(final Type t1, final Type t2, final Logic2AlloyLanguageMapperTrace trace) {
    final TopmostCommonSubtypes.Matcher topmostCommonSubtypes = TypeQueries.instance().getTopmostCommonSubtypes(trace.incqueryEngine);
    final List<Type> allTopmostCommon = IterableExtensions.<Type>toList(topmostCommonSubtypes.getAllValuesOfcommon(t1, t2));
    ALSFactDeclaration _createALSFactDeclaration = this.factory.createALSFactDeclaration();
    final Procedure1<ALSFactDeclaration> _function = (ALSFactDeclaration it) -> {
      it.setName(this.support.toIDMultiple("common", "types", t1.getName(), t2.getName()));
      ALSEquals _createALSEquals = this.factory.createALSEquals();
      final Procedure1<ALSEquals> _function_1 = (ALSEquals it_1) -> {
        ALSIntersection _createALSIntersection = this.factory.createALSIntersection();
        final Procedure1<ALSIntersection> _function_2 = (ALSIntersection it_2) -> {
          ALSReference _createALSReference = this.factory.createALSReference();
          final Procedure1<ALSReference> _function_3 = (ALSReference it_3) -> {
            it_3.setReferred(CollectionsUtil.<Type, ALSSignatureDeclaration>lookup(t1, this.getTypeTrace(trace).type2ALSType));
          };
          ALSReference _doubleArrow = ObjectExtensions.<ALSReference>operator_doubleArrow(_createALSReference, _function_3);
          it_2.setLeftOperand(_doubleArrow);
          ALSReference _createALSReference_1 = this.factory.createALSReference();
          final Procedure1<ALSReference> _function_4 = (ALSReference it_3) -> {
            it_3.setReferred(CollectionsUtil.<Type, ALSSignatureDeclaration>lookup(t2, this.getTypeTrace(trace).type2ALSType));
          };
          ALSReference _doubleArrow_1 = ObjectExtensions.<ALSReference>operator_doubleArrow(_createALSReference_1, _function_4);
          it_2.setRightOperand(_doubleArrow_1);
        };
        ALSIntersection _doubleArrow = ObjectExtensions.<ALSIntersection>operator_doubleArrow(_createALSIntersection, _function_2);
        it_1.setLeftOperand(_doubleArrow);
        final Function1<Type, ALSReference> _function_3 = (Type t) -> {
          ALSReference _createALSReference = this.factory.createALSReference();
          final Procedure1<ALSReference> _function_4 = (ALSReference it_2) -> {
            it_2.setReferred(CollectionsUtil.<Type, ALSSignatureDeclaration>lookup(t, this.getTypeTrace(trace).type2ALSType));
          };
          return ObjectExtensions.<ALSReference>operator_doubleArrow(_createALSReference, _function_4);
        };
        it_1.setRightOperand(this.support.unfoldPlus(ListExtensions.<Type, ALSReference>map(allTopmostCommon, _function_3)));
      };
      ALSEquals _doubleArrow = ObjectExtensions.<ALSEquals>operator_doubleArrow(_createALSEquals, _function_1);
      it.setTerm(_doubleArrow);
    };
    return ObjectExtensions.<ALSFactDeclaration>operator_doubleArrow(_createALSFactDeclaration, _function);
  }
  
  private ALSTerm unfoldDistinctElements(final List<DefinedElement> operands, final Logic2AlloyLanguageMapperTrace trace) {
    ALSEquals _xifexpression = null;
    if (((operands.size() == 1) || (operands.size() == 0))) {
      _xifexpression = this.support.unfoldTrueStatement(trace);
    } else {
      int _size = operands.size();
      int _size_1 = operands.size();
      int _multiply = (_size * _size_1);
      int _divide = (_multiply / 2);
      final ArrayList<ALSTerm> notEquals = new ArrayList<ALSTerm>(_divide);
      int _size_2 = operands.size();
      ExclusiveRange _doubleDotLessThan = new ExclusiveRange(0, _size_2, true);
      for (final Integer i : _doubleDotLessThan) {
        int _size_3 = operands.size();
        ExclusiveRange _doubleDotLessThan_1 = new ExclusiveRange(((i).intValue() + 1), _size_3, true);
        for (final Integer j : _doubleDotLessThan_1) {
          ALSNotEquals _createALSNotEquals = this.factory.createALSNotEquals();
          final Procedure1<ALSNotEquals> _function = (ALSNotEquals it) -> {
            ALSReference _createALSReference = this.factory.createALSReference();
            final Procedure1<ALSReference> _function_1 = (ALSReference it_1) -> {
              it_1.setReferred(this.getTypeTrace(trace).definedElement2Declaration.get(operands.get((i).intValue())));
            };
            ALSReference _doubleArrow = ObjectExtensions.<ALSReference>operator_doubleArrow(_createALSReference, _function_1);
            it.setLeftOperand(_doubleArrow);
            ALSReference _createALSReference_1 = this.factory.createALSReference();
            final Procedure1<ALSReference> _function_2 = (ALSReference it_1) -> {
              it_1.setReferred(this.getTypeTrace(trace).definedElement2Declaration.get(operands.get((j).intValue())));
            };
            ALSReference _doubleArrow_1 = ObjectExtensions.<ALSReference>operator_doubleArrow(_createALSReference_1, _function_2);
            it.setRightOperand(_doubleArrow_1);
          };
          ALSNotEquals _doubleArrow = ObjectExtensions.<ALSNotEquals>operator_doubleArrow(_createALSNotEquals, _function);
          notEquals.add(_doubleArrow);
        }
      }
      return this.support.unfoldAnd(notEquals);
    }
    return _xifexpression;
  }
  
  @Override
  public List<ALSSignatureDeclaration> transformTypeReference(final Type referred, final Logic2AlloyLanguageMapper mapper, final Logic2AlloyLanguageMapperTrace trace) {
    ALSSignatureDeclaration _get = this.getTypeTrace(trace).type2ALSType.get(referred);
    return Collections.<ALSSignatureDeclaration>unmodifiableList(CollectionLiterals.<ALSSignatureDeclaration>newArrayList(_get));
  }
  
  @Override
  public ALSSignatureDeclaration getUndefinedSupertype(final Logic2AlloyLanguageMapperTrace trace) {
    return this.getTypeTrace(trace).objectSupperClass;
  }
  
  @Override
  public ALSTerm transformReference(final DefinedElement referred, final Logic2AlloyLanguageMapperTrace trace) {
    ALSReference _createALSReference = this.factory.createALSReference();
    final Procedure1<ALSReference> _function = (ALSReference it) -> {
      it.setReferred(CollectionsUtil.<DefinedElement, ALSSignatureDeclaration>lookup(referred, this.getTypeTrace(trace).definedElement2Declaration));
    };
    return ObjectExtensions.<ALSReference>operator_doubleArrow(_createALSReference, _function);
  }
  
  @Override
  public int getUndefinedSupertypeScope(final int undefinedScope, final Logic2AlloyLanguageMapperTrace trace) {
    int _size = this.getTypeTrace(trace).definedElement2Declaration.size();
    return (undefinedScope + _size);
  }
  
  @Override
  public AlloyModelInterpretation_TypeInterpretation getTypeInterpreter() {
    return new AlloyModelInterpretation_TypeInterpretation_FilteredTypes();
  }
}
