package hu.bme.mit.inf.dslreasoner.application.execution;

import hu.bme.mit.inf.dlsreasoner.alloy.reasoner.AlloySolver;
import hu.bme.mit.inf.dlsreasoner.alloy.reasoner.AlloySolverConfiguration;
import hu.bme.mit.inf.dslreasoner.application.applicationConfiguration.ComparisonOperator;
import hu.bme.mit.inf.dslreasoner.application.applicationConfiguration.CostEntry;
import hu.bme.mit.inf.dslreasoner.application.applicationConfiguration.CostObjectiveFunction;
import hu.bme.mit.inf.dslreasoner.application.applicationConfiguration.ObjectiveEntry;
import hu.bme.mit.inf.dslreasoner.application.applicationConfiguration.ObjectiveFunction;
import hu.bme.mit.inf.dslreasoner.application.applicationConfiguration.OptimizationDirection;
import hu.bme.mit.inf.dslreasoner.application.applicationConfiguration.OptimizationEntry;
import hu.bme.mit.inf.dslreasoner.application.applicationConfiguration.Solver;
import hu.bme.mit.inf.dslreasoner.application.applicationConfiguration.ThresholdEntry;
import hu.bme.mit.inf.dslreasoner.application.execution.ScriptConsole;
import hu.bme.mit.inf.dslreasoner.logic.model.builder.LogicReasoner;
import hu.bme.mit.inf.dslreasoner.logic.model.builder.LogicSolverConfiguration;
import hu.bme.mit.inf.dslreasoner.smt.reasoner.SMTSolver;
import hu.bme.mit.inf.dslreasoner.smt.reasoner.SmtSolverConfiguration;
import hu.bme.mit.inf.dslreasoner.viatrasolver.logic2viatra.cardinality.PolyhedralScopePropagatorConstraints;
import hu.bme.mit.inf.dslreasoner.viatrasolver.logic2viatra.cardinality.PolyhedralScopePropagatorSolver;
import hu.bme.mit.inf.dslreasoner.viatrasolver.logic2viatra.cardinality.ScopePropagatorStrategy;
import hu.bme.mit.inf.dslreasoner.viatrasolver.reasoner.CostObjectiveConfiguration;
import hu.bme.mit.inf.dslreasoner.viatrasolver.reasoner.CostObjectiveElementConfiguration;
import hu.bme.mit.inf.dslreasoner.viatrasolver.reasoner.DiversityDescriptor;
import hu.bme.mit.inf.dslreasoner.viatrasolver.reasoner.PunishSizeStrategy;
import hu.bme.mit.inf.dslreasoner.viatrasolver.reasoner.ViatraReasoner;
import hu.bme.mit.inf.dslreasoner.viatrasolver.reasoner.ViatraReasonerConfiguration;
import hu.bme.mit.inf.dslreasoner.viatrasolver.reasoner.optimization.ObjectiveKind;
import hu.bme.mit.inf.dslreasoner.viatrasolver.reasoner.optimization.ObjectiveThreshold;
import hu.bme.mit.inf.dslreasoner.visualisation.pi2graphviz.GraphvizVisualiser;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.function.Consumer;
import org.eclipse.emf.common.util.EList;
import org.eclipse.viatra.query.patternlanguage.emf.vql.Pattern;
import org.eclipse.viatra.query.patternlanguage.emf.vql.PatternModel;
import org.eclipse.xtend2.lib.StringConcatenation;
import org.eclipse.xtext.EcoreUtil2;
import org.eclipse.xtext.xbase.lib.Exceptions;
import org.eclipse.xtext.xbase.lib.Functions.Function1;
import org.eclipse.xtext.xbase.lib.InputOutput;
import org.eclipse.xtext.xbase.lib.ObjectExtensions;
import org.eclipse.xtext.xbase.lib.Procedures.Procedure1;
import org.eclipse.xtext.xbase.lib.StringExtensions;

@SuppressWarnings("all")
public class SolverLoader {
  public LogicReasoner loadSolver(final Solver solver, final Map<String, String> config) {
    if (solver != null) {
      switch (solver) {
        case ALLOY_SOLVER:
          return new AlloySolver();
        case SMT_SOLVER:
          return new SMTSolver();
        case VIATRA_SOLVER:
          return new ViatraReasoner();
        default:
          break;
      }
    }
    return null;
  }
  
  private <Type extends Object> Optional<Type> getAsType(final Map<String, String> config, final String key, final ScriptConsole console, final Function1<String, Type> parser, final Class<Type> requestedType) {
    boolean _containsKey = config.containsKey(key);
    if (_containsKey) {
      final String stringValue = config.get(key);
      try {
        final Type parsedValue = parser.apply(stringValue);
        return Optional.<Type>of(parsedValue);
      } catch (final Throwable _t) {
        if (_t instanceof Exception) {
          StringConcatenation _builder = new StringConcatenation();
          _builder.append("Unable to parse configuration value for \"");
          _builder.append(key);
          _builder.append("\" to ");
          String _simpleName = requestedType.getSimpleName();
          _builder.append(_simpleName);
          _builder.append("!");
          console.writeError(_builder.toString());
          return Optional.<Type>empty();
        } else {
          throw Exceptions.sneakyThrow(_t);
        }
      }
    } else {
      return Optional.<Type>empty();
    }
  }
  
  private Optional<Integer> getAsInteger(final Map<String, String> config, final String key, final ScriptConsole console) {
    final Function1<String, Integer> _function = (String x) -> {
      return Integer.valueOf(Integer.parseInt(x));
    };
    return this.<Integer>getAsType(config, key, console, _function, Integer.class);
  }
  
  private Optional<Boolean> getAsBoolean(final Map<String, String> config, final String key, final ScriptConsole console) {
    final Function1<String, Boolean> _function = (String x) -> {
      return Boolean.valueOf(Boolean.parseBoolean(x));
    };
    return this.<Boolean>getAsType(config, key, console, _function, Boolean.class);
  }
  
  private Optional<Double> getAsDouble(final Map<String, String> config, final String key, final ScriptConsole console) {
    final Function1<String, Double> _function = (String x) -> {
      return Double.valueOf(Double.parseDouble(x));
    };
    return this.<Double>getAsType(config, key, console, _function, Double.class);
  }
  
  public LogicSolverConfiguration loadSolverConfig(final Solver solver, final Map<String, String> config, final List<ObjectiveEntry> objectiveEntries, final ScriptConsole console) {
    LogicSolverConfiguration _switchResult = null;
    if (solver != null) {
      switch (solver) {
        case ALLOY_SOLVER:
          SmtSolverConfiguration _xblockexpression = null;
          {
            boolean _isEmpty = objectiveEntries.isEmpty();
            boolean _not = (!_isEmpty);
            if (_not) {
              throw new IllegalArgumentException("Objectives are not supported by Alloy.");
            }
            final SmtSolverConfiguration c = new SmtSolverConfiguration();
            final Consumer<Boolean> _function = (Boolean it) -> {
              c.fixRandomSeed = (it).booleanValue();
            };
            this.getAsBoolean(config, "fixRandomSeed", console).ifPresent(_function);
            final Function1<String, String> _function_1 = (String it) -> {
              return it;
            };
            final Consumer<String> _function_2 = (String it) -> {
              c.solverPath = it;
            };
            this.<String>getAsType(config, "path", console, _function_1, String.class).ifPresent(_function_2);
            _xblockexpression = c;
          }
          _switchResult = _xblockexpression;
          break;
        case SMT_SOLVER:
          SmtSolverConfiguration _xblockexpression_1 = null;
          {
            boolean _isEmpty = objectiveEntries.isEmpty();
            boolean _not = (!_isEmpty);
            if (_not) {
              throw new IllegalArgumentException("Objectives are not supported by Z3.");
            }
            final SmtSolverConfiguration c = new SmtSolverConfiguration();
            final Consumer<Boolean> _function = (Boolean it) -> {
              c.fixRandomSeed = (it).booleanValue();
            };
            this.getAsBoolean(config, "fixRandomSeed", console).ifPresent(_function);
            final Function1<String, String> _function_1 = (String it) -> {
              return it;
            };
            final Consumer<String> _function_2 = (String it) -> {
              c.solverPath = it;
            };
            this.<String>getAsType(config, "path", console, _function_1, String.class).ifPresent(_function_2);
            _xblockexpression_1 = c;
          }
          _switchResult = _xblockexpression_1;
          break;
        case VIATRA_SOLVER:
          ViatraReasonerConfiguration _xblockexpression_2 = null;
          {
            final ViatraReasonerConfiguration c = new ViatraReasonerConfiguration();
            GraphvizVisualiser _graphvizVisualiser = new GraphvizVisualiser();
            c.debugConfiguration.partialInterpretatioVisualiser = _graphvizVisualiser;
            boolean _containsKey = config.containsKey("diversity-range");
            if (_containsKey) {
              final String stringValue = config.get("diversity-range");
              try {
                final int range = Integer.parseInt(stringValue);
                DiversityDescriptor _diversityDescriptor = new DiversityDescriptor();
                final Procedure1<DiversityDescriptor> _function = (DiversityDescriptor it) -> {
                  it.ensureDiversity = true;
                  it.range = range;
                };
                DiversityDescriptor _doubleArrow = ObjectExtensions.<DiversityDescriptor>operator_doubleArrow(_diversityDescriptor, _function);
                c.diversityRequirement = _doubleArrow;
              } catch (final Throwable _t) {
                if (_t instanceof NumberFormatException) {
                  final NumberFormatException e = (NumberFormatException)_t;
                  StringConcatenation _builder = new StringConcatenation();
                  _builder.append("Malformed number format: ");
                  String _message = e.getMessage();
                  _builder.append(_message);
                  console.writeError(_builder.toString());
                } else {
                  throw Exceptions.sneakyThrow(_t);
                }
              }
            }
            boolean _containsKey_1 = config.containsKey("numeric-solver-at-end");
            if (_containsKey_1) {
              final String stringValue_1 = config.get("numeric-solver-at-end");
              boolean _equals = stringValue_1.equals("true");
              if (_equals) {
                InputOutput.<String>println("numeric-solver-at-end");
                c.runIntermediateNumericalConsistencyChecks = false;
              }
            }
            boolean _containsKey_2 = config.containsKey("fitness-punishSize");
            if (_containsKey_2) {
              final String stringValue_2 = config.get("fitness-punishSize");
              PunishSizeStrategy _switchResult_1 = null;
              if (stringValue_2 != null) {
                switch (stringValue_2) {
                  case "false":
                    _switchResult_1 = PunishSizeStrategy.NONE;
                    break;
                  case "true":
                    _switchResult_1 = PunishSizeStrategy.SMALLER_IS_BETTER;
                    break;
                  case "inverse":
                    _switchResult_1 = PunishSizeStrategy.LARGER_IS_BETTER;
                    break;
                  default:
                    throw new IllegalArgumentException(("Unknown punish size strategy: " + stringValue_2));
                }
              } else {
                throw new IllegalArgumentException(("Unknown punish size strategy: " + stringValue_2));
              }
              c.punishSize = _switchResult_1;
            }
            boolean _containsKey_3 = config.containsKey("fitness-scope");
            if (_containsKey_3) {
              final String stringValue_3 = config.get("fitness-scope");
              c.scopeWeight = Integer.parseInt(stringValue_3);
            }
            boolean _containsKey_4 = config.containsKey("fitness-missing-containment");
            if (_containsKey_4) {
              final String stringValue_4 = config.get("fitness-missing-containment");
              c.conaintmentWeight = Integer.parseInt(stringValue_4);
            }
            boolean _containsKey_5 = config.containsKey("fitness-missing-noncontainment");
            if (_containsKey_5) {
              final String stringValue_5 = config.get("fitness-missing-noncontainment");
              c.nonContainmentWeight = Integer.parseInt(stringValue_5);
            }
            boolean _containsKey_6 = config.containsKey("fitness-missing-wf");
            if (_containsKey_6) {
              final String stringValue_6 = config.get("fitness-missing-wf");
              c.unfinishedWFWeight = Integer.parseInt(stringValue_6);
            }
            boolean _containsKey_7 = config.containsKey("fitness-objectCreationCosts");
            if (_containsKey_7) {
              final String stringValue_7 = config.get("fitness-objectCreationCosts");
              c.calculateObjectCreationCosts = Boolean.parseBoolean(stringValue_7);
            }
            boolean _containsKey_8 = config.containsKey("scopePropagator");
            if (_containsKey_8) {
              final String stringValue_8 = config.get("scopePropagator");
              ScopePropagatorStrategy _switchResult_2 = null;
              if (stringValue_8 != null) {
                switch (stringValue_8) {
                  case "polyhedral":
                    _switchResult_2 = new ScopePropagatorStrategy.Polyhedral(
                      PolyhedralScopePropagatorConstraints.Relational, PolyhedralScopePropagatorSolver.Clp, true);
                    break;
                  case "hybrid":
                    _switchResult_2 = new ScopePropagatorStrategy.Polyhedral(
                      PolyhedralScopePropagatorConstraints.Relational, PolyhedralScopePropagatorSolver.Clp, false);
                    break;
                  case "typeHierarchy":
                    _switchResult_2 = ScopePropagatorStrategy.BasicTypeHierarchy;
                    break;
                  default:
                    throw new IllegalArgumentException(("Unknown scope propagator: " + stringValue_8));
                }
              } else {
                throw new IllegalArgumentException(("Unknown scope propagator: " + stringValue_8));
              }
              c.scopePropagatorStrategy = _switchResult_2;
            }
            for (final ObjectiveEntry objectiveEntry : objectiveEntries) {
              {
                final CostObjectiveConfiguration costObjectiveConfig = new CostObjectiveConfiguration();
                boolean _matched = false;
                if (objectiveEntry instanceof OptimizationEntry) {
                  _matched=true;
                  costObjectiveConfig.findExtremum = true;
                  ObjectiveKind _switchResult_4 = null;
                  OptimizationDirection _direction = ((OptimizationEntry)objectiveEntry).getDirection();
                  final OptimizationDirection direction = _direction;
                  if (direction != null) {
                    switch (direction) {
                      case MAXIMIZE:
                        _switchResult_4 = ObjectiveKind.HIGHER_IS_BETTER;
                        break;
                      case MINIMIZE:
                        _switchResult_4 = ObjectiveKind.LOWER_IS_BETTER;
                        break;
                      default:
                        throw new IllegalArgumentException(("Unknown direction: " + direction));
                    }
                  } else {
                    throw new IllegalArgumentException(("Unknown direction: " + direction));
                  }
                  costObjectiveConfig.kind = _switchResult_4;
                  costObjectiveConfig.threshold = ObjectiveThreshold.NO_THRESHOLD;
                }
                if (!_matched) {
                  if (objectiveEntry instanceof ThresholdEntry) {
                    _matched=true;
                    costObjectiveConfig.findExtremum = false;
                    final double threshold = ((ThresholdEntry)objectiveEntry).getThreshold().doubleValue();
                    ComparisonOperator _operator = ((ThresholdEntry)objectiveEntry).getOperator();
                    final ComparisonOperator operator = _operator;
                    if (operator != null) {
                      switch (operator) {
                        case LESS:
                          costObjectiveConfig.kind = ObjectiveKind.LOWER_IS_BETTER;
                          ObjectiveThreshold.Exclusive _exclusive = new ObjectiveThreshold.Exclusive(threshold);
                          costObjectiveConfig.threshold = _exclusive;
                          break;
                        case GREATER:
                          costObjectiveConfig.kind = ObjectiveKind.HIGHER_IS_BETTER;
                          ObjectiveThreshold.Exclusive _exclusive_1 = new ObjectiveThreshold.Exclusive(threshold);
                          costObjectiveConfig.threshold = _exclusive_1;
                          break;
                        case LESS_EQUALS:
                          costObjectiveConfig.kind = ObjectiveKind.LOWER_IS_BETTER;
                          ObjectiveThreshold.Exclusive _exclusive_2 = new ObjectiveThreshold.Exclusive(threshold);
                          costObjectiveConfig.threshold = _exclusive_2;
                          break;
                        case GREATER_EQUALS:
                          costObjectiveConfig.kind = ObjectiveKind.HIGHER_IS_BETTER;
                          ObjectiveThreshold.Exclusive _exclusive_3 = new ObjectiveThreshold.Exclusive(threshold);
                          costObjectiveConfig.threshold = _exclusive_3;
                          break;
                        default:
                          throw new IllegalArgumentException(("Unknown operator: " + operator));
                      }
                    } else {
                      throw new IllegalArgumentException(("Unknown operator: " + operator));
                    }
                  }
                }
                final ObjectiveFunction function = objectiveEntry.getFunction();
                if ((function instanceof CostObjectiveFunction)) {
                  EList<CostEntry> _entries = ((CostObjectiveFunction)function).getEntries();
                  for (final CostEntry costEntry : _entries) {
                    {
                      final CostObjectiveElementConfiguration element = new CostObjectiveElementConfiguration();
                      final Pattern pattern = costEntry.getPatternElement().getPattern();
                      String _elvis = null;
                      PatternModel _package = costEntry.getPatternElement().getPackage();
                      String _packageName = null;
                      if (_package!=null) {
                        _packageName=_package.getPackageName();
                      }
                      if (_packageName != null) {
                        _elvis = _packageName;
                      } else {
                        PatternModel _containerOfType = EcoreUtil2.<PatternModel>getContainerOfType(pattern, PatternModel.class);
                        String _packageName_1 = null;
                        if (_containerOfType!=null) {
                          _packageName_1=_containerOfType.getPackageName();
                        }
                        _elvis = _packageName_1;
                      }
                      final String packageName = _elvis;
                      String _xifexpression = null;
                      boolean _isNullOrEmpty = StringExtensions.isNullOrEmpty(packageName);
                      if (_isNullOrEmpty) {
                        _xifexpression = pattern.getName();
                      } else {
                        String _name = pattern.getName();
                        _xifexpression = ((packageName + ".") + _name);
                      }
                      element.patternQualifiedName = _xifexpression;
                      element.weight = costEntry.getWeight();
                      costObjectiveConfig.elements.add(element);
                    }
                  }
                } else {
                  throw new IllegalArgumentException("Only cost objectives are supported by VIATRA.");
                }
                c.costObjectives.add(costObjectiveConfig);
              }
            }
            _xblockexpression_2 = c;
          }
          _switchResult = _xblockexpression_2;
          break;
        default:
          StringConcatenation _builder = new StringConcatenation();
          _builder.append("Unknown solver: ");
          _builder.append(solver);
          throw new UnsupportedOperationException(_builder.toString());
      }
    } else {
      StringConcatenation _builder = new StringConcatenation();
      _builder.append("Unknown solver: ");
      _builder.append(solver);
      throw new UnsupportedOperationException(_builder.toString());
    }
    return _switchResult;
  }
  
  protected void _setRunIndex(final AlloySolverConfiguration config, final Map<String, String> parameters, final int runIndex, final ScriptConsole console) {
    final Consumer<Boolean> _function = (Boolean it) -> {
      if ((it).booleanValue()) {
        config.randomise = (runIndex - 1);
      }
    };
    this.getAsBoolean(parameters, "randomize", console).ifPresent(_function);
  }
  
  protected void _setRunIndex(final LogicSolverConfiguration config, final Map<String, String> parameters, final int runIndex, final ScriptConsole console) {
  }
  
  public void setRunIndex(final LogicSolverConfiguration config, final Map<String, String> parameters, final int runIndex, final ScriptConsole console) {
    if (config instanceof AlloySolverConfiguration) {
      _setRunIndex((AlloySolverConfiguration)config, parameters, runIndex, console);
      return;
    } else if (config != null) {
      _setRunIndex(config, parameters, runIndex, console);
      return;
    } else {
      throw new IllegalArgumentException("Unhandled parameter types: " +
        Arrays.<Object>asList(config, parameters, runIndex, console).toString());
    }
  }
}
