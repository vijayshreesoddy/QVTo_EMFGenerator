package hu.bme.mit.inf.dslreasoner.application.ui.highlight;

import com.google.common.collect.Iterables;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Random;
import org.eclipse.emf.common.util.EList;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EClassifier;
import org.eclipse.emf.ecore.EDataType;
import org.eclipse.xtext.xbase.lib.CollectionLiterals;
import org.eclipse.xtext.xbase.lib.Functions.Function0;
import org.eclipse.xtext.xbase.lib.Functions.Function1;
import org.eclipse.xtext.xbase.lib.Functions.Function2;
import org.eclipse.xtext.xbase.lib.IterableExtensions;
import org.eclipse.xtext.xbase.lib.Pair;

@SuppressWarnings("all")
public class ColorCalculator {
  protected List<Integer> _getColor(final EClass c) {
    EList<EClass> _eAllSuperTypes = c.getEAllSuperTypes();
    final Iterable<EClass> supertypes = Iterables.<EClass>concat(_eAllSuperTypes, Collections.<EClass>unmodifiableList(CollectionLiterals.<EClass>newArrayList(c)));
    final Function1<EClass, Integer> _function = (EClass it) -> {
      String _nsURI = c.getEPackage().getNsURI();
      String _name = c.getName();
      int _hashCode = Pair.<String, String>of(_nsURI, _name).hashCode();
      return Integer.valueOf((_hashCode + 2));
    };
    final Iterable<Integer> typeHashcodes = IterableExtensions.<EClass, Integer>map(supertypes, _function);
    return this.randomColor(typeHashcodes);
  }
  
  protected List<Integer> _getColor(final EDataType e) {
    String _nsURI = e.getEPackage().getNsURI();
    String _name = e.getName();
    return this.randomColor(Integer.valueOf(Pair.<String, String>of(_nsURI, _name).hashCode()));
  }
  
  protected List<Integer> randomColor(final Integer seed) {
    final Random random = new Random((seed).intValue());
    final Function0<Integer> _function = () -> {
      int _nextInt = random.nextInt(128);
      return Integer.valueOf((_nextInt + 128));
    };
    final Function0<Integer> rangePicker = _function;
    Integer _apply = rangePicker.apply();
    Integer _apply_1 = rangePicker.apply();
    Integer _apply_2 = rangePicker.apply();
    return Collections.<Integer>unmodifiableList(CollectionLiterals.<Integer>newArrayList(_apply, _apply_1, _apply_2));
  }
  
  protected List<Integer> randomColor(final Iterable<Integer> seeds) {
    final Function1<Integer, List<Integer>> _function = (Integer it) -> {
      return this.randomColor(it);
    };
    return this.averageColor(IterableExtensions.<Integer, List<Integer>>map(seeds, _function));
  }
  
  private List<Integer> averageColor(final Iterable<List<Integer>> colors) {
    boolean _isEmpty = IterableExtensions.isEmpty(colors);
    if (_isEmpty) {
      return Collections.<Integer>unmodifiableList(CollectionLiterals.<Integer>newArrayList(Integer.valueOf(256), Integer.valueOf(256), Integer.valueOf(256)));
    } else {
      final Function1<List<Integer>, Integer> _function = (List<Integer> it) -> {
        return it.get(0);
      };
      int _average = this.average(IterableExtensions.<List<Integer>, Integer>map(colors, _function));
      final Function1<List<Integer>, Integer> _function_1 = (List<Integer> it) -> {
        return it.get(1);
      };
      int _average_1 = this.average(IterableExtensions.<List<Integer>, Integer>map(colors, _function_1));
      final Function1<List<Integer>, Integer> _function_2 = (List<Integer> it) -> {
        return it.get(2);
      };
      int _average_2 = this.average(IterableExtensions.<List<Integer>, Integer>map(colors, _function_2));
      return Collections.<Integer>unmodifiableList(CollectionLiterals.<Integer>newArrayList(Integer.valueOf(_average), Integer.valueOf(_average_1), Integer.valueOf(_average_2)));
    }
  }
  
  private int average(final Iterable<Integer> doubles) {
    final Function2<Integer, Integer, Integer> _function = (Integer p1, Integer p2) -> {
      return Integer.valueOf(((p1).intValue() + (p2).intValue()));
    };
    Integer _reduce = IterableExtensions.<Integer>reduce(doubles, _function);
    int _size = IterableExtensions.size(doubles);
    return ((_reduce).intValue() / _size);
  }
  
  public List<Integer> getColor(final EClassifier c) {
    if (c instanceof EClass) {
      return _getColor((EClass)c);
    } else if (c instanceof EDataType) {
      return _getColor((EDataType)c);
    } else {
      throw new IllegalArgumentException("Unhandled parameter types: " +
        Arrays.<Object>asList(c).toString());
    }
  }
}
