package hu.bme.mit.inf.dslreasoner.application.ui.execute;

import com.google.common.collect.Iterables;
import hu.bme.mit.inf.dslreasoner.application.execution.ScriptConsole;
import hu.bme.mit.inf.dslreasoner.application.execution.ScriptConsoleDecorator;
import hu.bme.mit.inf.dslreasoner.application.ui.execute.ScriptConsoleFileHiperlink;
import java.io.File;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.CompletableFuture;
import org.eclipse.emf.common.util.URI;
import org.eclipse.jface.text.BadLocationException;
import org.eclipse.jface.text.DocumentEvent;
import org.eclipse.jface.text.IDocumentListener;
import org.eclipse.swt.graphics.Color;
import org.eclipse.swt.graphics.Device;
import org.eclipse.ui.console.ConsolePlugin;
import org.eclipse.ui.console.IConsole;
import org.eclipse.ui.console.IConsoleManager;
import org.eclipse.ui.console.MessageConsole;
import org.eclipse.ui.console.MessageConsoleStream;
import org.eclipse.xtend2.lib.StringConcatenation;
import org.eclipse.xtext.xbase.lib.CollectionLiterals;
import org.eclipse.xtext.xbase.lib.Conversions;
import org.eclipse.xtext.xbase.lib.Exceptions;
import org.eclipse.xtext.xbase.lib.ExclusiveRange;
import org.eclipse.xtext.xbase.lib.Functions.Function1;
import org.eclipse.xtext.xbase.lib.IterableExtensions;

@SuppressWarnings("all")
public class RuntimeConsoleBasedScriptConsole extends ScriptConsole {
  /**
   * Console is identified with the name of this class.
   */
  private static final String consoleID = ScriptConsole.class.getName();
  
  private final MessageConsole runtimeConsole;
  
  public RuntimeConsoleBasedScriptConsole(final boolean cleanFiles, final URI messageConsoleURI, final URI errorConsoleURI, final URI statisticsConsoleURI) {
    super((!RuntimeConsoleBasedScriptConsole.hasConsolePlugin()), cleanFiles, messageConsoleURI, errorConsoleURI, statisticsConsoleURI);
    this.runtimeConsole = this.prepareRuntimeConsole();
    this.writeErrorMessagesDuringInitialisation();
  }
  
  @Override
  public void writeMessage(final CharSequence message, final String separator, final ScriptConsoleDecorator[] decorators) {
    super.writeMessage(message, separator, decorators);
    if ((this.runtimeConsole != null)) {
      this.writeToRuntimeConsole(message, separator, decorators);
    }
  }
  
  @Override
  public void writeMessage(final String message) {
    super.writeMessage(message);
    if ((this.runtimeConsole != null)) {
      this.writeToRuntimeConsole(message);
    }
  }
  
  @Override
  public void writeError(final CharSequence message, final String separator, final ScriptConsoleDecorator[] decorators) {
    super.writeError(message, separator, decorators);
    if ((this.runtimeConsole != null)) {
      this.writeToRuntimeConsole(message, separator, decorators);
    }
  }
  
  @Override
  public void writeError(final String message) {
    super.writeError(message);
    if ((this.runtimeConsole != null)) {
      this.writeToRuntimeConsole(message);
    }
  }
  
  private MessageConsole prepareRuntimeConsole() {
    final ConsolePlugin plugin = ConsolePlugin.getDefault();
    if ((plugin == null)) {
      return null;
    } else {
      final IConsoleManager conMan = plugin.getConsoleManager();
      final IConsole[] existingConsoles = conMan.getConsoles();
      final Function1<IConsole, Boolean> _function = (IConsole it) -> {
        return Boolean.valueOf(it.getName().equals(RuntimeConsoleBasedScriptConsole.consoleID));
      };
      final Iterable<IConsole> existingConsolesWithID = IterableExtensions.<IConsole>filter(((Iterable<IConsole>)Conversions.doWrapArray(existingConsoles)), _function);
      boolean _isEmpty = IterableExtensions.isEmpty(existingConsolesWithID);
      if (_isEmpty) {
        final MessageConsole res = new MessageConsole(RuntimeConsoleBasedScriptConsole.consoleID, null);
        conMan.addConsoles(new IConsole[] { res });
        return res;
      } else {
        IConsole _head = IterableExtensions.<IConsole>head(existingConsolesWithID);
        return ((MessageConsole) _head);
      }
    }
  }
  
  private void writeToRuntimeConsole(final CharSequence message) {
    try {
      ConsolePlugin.getDefault().getConsoleManager().showConsoleView(this.runtimeConsole);
      final MessageConsoleStream stream = this.runtimeConsole.newMessageStream();
      stream.println(message.toString());
      stream.close();
    } catch (Throwable _e) {
      throw Exceptions.sneakyThrow(_e);
    }
  }
  
  private void writeToRuntimeConsole(final CharSequence message, final String separator, final ScriptConsoleDecorator[] decorators) {
    try {
      final String messageString = message.toString();
      Iterable<String> _xifexpression = null;
      boolean _startsWith = messageString.startsWith(separator);
      if (_startsWith) {
        String[] _split = messageString.split(separator, (-1));
        _xifexpression = Iterables.<String>concat(Collections.<String>unmodifiableList(CollectionLiterals.<String>newArrayList("")), ((Iterable<? extends String>)Conversions.doWrapArray(_split)));
      } else {
        _xifexpression = IterableExtensions.<String>toList(((Iterable<String>)Conversions.doWrapArray(messageString.split(separator, (-1)))));
      }
      final Iterable<String> separatedMessage = _xifexpression;
      int _size = IterableExtensions.size(separatedMessage);
      int _minus = (_size - 1);
      int _size_1 = ((List<ScriptConsoleDecorator>)Conversions.doWrapArray(decorators)).size();
      boolean _tripleNotEquals = (_minus != _size_1);
      if (_tripleNotEquals) {
        throw new IllegalArgumentException();
      }
      ConsolePlugin.getDefault().getConsoleManager().showConsoleView(this.runtimeConsole);
      final MessageConsoleStream stream = this.runtimeConsole.newMessageStream();
      int _size_2 = ((List<ScriptConsoleDecorator>)Conversions.doWrapArray(decorators)).size();
      ExclusiveRange _doubleDotLessThan = new ExclusiveRange(0, _size_2, true);
      for (final Integer i : _doubleDotLessThan) {
        {
          stream.print(((String[])Conversions.unwrapArray(separatedMessage, String.class))[(i).intValue()]);
          this.writeDecoratedTextToRuntimeConsole(decorators[(i).intValue()], stream);
        }
      }
      stream.println(IterableExtensions.<String>last(separatedMessage));
      stream.close();
    } catch (Throwable _e) {
      throw Exceptions.sneakyThrow(_e);
    }
  }
  
  private void writeDecoratedTextToRuntimeConsole(final ScriptConsoleDecorator message, final MessageConsoleStream stream) {
    try {
      final Color originalBackgroundColor = this.runtimeConsole.getBackground();
      Color newColor = null;
      StringConcatenation _builder = new StringConcatenation();
      _builder.append("[");
      String _text = message.getText();
      _builder.append(_text);
      _builder.append("]");
      final String text = _builder.toString();
      if ((((message.getRed() >= 0) && (message.getGreen() >= 0)) && (message.getBlue() >= 0))) {
        Device _device = originalBackgroundColor.getDevice();
        int _red = message.getRed();
        int _green = message.getGreen();
        int _blue = message.getBlue();
        Color _color = new Color(_device, _red, _green, _blue);
        newColor = _color;
        this.runtimeConsole.setBackground(newColor);
      }
      stream.flush();
      final CompletableFuture<Boolean> finished = new CompletableFuture<Boolean>();
      final IDocumentListener listener = new IDocumentListener() {
        @Override
        public void documentAboutToBeChanged(final DocumentEvent event) {
        }
        
        @Override
        public void documentChanged(final DocumentEvent event) {
          boolean _endsWith = event.fText.endsWith(text);
          if (_endsWith) {
            int _length = event.fDocument.getLength();
            int _length_1 = text.length();
            int _minus = (_length - _length_1);
            final int from = (_minus + 1);
            final int length = message.getText().length();
            try {
              File _hyperlink = message.getHyperlink();
              ScriptConsoleFileHiperlink _scriptConsoleFileHiperlink = new ScriptConsoleFileHiperlink(_hyperlink);
              RuntimeConsoleBasedScriptConsole.this.runtimeConsole.addHyperlink(_scriptConsoleFileHiperlink, from, length);
            } catch (final Throwable _t) {
              if (_t instanceof BadLocationException) {
              } else {
                throw Exceptions.sneakyThrow(_t);
              }
            } finally {
              RuntimeConsoleBasedScriptConsole.this.runtimeConsole.getDocument().removeDocumentListener(this);
              finished.complete(Boolean.valueOf(true));
            }
          }
        }
      };
      this.runtimeConsole.getDocument().addDocumentListener(listener);
      stream.print(text);
      stream.flush();
      finished.get();
      if ((((message.getRed() >= 0) && (message.getGreen() >= 0)) && (message.getBlue() >= 0))) {
        newColor.dispose();
        this.runtimeConsole.setBackground(originalBackgroundColor);
      }
    } catch (Throwable _e) {
      throw Exceptions.sneakyThrow(_e);
    }
  }
  
  private static boolean hasConsolePlugin() {
    ConsolePlugin _default = ConsolePlugin.getDefault();
    return (_default != null);
  }
  
  public static final ScriptConsole.Factory FACTORY = new ScriptConsole.Factory() {
    @Override
    public ScriptConsole createScriptConsole(final boolean cleanFiles, final URI messageConsoleURI, final URI errorConsoleURI, final URI statisticsConsoleURI) {
      return new RuntimeConsoleBasedScriptConsole(cleanFiles, messageConsoleURI, errorConsoleURI, statisticsConsoleURI);
    }
  };
}
