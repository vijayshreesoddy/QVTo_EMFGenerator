package hu.bme.mit.inf.dlsreasoner.alloy.reasoner.builder;

import hu.bme.mit.inf.dlsreasoner.alloy.reasoner.builder.Logic2AlloyLanguageMapper;
import hu.bme.mit.inf.dlsreasoner.alloy.reasoner.builder.Logic2AlloyLanguageMapperTrace;
import hu.bme.mit.inf.dlsreasoner.alloy.reasoner.builder.Logic2AlloyLanguageMapper_Support;
import hu.bme.mit.inf.dslreasoner.alloyLanguage.ALSFieldDeclaration;
import hu.bme.mit.inf.dslreasoner.alloyLanguage.ALSFunctionDefinition;
import hu.bme.mit.inf.dslreasoner.alloyLanguage.ALSMultiplicity;
import hu.bme.mit.inf.dslreasoner.alloyLanguage.ALSVariableDeclaration;
import hu.bme.mit.inf.dslreasoner.alloyLanguage.AlloyLanguageFactory;
import hu.bme.mit.inf.dslreasoner.logic.model.logiclanguage.Constant;
import hu.bme.mit.inf.dslreasoner.logic.model.logiclanguage.ConstantDeclaration;
import hu.bme.mit.inf.dslreasoner.logic.model.logiclanguage.ConstantDefinition;
import hu.bme.mit.inf.dslreasoner.logic.model.logiclanguage.Variable;
import hu.bme.mit.inf.dslreasoner.util.CollectionsUtil;
import java.util.Arrays;
import org.eclipse.emf.common.util.EList;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.xtext.xbase.lib.CollectionLiterals;
import org.eclipse.xtext.xbase.lib.Extension;
import org.eclipse.xtext.xbase.lib.ObjectExtensions;
import org.eclipse.xtext.xbase.lib.Procedures.Procedure1;

@SuppressWarnings("all")
public class Logic2AlloyLanguageMapper_ConstantMapper {
  @Extension
  private final AlloyLanguageFactory factory = AlloyLanguageFactory.eINSTANCE;
  
  private final Logic2AlloyLanguageMapper_Support support = new Logic2AlloyLanguageMapper_Support();
  
  private final Logic2AlloyLanguageMapper base;
  
  public Logic2AlloyLanguageMapper_ConstantMapper(final Logic2AlloyLanguageMapper base) {
    this.base = base;
  }
  
  protected EObject _transformConstant(final ConstantDeclaration constant, final Logic2AlloyLanguageMapperTrace trace) {
    ALSFieldDeclaration _xifexpression = null;
    boolean _containsKey = trace.constantDefinitions.containsKey(constant);
    boolean _not = (!_containsKey);
    if (_not) {
      ALSFieldDeclaration _xblockexpression = null;
      {
        ALSFieldDeclaration _createALSFieldDeclaration = this.factory.createALSFieldDeclaration();
        final Procedure1<ALSFieldDeclaration> _function = (ALSFieldDeclaration it) -> {
          it.setName(this.support.toID(constant.getName()));
          it.setType(this.base.transformTypeReference(constant.getType(), trace));
          it.setMultiplicity(ALSMultiplicity.ONE);
        };
        final ALSFieldDeclaration c = ObjectExtensions.<ALSFieldDeclaration>operator_doubleArrow(_createALSFieldDeclaration, _function);
        EList<ALSFieldDeclaration> _fields = trace.logicLanguageBody.getFields();
        _fields.add(c);
        _xblockexpression = trace.constantDeclaration2LanguageField.put(constant, c);
      }
      _xifexpression = _xblockexpression;
    }
    return _xifexpression;
  }
  
  protected EObject _transformConstant(final ConstantDefinition constant, final Logic2AlloyLanguageMapperTrace trace) {
    ALSFunctionDefinition _xblockexpression = null;
    {
      ALSFunctionDefinition _createALSFunctionDefinition = this.factory.createALSFunctionDefinition();
      final Procedure1<ALSFunctionDefinition> _function = (ALSFunctionDefinition it) -> {
        it.setName(this.support.toID(constant.getName()));
        it.setType(this.base.transformTypeReference(constant.getType(), trace));
      };
      final ALSFunctionDefinition c = ObjectExtensions.<ALSFunctionDefinition>operator_doubleArrow(_createALSFunctionDefinition, _function);
      EList<ALSFunctionDefinition> _functionDefinitions = trace.specification.getFunctionDefinitions();
      _functionDefinitions.add(c);
      _xblockexpression = trace.constantDefinition2Function.put(constant, c);
    }
    return _xblockexpression;
  }
  
  protected void transformConstantDefinitionSpecification(final ConstantDefinition constant, final Logic2AlloyLanguageMapperTrace trace) {
    final ALSFunctionDefinition definition = CollectionsUtil.<ConstantDefinition, ALSFunctionDefinition>lookup(constant, trace.constantDefinition2Function);
    definition.setValue(this.base.transformTerm(constant.getValue(), trace, CollectionLiterals.<Variable, ALSVariableDeclaration>emptyMap()));
  }
  
  protected EObject transformConstant(final Constant constant, final Logic2AlloyLanguageMapperTrace trace) {
    if (constant instanceof ConstantDeclaration) {
      return _transformConstant((ConstantDeclaration)constant, trace);
    } else if (constant instanceof ConstantDefinition) {
      return _transformConstant((ConstantDefinition)constant, trace);
    } else {
      throw new IllegalArgumentException("Unhandled parameter types: " +
        Arrays.<Object>asList(constant, trace).toString());
    }
  }
}
