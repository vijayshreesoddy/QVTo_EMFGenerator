/**
 */
package hu.bme.mit.inf.dslreasoner.alloyLanguage;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>ALS Relation Definition</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see hu.bme.mit.inf.dslreasoner.alloyLanguage.AlloyLanguagePackage#getALSRelationDefinition()
 * @model
 * @generated
 */
public interface ALSRelationDefinition extends ALSDefinition
{
} // ALSRelationDefinition
