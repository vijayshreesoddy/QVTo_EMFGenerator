package hu.bme.mit.inf.dlsreasoner.alloy.reasoner.builder;

@SuppressWarnings("all")
public interface Logic2AlloyLanguageMapper_TypeMapperTrace {
}
