package hu.bme.mit.inf.dlsreasoner.alloy.reasoner.builder;

import hu.bme.mit.inf.dlsreasoner.alloy.reasoner.builder.Logic2AlloyLanguageMapper;
import hu.bme.mit.inf.dlsreasoner.alloy.reasoner.builder.Logic2AlloyLanguageMapperTrace;
import hu.bme.mit.inf.dslreasoner.alloyLanguage.ALSDocument;
import hu.bme.mit.inf.dslreasoner.logic.model.logiclanguage.Type;

@SuppressWarnings("all")
public interface Logic2AlloyLanguageMapper_TypeScopeMapping {
  void addLowerMultiplicity(final ALSDocument document, final Type type, final int lowerMultiplicty, final Logic2AlloyLanguageMapper mapper, final Logic2AlloyLanguageMapperTrace trace);
  
  void addUpperMultiplicity(final ALSDocument document, final Type type, final int upperMultiplicty, final Logic2AlloyLanguageMapper mapper, final Logic2AlloyLanguageMapperTrace trace);
}
