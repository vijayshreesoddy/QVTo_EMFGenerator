package hu.bme.mit.inf.dlsreasoner.alloy.reasoner.builder;

import com.google.common.base.Objects;
import java.util.Arrays;

/**
 * Helper class for efficiently matching parameter substitutions for functions and relations.
 */
@SuppressWarnings("all")
public class ParameterSubstitution {
  private final Object[] data;
  
  public ParameterSubstitution(final Object[] data) {
    this.data = data;
  }
  
  @Override
  public boolean equals(final Object obj) {
    if ((obj == this)) {
      return true;
    } else {
      boolean _equals = Objects.equal(obj, null);
      if (_equals) {
        return false;
      }
    }
    if ((obj instanceof ParameterSubstitution)) {
      return Arrays.equals(this.data, ((ParameterSubstitution)obj).data);
    }
    return false;
  }
  
  @Override
  public int hashCode() {
    return Arrays.hashCode(this.data);
  }
}
