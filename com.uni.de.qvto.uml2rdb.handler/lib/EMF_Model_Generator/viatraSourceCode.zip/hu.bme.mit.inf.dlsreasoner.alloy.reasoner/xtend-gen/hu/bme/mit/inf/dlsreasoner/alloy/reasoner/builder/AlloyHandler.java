package hu.bme.mit.inf.dlsreasoner.alloy.reasoner.builder;

import com.google.common.base.Objects;
import edu.mit.csail.sdg.alloy4.A4Reporter;
import edu.mit.csail.sdg.alloy4.Err;
import edu.mit.csail.sdg.alloy4.ErrorWarning;
import edu.mit.csail.sdg.alloy4compiler.ast.Command;
import edu.mit.csail.sdg.alloy4compiler.parser.CompModule;
import edu.mit.csail.sdg.alloy4compiler.parser.CompUtil;
import edu.mit.csail.sdg.alloy4compiler.translator.A4Options;
import edu.mit.csail.sdg.alloy4compiler.translator.A4Solution;
import hu.bme.mit.inf.dlsreasoner.alloy.reasoner.AlloyBackendSolver;
import hu.bme.mit.inf.dlsreasoner.alloy.reasoner.AlloySolverConfiguration;
import hu.bme.mit.inf.dlsreasoner.alloy.reasoner.builder.AlloyCallerWithTimeout;
import hu.bme.mit.inf.dlsreasoner.alloy.reasoner.builder.AlloySolverException;
import hu.bme.mit.inf.dlsreasoner.alloy.reasoner.builder.MonitoredAlloySolution;
import hu.bme.mit.inf.dlsreasoner.alloy.reasoner.builder.SolverConfiguration;
import hu.bme.mit.inf.dslreasoner.alloyLanguage.ALSDocument;
import hu.bme.mit.inf.dslreasoner.logic.model.builder.LogicSolverConfiguration;
import hu.bme.mit.inf.dslreasoner.workspace.ReasonerWorkspace;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;
import org.eclipse.xtend2.lib.StringConcatenation;
import org.eclipse.xtext.xbase.lib.Exceptions;
import org.eclipse.xtext.xbase.lib.IterableExtensions;
import org.eclipse.xtext.xbase.lib.ObjectExtensions;
import org.eclipse.xtext.xbase.lib.Pair;
import org.eclipse.xtext.xbase.lib.Procedures.Procedure1;

@SuppressWarnings("all")
public class AlloyHandler {
  public MonitoredAlloySolution callSolver(final ALSDocument problem, final ReasonerWorkspace workspace, final AlloySolverConfiguration configuration, final String alloyCode) {
    try {
      MonitoredAlloySolution _xblockexpression = null;
      {
        final LinkedList<String> warnings = new LinkedList<String>();
        final LinkedList<String> debugs = new LinkedList<String>();
        final ArrayList<Long> runtime = new ArrayList<Long>();
        final A4Reporter reporter = new A4Reporter() {
          @Override
          public void debug(final String message) {
            debugs.add(message);
          }
          
          @Override
          public void resultSAT(final Object command, final long solvingTime, final Object solution) {
            runtime.add(Long.valueOf(solvingTime));
          }
          
          @Override
          public void resultUNSAT(final Object command, final long solvingTime, final Object solution) {
            runtime.add(Long.valueOf(solvingTime));
          }
          
          @Override
          public void warning(final ErrorWarning msg) {
            String _message = msg.getMessage();
            warnings.add(_message);
          }
        };
        A4Options _a4Options = new A4Options();
        final Procedure1<A4Options> _function = (A4Options it) -> {
          it.symmetry = configuration.symmetry;
          it.noOverflow = true;
          it.solver = this.getSolver(configuration.solver, configuration);
          boolean _isExternalSolver = this.isExternalSolver(configuration.solver);
          if (_isExternalSolver) {
            it.solverDirectory = configuration.solverPath;
          }
        };
        final A4Options options = ObjectExtensions.<A4Options>operator_doubleArrow(_a4Options, _function);
        Command command = null;
        CompModule compModule = null;
        final long kodkodTransformStart = System.currentTimeMillis();
        try {
          compModule = CompUtil.parseEverything_fromString(reporter, alloyCode);
          int _size = compModule.getAllCommands().size();
          boolean _notEquals = (_size != 1);
          if (_notEquals) {
            StringConcatenation _builder = new StringConcatenation();
            _builder.append("Alloy files with multiple commands are not supported!");
            throw new UnsupportedOperationException(_builder.toString());
          }
          command = IterableExtensions.<Command>head(compModule.getAllCommands());
        } catch (final Throwable _t) {
          if (_t instanceof Err) {
            final Err e = (Err)_t;
            String _message = e.getMessage();
            throw new AlloySolverException(_message, warnings, e);
          } else {
            throw Exceptions.sneakyThrow(_t);
          }
        }
        long _currentTimeMillis = System.currentTimeMillis();
        final long kodkodTransformFinish = (_currentTimeMillis - kodkodTransformStart);
        final AlloyCallerWithTimeout callable = new AlloyCallerWithTimeout(warnings, debugs, reporter, options, command, compModule, configuration);
        List<Pair<A4Solution, Long>> answers = null;
        boolean finished = false;
        if ((configuration.runtimeLimit == LogicSolverConfiguration.Unlimited)) {
          answers = callable.call();
          finished = true;
        } else {
          final ExecutorService executor = Executors.newCachedThreadPool();
          final Future<List<Pair<A4Solution, Long>>> future = executor.<List<Pair<A4Solution, Long>>>submit(callable);
          try {
            answers = future.get(configuration.runtimeLimit, TimeUnit.SECONDS);
            finished = true;
          } catch (final Throwable _t) {
            if (_t instanceof TimeoutException || _t instanceof InterruptedException || _t instanceof ExecutionException) {
              future.cancel(true);
              answers = callable.getPartialAnswers();
              finished = false;
            } else {
              throw Exceptions.sneakyThrow(_t);
            }
          }
        }
        _xblockexpression = new MonitoredAlloySolution(warnings, debugs, kodkodTransformFinish, answers, finished);
      }
      return _xblockexpression;
    } catch (Throwable _e) {
      throw Exceptions.sneakyThrow(_e);
    }
  }
  
  private static final Map<SolverConfiguration, A4Options.SatSolver> previousSolverConfigurations = new HashMap<SolverConfiguration, A4Options.SatSolver>();
  
  public A4Options.SatSolver getSolverConfiguration(final AlloyBackendSolver backedSolver, final String path, final String[] options) {
    try {
      final SolverConfiguration config = new SolverConfiguration(backedSolver, path, options);
      boolean _containsKey = AlloyHandler.previousSolverConfigurations.containsKey(config);
      if (_containsKey) {
        return AlloyHandler.previousSolverConfigurations.get(config);
      } else {
        StringConcatenation _builder = new StringConcatenation();
        _builder.append("DSLReasoner_Alloy_");
        int _size = AlloyHandler.previousSolverConfigurations.size();
        _builder.append(_size);
        _builder.append("_");
        _builder.append(backedSolver);
        final String id = _builder.toString();
        final A4Options.SatSolver newSolver = A4Options.SatSolver.make(id, id, path, options);
        AlloyHandler.previousSolverConfigurations.put(config, newSolver);
        return newSolver;
      }
    } catch (Throwable _e) {
      throw Exceptions.sneakyThrow(_e);
    }
  }
  
  public A4Options.SatSolver getSolver(final AlloyBackendSolver backedSolver, final AlloySolverConfiguration configuration) {
    if (backedSolver != null) {
      switch (backedSolver) {
        case BerkMinPIPE:
          return A4Options.SatSolver.BerkMinPIPE;
        case SpearPIPE:
          return A4Options.SatSolver.SpearPIPE;
        case MiniSatJNI:
          return A4Options.SatSolver.MiniSatJNI;
        case MiniSatProverJNI:
          return A4Options.SatSolver.MiniSatProverJNI;
        case LingelingJNI:
          return A4Options.SatSolver.LingelingJNI;
        case PLingelingJNI:
          return this.getSolverConfiguration(backedSolver, configuration.solverPath, null);
        case GlucoseJNI:
          return A4Options.SatSolver.GlucoseJNI;
        case CryptoMiniSatJNI:
          return A4Options.SatSolver.CryptoMiniSatJNI;
        case SAT4J:
          return A4Options.SatSolver.SAT4J;
        case CNF:
          return A4Options.SatSolver.CNF;
        case KodKod:
          return A4Options.SatSolver.KK;
        default:
          break;
      }
    }
    return null;
  }
  
  public boolean isExternalSolver(final AlloyBackendSolver backedSolver) {
    boolean _equals = Objects.equal(backedSolver, AlloyBackendSolver.SAT4J);
    return (!_equals);
  }
}
