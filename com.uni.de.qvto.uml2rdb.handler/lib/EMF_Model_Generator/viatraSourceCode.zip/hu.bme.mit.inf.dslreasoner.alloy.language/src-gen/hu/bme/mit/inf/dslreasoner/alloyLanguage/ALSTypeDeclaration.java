/**
 */
package hu.bme.mit.inf.dslreasoner.alloyLanguage;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>ALS Type Declaration</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see hu.bme.mit.inf.dslreasoner.alloyLanguage.AlloyLanguagePackage#getALSTypeDeclaration()
 * @model
 * @generated
 */
public interface ALSTypeDeclaration extends ALSRelationDeclaration
{
} // ALSTypeDeclaration
